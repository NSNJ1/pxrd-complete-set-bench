"""Audit recoverable candidate structures for cross-source reuse."""

from __future__ import annotations

import argparse
import hashlib
import json
import warnings
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import pandas as pd
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Structure
from pymatgen.io.cif import CifParser
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

SOURCE_ROOTS = {
    "ariadnex_controlled": (
        "strict_benchmark_evidence_20261123/"
        "external_method_handoff_v0.5/input/candidates"
    ),
    "xca_nicoal": "xca20_crystalshift_20261124/dataset/public/cif",
    "galaxi_validation": (
        "structure_overlap_audit_20261124/source_cache/"
        "galaxi-ad46d82afdf5c42fde72759734f6d25582372109/"
        "reproduction/validation/ref_200"
    ),
    "galaxi_pristine": (
        "structure_overlap_audit_20261124/source_cache/"
        "galaxi-ad46d82afdf5c42fde72759734f6d25582372109/"
        "examples/pretrained_catalog/reference_cifs"
    ),
    "realbind20": (
        "realbind20_crystalshift_20261124/dataset_v2_repro/candidates"
    ),
    "realbind_paired104": "realbind_paired104_20261124/run_v1/shared/cif",
    "realbind_hard20": "realbind_hard20_20261124/public/cif",
    "deltaxrd_rruff": (
        "deltaxrd20_20261124/dataset_v2/rruff/public/cif"
    ),
    "deltaxrd_opxrd": (
        "deltaxrd20_20261124/dataset_v2/opxrd/public/cif"
    ),
    "chemin_cod": "chemin_external_20261124/cod_cache/cif",
    "opxrd_empa": (
        "frontier_review_20261123/opxrd_empa_20261123/candidates"
    ),
    "tasno": (
        "../../../../external_benchmarks/CrystalShift.jl/data/Ta-Sn-O"
    ),
}

LINEAGES = {
    "ariadnex_controlled": "ariadnex",
    "xca_nicoal": "xca",
    "galaxi_validation": "galaxi",
    "galaxi_pristine": "galaxi",
    "realbind20": "realbind",
    "realbind_paired104": "realbind",
    "realbind_hard20": "realbind",
    "deltaxrd_rruff": "deltaxrd_rruff",
    "deltaxrd_opxrd": "opxrd",
    "chemin_cod": "chemin",
    "opxrd_empa": "opxrd",
    "tasno": "tasno",
}

UNAVAILABLE_CORE = {
    "precursor_genome": (
        "The score table retains ICSD identifiers, but the nested ICSD "
        "structures are not redistributed or present locally."
    ),
    "rare_earth_mof": (
        "The score table retains CSD refcodes, but the nested CSD structures "
        "are not redistributed or present locally."
    ),
}


def load_source_spec(path: Path) -> tuple[dict[str, str], dict[str, str], dict]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    sources = payload.get("sources")
    if not isinstance(sources, dict) or not sources:
        raise ValueError("source spec needs a non-empty sources mapping")
    source_roots = {}
    lineages = {}
    for name, metadata in sources.items():
        if not isinstance(metadata, dict):
            raise TypeError(f"source metadata must be an object: {name}")
        root = str(metadata.get("root", "")).strip()
        lineage = str(metadata.get("lineage", "")).strip()
        if not root or not lineage:
            raise ValueError(f"source needs root and lineage: {name}")
        source_roots[name] = root
        lineages[name] = lineage
    unavailable = payload.get("unavailable", {})
    if not isinstance(unavailable, dict):
        raise TypeError("unavailable must be an object")
    return source_roots, lineages, unavailable


@dataclass(frozen=True)
class CifRecord:
    sha256: str
    source: str
    path: Path
    relative_path: str
    structure: Structure | None
    formula: str | None
    primitive_sites: int | None
    space_group_number: int | None
    space_group_symbol: str | None
    volume_per_site: float | None
    parse_error: str | None
    symmetry_error: str | None


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_memberships(
    root: Path,
) -> tuple[list[dict], dict[str, set[str]], dict[str, list[Path]]]:
    records = []
    memberships: dict[str, set[str]] = defaultdict(set)
    paths_by_hash: dict[str, list[Path]] = defaultdict(list)
    for source, relative_root in SOURCE_ROOTS.items():
        directory = root / relative_root
        if not directory.exists():
            raise FileNotFoundError(f"missing source CIF directory: {directory}")
        paths = sorted(directory.rglob("*.cif"))
        if not paths:
            raise ValueError(f"no CIF files found in {directory}")
        for path in paths:
            digest = sha256(path)
            memberships[digest].add(source)
            paths_by_hash[digest].append(path)
            records.append(
                {
                    "source": source,
                    "lineage": LINEAGES[source],
                    "sha256": digest,
                    "path": path.relative_to(root).as_posix(),
                }
            )
    return records, memberships, paths_by_hash


def parse_cif(
    digest: str,
    path: Path,
    sources: set[str],
    root: Path,
) -> CifRecord:
    primary_source = min(sources)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structures = CifParser(path).parse_structures(primitive=False)
        if not structures:
            raise ValueError("CIF contains no parsed structure")
        primitive = structures[0].get_primitive_structure(tolerance=0.25)
        try:
            analyzer = SpacegroupAnalyzer(primitive, symprec=0.1)
            space_group_number = int(analyzer.get_space_group_number())
            space_group_symbol = str(analyzer.get_space_group_symbol())
            symmetry_error = None
        except (RuntimeError, TypeError, ValueError) as error:
            space_group_number = None
            space_group_symbol = None
            symmetry_error = f"{type(error).__name__}: {error}"
        return CifRecord(
            sha256=digest,
            source=primary_source,
            path=path,
            relative_path=path.relative_to(root).as_posix(),
            structure=primitive,
            formula=primitive.composition.reduced_formula,
            primitive_sites=len(primitive),
            space_group_number=space_group_number,
            space_group_symbol=space_group_symbol,
            volume_per_site=float(primitive.volume / len(primitive)),
            parse_error=None,
            symmetry_error=symmetry_error,
        )
    except (IndexError, KeyError, RuntimeError, TypeError, ValueError) as error:
        return CifRecord(
            sha256=digest,
            source=primary_source,
            path=path,
            relative_path=path.relative_to(root).as_posix(),
            structure=None,
            formula=None,
            primitive_sites=None,
            space_group_number=None,
            space_group_symbol=None,
            volume_per_site=None,
            parse_error=f"{type(error).__name__}: {error}",
            symmetry_error=None,
        )


def source_pair(left: set[str], right: set[str]) -> str:
    labels = ["+".join(sorted(left)), "+".join(sorted(right))]
    return "__".join(sorted(labels))


def anonymize(structure: Structure) -> Structure:
    return Structure(
        structure.lattice,
        ["X"] * len(structure),
        structure.frac_coords,
        coords_are_cartesian=False,
    )


def fit_record(
    matcher: StructureMatcher,
    left: Structure,
    right: Structure,
) -> dict | None:
    fit = matcher.get_rms_dist(left, right)
    if fit is None:
        return None
    normalized_rms, maximum_distance = fit
    return {
        "normalized_rms": float(normalized_rms),
        "maximum_distance": float(maximum_distance),
    }


def structural_pairs(
    records: list[CifRecord],
    memberships: dict[str, set[str]],
) -> tuple[list[dict], list[dict]]:
    parsed = [record for record in records if record.structure is not None]
    lattice_matcher = StructureMatcher(
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
        primitive_cell=True,
        scale=False,
        attempt_supercell=False,
    )
    scale_matcher = StructureMatcher(
        ltol=0.2,
        stol=0.3,
        angle_tol=5.0,
        primitive_cell=True,
        scale=True,
        attempt_supercell=False,
    )
    permissive_matcher = StructureMatcher(
        ltol=0.3,
        stol=0.5,
        angle_tol=10.0,
        primitive_cell=True,
        scale=True,
        attempt_supercell=False,
    )
    prototype_matcher = StructureMatcher(
        ltol=0.3,
        stol=0.5,
        angle_tol=10.0,
        primitive_cell=True,
        scale=True,
        attempt_supercell=False,
    )

    formula_groups: dict[str, list[CifRecord]] = defaultdict(list)
    prototype_groups: dict[tuple[int, int], list[CifRecord]] = defaultdict(list)
    for record in parsed:
        formula_groups[str(record.formula)].append(record)
        if record.space_group_number is not None:
            prototype_groups[
                (
                    int(record.space_group_number),
                    int(record.primitive_sites),
                )
            ].append(record)

    structure_pairs = []
    seen_structure_pairs = set()
    for formula, group in sorted(formula_groups.items()):
        for left_index, left in enumerate(group):
            for right in group[left_index + 1 :]:
                if left.primitive_sites != right.primitive_sites:
                    continue
                if memberships[left.sha256] == memberships[right.sha256]:
                    continue
                permissive = fit_record(
                    permissive_matcher,
                    left.structure,
                    right.structure,
                )
                if permissive is None:
                    continue
                scale_normalized = fit_record(
                    scale_matcher,
                    left.structure,
                    right.structure,
                )
                if scale_normalized is None:
                    continue
                lattice_preserving = fit_record(
                    lattice_matcher,
                    left.structure,
                    right.structure,
                )
                pair_key = tuple(sorted((left.sha256, right.sha256)))
                if pair_key in seen_structure_pairs:
                    continue
                seen_structure_pairs.add(pair_key)
                structure_pairs.append(
                    {
                        "left_sha256": left.sha256,
                        "right_sha256": right.sha256,
                        "formula": formula,
                        "space_group_number": left.space_group_number,
                        "primitive_sites": left.primitive_sites,
                        "lattice_preserving_match": (
                            lattice_preserving is not None
                        ),
                        "scale_normalized_match": True,
                        "lattice_preserving_rms": (
                            lattice_preserving["normalized_rms"]
                            if lattice_preserving is not None
                            else None
                        ),
                        "permissive_rms": permissive["normalized_rms"],
                        "permissive_max_distance": permissive[
                            "maximum_distance"
                        ],
                        "left_sources": "|".join(
                            sorted(memberships[left.sha256])
                        ),
                        "right_sources": "|".join(
                            sorted(memberships[right.sha256])
                        ),
                        "left_path": left.relative_path,
                        "right_path": right.relative_path,
                    }
                )

    prototype_pairs = []
    seen_prototype_pairs = set()
    for _, group in sorted(prototype_groups.items()):
        if len(group) < 2:
            continue
        anonymized = {
            record.sha256: anonymize(record.structure)
            for record in group
        }
        for left_index, left in enumerate(group):
            for right in group[left_index + 1 :]:
                if left.formula == right.formula:
                    continue
                if memberships[left.sha256] == memberships[right.sha256]:
                    continue
                pair_key = tuple(sorted((left.sha256, right.sha256)))
                if pair_key in seen_prototype_pairs:
                    continue
                seen_prototype_pairs.add(pair_key)
                fit = fit_record(
                    prototype_matcher,
                    anonymized[left.sha256],
                    anonymized[right.sha256],
                )
                if fit is None:
                    continue
                prototype_pairs.append(
                    {
                        "left_sha256": left.sha256,
                        "right_sha256": right.sha256,
                        "left_formula": left.formula,
                        "right_formula": right.formula,
                        "space_group_number": left.space_group_number,
                        "space_group_symbol": left.space_group_symbol,
                        "primitive_sites": left.primitive_sites,
                        "normalized_rms": fit["normalized_rms"],
                        "maximum_distance": fit["maximum_distance"],
                        "left_sources": "|".join(
                            sorted(memberships[left.sha256])
                        ),
                        "right_sources": "|".join(
                            sorted(memberships[right.sha256])
                        ),
                        "left_path": left.relative_path,
                        "right_path": right.relative_path,
                    }
                )
    return structure_pairs, prototype_pairs


def exact_clusters(
    memberships: dict[str, set[str]],
    paths_by_hash: dict[str, list[Path]],
    root: Path,
) -> list[dict]:
    clusters = []
    for digest, sources in memberships.items():
        if len(sources) < 2:
            continue
        clusters.append(
            {
                "sha256": digest,
                "sources": sorted(sources),
                "lineages": sorted({LINEAGES[source] for source in sources}),
                "paths": [
                    path.relative_to(root).as_posix()
                    for path in sorted(paths_by_hash[digest])
                ],
            }
        )
    clusters.sort(key=lambda item: (-len(item["sources"]), item["sha256"]))
    return clusters


def summarize_pairs(
    pair_rows: list[dict],
    memberships: dict[str, set[str]],
) -> dict:
    report = {
        "lattice_preserving_same_formula": 0,
        "scale_normalized_same_formula": 0,
        "cross_lineage_lattice_preserving": 0,
        "cross_lineage_scale_normalized": 0,
        "source_pairs": {},
    }
    for row in pair_rows:
        lattice_preserving = bool(row["lattice_preserving_match"])
        report["scale_normalized_same_formula"] += 1
        if lattice_preserving:
            report["lattice_preserving_same_formula"] += 1
        left_sources = memberships[row["left_sha256"]]
        right_sources = memberships[row["right_sha256"]]
        cross_lineage = {
            LINEAGES[source] for source in left_sources
        } != {LINEAGES[source] for source in right_sources}
        if cross_lineage:
            report["cross_lineage_scale_normalized"] += 1
            if lattice_preserving:
                report["cross_lineage_lattice_preserving"] += 1
        key = source_pair(left_sources, right_sources)
        local = report["source_pairs"].setdefault(
            key,
            {
                "lattice_preserving_same_formula": 0,
                "scale_normalized_same_formula": 0,
            },
        )
        local["scale_normalized_same_formula"] += 1
        if lattice_preserving:
            local["lattice_preserving_same_formula"] += 1
    return report


def pair_lineage_key(left: str, right: str) -> str:
    return "__".join(sorted((left, right)))


def structure_pair_lineage_overlap(
    pair_rows: list[dict],
) -> dict:
    grouped: dict[str, dict[str, set]] = defaultdict(
        lambda: {
            "pairs": set(),
            "structures_by_lineage": defaultdict(set),
        }
    )
    for row in pair_rows:
        left_lineages = {
            LINEAGES[source]
            for source in row["left_sources"].split("|")
        }
        right_lineages = {
            LINEAGES[source]
            for source in row["right_sources"].split("|")
        }
        pair = tuple(
            sorted((row["left_sha256"], row["right_sha256"]))
        )
        for left in left_lineages:
            for right in right_lineages:
                if left == right:
                    continue
                key = pair_lineage_key(left, right)
                grouped[key]["pairs"].add(pair)
                grouped[key]["structures_by_lineage"][left].add(
                    row["left_sha256"]
                )
                grouped[key]["structures_by_lineage"][right].add(
                    row["right_sha256"]
                )
    return {
        key: {
            "unique_structure_pairs": len(value["pairs"]),
            "unique_structures_by_lineage": {
                lineage: len(structures)
                for lineage, structures in sorted(
                    value["structures_by_lineage"].items()
                )
            },
        }
        for key, value in sorted(grouped.items())
    }


def exact_cluster_lineage_overlap(clusters: list[dict]) -> dict:
    grouped: dict[str, set[str]] = defaultdict(set)
    for cluster in clusters:
        lineages = sorted(
            {LINEAGES[source] for source in cluster["sources"]}
        )
        for index, left in enumerate(lineages):
            for right in lineages[index + 1 :]:
                grouped[pair_lineage_key(left, right)].add(
                    cluster["sha256"]
                )
    return {
        key: len(values)
        for key, values in sorted(grouped.items())
    }


def prototype_lineage_overlap(pair_rows: list[dict]) -> dict:
    grouped: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for row in pair_rows:
        left_lineages = {
            LINEAGES[source]
            for source in row["left_sources"].split("|")
        }
        right_lineages = {
            LINEAGES[source]
            for source in row["right_sources"].split("|")
        }
        pair = tuple(
            sorted((row["left_sha256"], row["right_sha256"]))
        )
        for left in left_lineages:
            for right in right_lineages:
                if left != right:
                    grouped[pair_lineage_key(left, right)].add(pair)
    return {
        key: len(values)
        for key, values in sorted(grouped.items())
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
    )
    parser.add_argument("--source-spec", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.out_dir.exists() and any(args.out_dir.iterdir()):
        raise FileExistsError(f"refusing to overwrite {args.out_dir}")
    args.out_dir.mkdir(parents=True, exist_ok=True)

    if args.source_spec is not None:
        global SOURCE_ROOTS, LINEAGES, UNAVAILABLE_CORE
        SOURCE_ROOTS, LINEAGES, UNAVAILABLE_CORE = load_source_spec(
            args.source_spec
        )

    occurrences, memberships, paths_by_hash = source_memberships(args.root)
    records = [
        parse_cif(digest, min(paths), memberships[digest], args.root)
        for digest, paths in sorted(paths_by_hash.items())
    ]
    parse_failures = [
        {
            "sha256": record.sha256,
            "path": record.relative_path,
            "error": record.parse_error,
        }
        for record in records
        if record.structure is None
    ]

    structure_pairs, prototype_pairs = structural_pairs(records, memberships)
    clusters = exact_clusters(memberships, paths_by_hash, args.root)
    summary = summarize_pairs(structure_pairs, memberships)
    prototype_cross_lineage = sum(
        {
            LINEAGES[source]
            for source in row["left_sources"].split("|")
        }
        != {
            LINEAGES[source]
            for source in row["right_sources"].split("|")
        }
        for row in prototype_pairs
    )

    inventory_rows = []
    for record in records:
        inventory_rows.append(
            {
                "sha256": record.sha256,
                "sources": "|".join(sorted(memberships[record.sha256])),
                "path": record.relative_path,
                "formula": record.formula,
                "primitive_sites": record.primitive_sites,
                "space_group_number": record.space_group_number,
                "space_group_symbol": record.space_group_symbol,
                "volume_per_site": record.volume_per_site,
                "parse_error": record.parse_error,
                "symmetry_error": record.symmetry_error,
            }
        )
    pd.DataFrame(inventory_rows).to_csv(
        args.out_dir / "structure_inventory.csv",
        index=False,
        lineterminator="\n",
    )
    pd.DataFrame(occurrences).to_csv(
        args.out_dir / "source_cif_occurrences.csv",
        index=False,
        lineterminator="\n",
    )
    pd.DataFrame(structure_pairs).to_csv(
        args.out_dir / "same_formula_structure_pairs.csv",
        index=False,
        lineterminator="\n",
    )
    pd.DataFrame(prototype_pairs).to_csv(
        args.out_dir / "anonymous_prototype_pairs.csv",
        index=False,
        lineterminator="\n",
    )

    report = {
        "status": "structure_and_prototype_overlap_audit_complete",
        "claim_boundary": (
            "Recoverable local candidate structures only. Exact and structural "
            "overlap is library reuse, not by itself training leakage. "
            "Unavailable source structures are reported, not imputed."
        ),
        "source_spec": (
            {
                "path": args.source_spec.name,
                "sha256": hashlib.sha256(
                    args.source_spec.read_bytes()
                ).hexdigest(),
            }
            if args.source_spec is not None
            else None
        ),
        "contract": {
            "lattice_preserving_structure_match": {
                "ltol": 0.2,
                "stol": 0.3,
                "angle_tol_deg": 5.0,
                "primitive_cell": True,
                "scale": False,
            },
            "scale_normalized_structure_match": {
                "ltol": 0.3,
                "stol": 0.5,
                "angle_tol_deg": 10.0,
                "primitive_cell": True,
                "scale": True,
            },
            "prototype_match": (
                "permissive StructureMatcher on all-species-anonymized "
                "structures, limited to equal space-group number and "
                "primitive site count"
            ),
            "symmetry_tolerance": 0.1,
            "primitive_reduction_tolerance": 0.25,
        },
        "coverage": {
            "sources": len(SOURCE_ROOTS),
            "source_cif_occurrences": len(occurrences),
            "unique_cif_sha256": len(records),
            "parsed_unique_structures": len(records) - len(parse_failures),
            "parse_failures": len(parse_failures),
            "symmetry_failures": sum(
                record.symmetry_error is not None for record in records
            ),
            "files_by_source": {
                source: sum(
                    row["source"] == source for row in occurrences
                )
                for source in SOURCE_ROOTS
            },
            "unique_structures_by_source": {
                source: sum(
                    source in sources for sources in memberships.values()
                )
                for source in SOURCE_ROOTS
            },
            "unavailable_core_sources": UNAVAILABLE_CORE,
        },
        "exact_byte_identity": {
            "cross_source_clusters": len(clusters),
            "clusters": clusters,
        },
        "same_formula_structural_overlap": summary,
        "lineage_overlap": {
            "exact_byte_duplicate_clusters": exact_cluster_lineage_overlap(
                clusters
            ),
            "same_formula_structure_pairs": structure_pair_lineage_overlap(
                structure_pairs
            ),
            "anonymous_prototype_pairs": prototype_lineage_overlap(
                prototype_pairs
            ),
        },
        "prototype_overlap": {
            "all_pairs": len(prototype_pairs),
            "cross_lineage_pairs": int(prototype_cross_lineage),
            "top_pairs": sorted(
                prototype_pairs,
                key=lambda row: row["normalized_rms"],
            )[:100],
        },
        "parse_failures": parse_failures,
    }
    (args.out_dir / "structure_overlap_audit.json").write_text(
        json.dumps(
            report,
            ensure_ascii=False,
            indent=2,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "unique_cif_sha256": report["coverage"][
                    "unique_cif_sha256"
                ],
                "parsed_unique_structures": report["coverage"][
                    "parsed_unique_structures"
                ],
                "exact_cross_source_clusters": len(clusters),
                "lattice_preserving_same_formula": summary[
                    "lattice_preserving_same_formula"
                ],
                "scale_normalized_same_formula": summary[
                    "scale_normalized_same_formula"
                ],
                "cross_lineage_lattice_preserving": summary[
                    "cross_lineage_lattice_preserving"
                ],
                "cross_lineage_scale_normalized": summary[
                    "cross_lineage_scale_normalized"
                ],
                "cross_lineage_prototype_pairs": int(
                    prototype_cross_lineage
                ),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    if parse_failures:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
