# PXRD benchmark 跨来源结构/原型重叠审计

日期：2026-11-24  
状态：`structure_and_prototype_overlap_audit_complete`

## 先给结论

这次审计找到一个会影响论文叙事、但不推翻主结论的事实：

> 我们的外部来源在“实测谱和样品”层面是多样的，但在“候选结构库”层面
> 并不是结构互斥的。多个 benchmark panel 复用了相同或近重复的候选结构。

这不是训练泄漏的直接证明。它说明论文不能写：

> 所有外部来源都独立，并且模型是在完全未见的材料结构上泛化。

更准确的写法是：

> 这些实验检验跨仪器、跨样品和跨流程的 query-level 转移；
> 候选结构空间存在已知复用，因此不能把结果解释为 unseen-structure
> generalization。

这一区分对一区审稿很重要。候选库复用是材料学 benchmark 常见的正常现象，
但必须在实验中声明，不能把来源数量直接等同于结构独立证据。

## 覆盖范围

本次恢复了 12 个候选集合，共：

- 1,692 个 CIF 文件出现；
- 1,599 个唯一 CIF SHA-256；
- 1,599 个结构成功解析；
- CIF 解析失败 0；
- 1 个结构的对称性分析失败，但其结构体仍用于同成分比较；
- CIF 字节完全一致的重复跨来源簇 91 个。

去重后的 lineage 覆盖：

| Lineage | 唯一结构数 |
| --- | ---: |
| GALAXI validation + pristine | 566 |
| DeltaXRD RRUFF | 433 |
| opXRD / DeltaXRD opXRD / opXRD-EMPA | 376 |
| RealBind 20 / 104 / hard-negative | 124 |
| CheMin COD | 58 |
| XCA Ni-Co-Al | 31 |
| Ta-Sn-O | 15 |
| AriadneX controlled | 4 |

七个核心来源中，已经恢复五个来源记录的结构：

- AriadneX；
- XCA Ni-Co-Al；
- Ta-Sn-O；
- GALAXI validation；
- GALAXI pristine。

按 query 计，覆盖 `1,449 / 1,921`，即 **75.4%** 的核心 query 所属来源。

只有两个核心来源仍缺少可合法恢复的完整候选 CIF：

- rare-earth MOF：公开包有 CSD refcodes 和参考峰表，但没有 CIF；
- Precursor Genome：公开 ledger 有 `cif_names`，但没有对应 CIF payload；
  结构来自嵌套 ICSD，不能凭空补造。

我实际检查了 rare-earth 的
`pxrd-search-match-details.zip`：6 个文件、0 个 CIF。Precursor Genome
固定提交的 ledger 也只给出 CIF 名称，不包含结构正文。因此这两项保持
“不可用”，没有用化学式或猜测结构代替。

## 审计方法

### 1. 字节级重复

对每个 CIF 计算 SHA-256。相同哈希视为同一文件被不同 panel 复用。

### 2. 同成分晶格保持结构匹配

使用 pymatgen `StructureMatcher`：

- `ltol = 0.2`；
- `stol = 0.3`；
- `angle_tol = 5 deg`；
- primitive cell；
- `scale = False`。

这一步要求化学成分相同、原子位置和晶格相近，但不允许靠整体缩放把不同晶格
强行匹配。

### 3. 允许尺度归一化的结构匹配

同样阈值但 `scale = True`。这一层可以识别晶格整体缩放后的同拓扑结构。

本次 743 对同成分匹配在两种设置下完全相同，说明它们不是依靠尺度归一化才
成立。

### 4. 匿名原型匹配

去掉元素身份后，以：

- 相同空间群；
- 相同 primitive site 数；
- `ltol = 0.3`、`stol = 0.5`、`angle_tol = 10 deg`；

比较结构骨架。原型相同不等于泄漏，例如岩盐、尖晶石和萤石原型会跨化学组成
重复。因此本报告只把它作为候选库多样性诊断。

## 字节级完全相同

91 个跨来源哈希簇中：

- 83 个是 RealBind paired104 与 RealBind hard20 的重复；
- 8 个是 DeltaXRD-opXRD 与 RealBind20 的完全相同 CIF。

前者是同一 RealBind lineage 内部的面板复用，不应伪装成独立来源。
后者的 8 个跨 lineage 完全相同结构更需要显式披露。

没有发现 CheMin、GALAXI、XCA、Ta-Sn-O 与其他来源的 CIF 字节完全相同。

## 同成分近重复结构

共 743 对 unique hash pairs。其中 644 对跨 lineage。

但这 743 对不能直接当作“744 个泄漏风险”，因为 625 对来自同一个
`As2O3` 硬负例家族。该家族横跨 opXRD 与 RealBind，可能是专门构造的
近重复负例，数量会放大原始 pair 数。

去掉 `As2O3` 后：

- 剩余 118 对；
- 其中 90 对跨 lineage；
- 常见家族包括 Fe3O4、TiO2、Fe2O3、CaCO3、SiO2、MgSiO3、
  CaMg(CO3)2、FeHO2 和 SnO2。

主要跨 lineage 结果：

| Lineage pair | 唯一结构对 | 左 lineage 涉及结构 | 右 lineage 涉及结构 |
| --- | ---: | ---: | ---: |
| opXRD / RealBind | 575 | 40 / 376 | 51 / 124 |
| CheMin / DeltaXRD-RRUFF | 21 | 14 / 58 | 17 / 433 |
| CheMin / GALAXI | 18 | 10 / 58 | 8 / 566 |
| DeltaXRD-RRUFF / GALAXI | 11 | 9 / 433 | 7 / 566 |
| AriadneX / DeltaXRD-RRUFF | 7 | 3 / 4 | 7 / 433 |
| GALAXI / RealBind | 4 | 4 / 566 | 2 / 124 |
| CheMin / RealBind | 3 | 3 / 58 | 1 / 124 |
| GALAXI / opXRD | 2 | 2 / 566 | 2 / 376 |
| AriadneX / CheMin | 1 | 1 / 4 | 1 / 58 |
| AriadneX / GALAXI | 1 | 1 / 4 | 1 / 566 |
| DeltaXRD-RRUFF / Ta-Sn-O | 1 | 1 / 433 | 1 / 15 |

按 lineage 汇总有任意跨来源同成分结构重叠的比例：

| Lineage | 有重叠的结构 / 唯一结构 | 比例 |
| --- | ---: | ---: |
| AriadneX | 3 / 4 | 75.0% |
| RealBind | 53 / 124 | 42.7% |
| CheMin | 21 / 58 | 36.2% |
| opXRD | 42 / 376 | 11.2% |
| Ta-Sn-O | 1 / 15 | 6.7% |
| DeltaXRD-RRUFF | 28 / 433 | 6.5% |
| GALAXI | 16 / 566 | 2.8% |
| XCA | 0 / 31 | 0% |

这里 Key 的信息不是“36% 说明作弊”，而是：

> CheMin 的 58 条参考结构中，21 条在别的 benchmark lineage 里有同成分
> 严格结构匹配。因此 CheMin 证据首先是新仪器和新 query 的外部测试，
> 不是新结构空间测试。

## 匿名原型

共发现 1,307 个跨 lineage 匿名原型对。这个数字看起来很大，但材料学中
常见原型本来就会重复：

- 岩盐；
- 尖晶石；
- 萤石；
- 钙钛矿；
- 金红石；
- 刚玉型。

所以匿名原型不进入泄漏告警。它只说明不同候选库共享材料学原型，不能支持
“结构 prototype 完全不重叠”的表述。

## 对现有论文结论的影响

### 仍然成立

- 不同实测来源的 query transfer 是真实存在的；
- 固定 20 候选时，不同端点可以改变方法结论；
- RealBind hard-negative interaction 仍是显著证据；
- 频率先验、简单 Pearson 和 ordinary baseline 仍必须报告；
- CheMin 仍是跨仪器、Co K-alpha、许可清楚的新外部 source。

### 必须降级或改写

- 不能把 7 个或更多来源简单称为结构独立；
- 不能把外部方法结果写成 unseen-structure generalization；
- 不能忽略 RealBind 与 opXRD candidate-library 的大量复用；
- 不能把 AriadneX 的 4 个候选当成四个结构独立的材料空间样本；
- CheMin 的 21/58 结构跨 benchmark 匹配必须在 model contamination
  声明中列出。

### 反而增强的方法学观点

这次审计进一步证明：

> 候选库构造本身就是 benchmark 结论的一部分。只固定候选数，不固定候选
> 结构来源和 lineage，跨论文的 leaderboard 仍然不可直接比较。

这比单纯“复杂模型没有打赢 Pearson”更强，也更符合高水平 benchmark 论文
对 candidate construction、leakage control 和 source stratification 的要求。

## 一区判断

这次审计把原来一项未知风险变成了可量化边界，但没有把论文自动升级为
“完全一区平齐”。

当前判断仍然约为 **9.0/10 的严肃一区候选**，但 `full_q1_parity = false`。

还缺的最硬条件没有变化：

1. 一个真正前瞻、标签冻结后才获得的实测多相来源；
2. rare-earth MOF 与 Precursor Genome 的 CSD/ICSD 结构级核查，若合法结构
   无法取得，就只能在论文中明确写 unavailable；
3. 作者重写正文、主图和生产级投稿材料。

继续在同一批来源上换 Pearson 窗口、权重或相似模型，不会补上这三项。

## 复现与文件

最终审计对相同输入完整运行两次，5 个结果文件字节完全一致。

- 审计脚本 SHA-256：
  `be22379c7953b91cb47ac90d49310c6009bb9c7b024cd0b335228a3275e7b219`
- 主结果 SHA-256：
  `c2fc64e787817ffe4ace7416b89f4e2cf133b6a78a06ac88e3422de5c87a1208`
- 同成分结构对 SHA-256：
  `21980cc9fc090c7c8ed8787e9c62c4f1610e7bed52932cac44aaec7b30eea77d`

文件：

- `results_v14/structure_overlap_audit.json`
- `results_v14/structure_inventory.csv`
- `results_v14/source_cif_occurrences.csv`
- `results_v14/same_formula_structure_pairs.csv`
- `results_v14/anonymous_prototype_pairs.csv`
- `source_cache/SOURCE_MANIFEST.json`

