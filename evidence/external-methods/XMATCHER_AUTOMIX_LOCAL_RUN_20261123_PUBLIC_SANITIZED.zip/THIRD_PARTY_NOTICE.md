# Third-party attribution

XMatcher Desktop 1.3.0 was used under CC BY 4.0. The official release is
identified by Figshare DOI `10.6084/m9.figshare.32812985.v7`.

The method citation is:

> Cao, B. XMatcher: An Open-Source Framework for X-Ray Diffraction Phase
> Identification. arXiv:2607.17162 (2026).
> https://arxiv.org/abs/2607.17162

This evidence package contains the project's adapter, generated candidate
database, predictions, and raw API responses. It does not redistribute the
XMatcher application or its original database.
