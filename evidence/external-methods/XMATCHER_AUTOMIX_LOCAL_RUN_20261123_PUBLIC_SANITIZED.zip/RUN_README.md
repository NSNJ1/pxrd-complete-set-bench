# XMatcher four-candidate external run

This directory records a label-free execution of XMatcher Desktop 1.3.0 on the
frozen AriadneX four-candidate panel.

## Release and environment

- XMatcher Desktop 1.3.0
- Figshare DOI: `10.6084/m9.figshare.32812985.v7`
- License: CC BY 4.0
- Windows distribution SHA-256:
  `4bfb4a1bb4b14dfe0e3f6660841d4b0c08d1b3651b7266f0629b11c90c23c046`
- Windows 11 x64, Python 3.12.14, pymatgen 2026.5.4

The original XMatcher database was not modified permanently. Its hash is
recorded in `execution_status.json`. A temporary four-entry database was built
from the four frozen CIF files and restored after the run.

## Inputs

`input_manifest.json` is the label-free handoff manifest. It specifies four
candidate CIF hashes and 25 measured Mo K-alpha spectra. The adapter verified
all hashes before inference. The candidates are:

- A: CaCO3
- B: ZnO
- C: TiO2
- D: SnO2

Mo K-alpha two-theta values were converted to Cu K-alpha by Bragg-angle
equivalence, using 0.70932 A and 1.5406 A. The measured intensities were not
altered.

## Execution

`scripts/prepare_xmatcher_database.py` generated a four-entry XMatcher database
with Cu K-alpha stick patterns. `scripts/run_xmatcher_panel.py` then:

1. verified every frozen input hash;
2. performed a preflight single-phase request and required
   `candidate_count == 4`;
3. submitted 25 requests to `/api/multiphase-match`;
4. wrote 100 query-phase ranking rows.

The request used the application defaults for peak detection and hybrid
scoring, with `max_phases=3`, `candidate_pool=4`, `top_n=10`, and 12 AutoMix
fitting peaks.

For each phase, the adapted ranking score is the maximum
`single_phase_score` among returned AutoMix combinations that contain that
phase. A phase absent from all returned combinations receives zero. This is a
deterministic output adapter for a phase-ranking benchmark; it is not a
probability and is not an estimate of phase fraction.

## Reproducibility

The 25-query run was repeated once without changing the database, parameters,
or parser. Both prediction files had SHA-256
`8d3373c73ecace8085912f79cf1729a9b30ae1c0d4c3b1ca8bbd5ec76dfc5b3a`.
Both raw-response files had SHA-256
`cb484d6f36d798a457bb80dc83eee861e2754deb9eef591aedba2d0a185d4114`.

The adapter never reads the benchmark truth table. These results support a
retrospective method-coverage analysis, not prospective validation.

