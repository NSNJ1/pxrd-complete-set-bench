# Third-party attribution

XDecomposer is distributed under the MIT License. The official source,
checkpoint release, and citation are:

- https://github.com/Licht0812/XDecomposer
- https://github.com/Licht0812/XDecomposer/releases/tag/V_0.0.1
- Gao, H., Cao, B., Su, Y., Zhang, T.-Y., and Liu, Q.
  XDecomposer: Learning Prior-Free Set Decomposition for Multiphase X-ray
  Diffraction. NeurIPS 2026. arXiv:2605.05866.

This package contains the project's adapter, candidate reference table,
predictions, and inference records. It does not redistribute the upstream
source archive or trained weights.
