# XDecomposer four-candidate external run

This directory records a label-free execution of the official XDecomposer
checkpoint on the frozen AriadneX four-candidate panel.

## Release

- Repository: https://github.com/Licht0812/XDecomposer
- Commit: `3aec2505fa7de0f0f1e8b8f01f8b1f4bc8b96bf1`
- License: MIT
- Checkpoint release tag: `V_0.0.1`
- Checkpoint archive SHA-256:
  `1a7125e2dddf2deaf29647a20d32349bd011749a2f2611e160fb519390b562b7`
- Separation checkpoint SHA-256:
  `f33186a06ddff78319e9153d18e1fc11de68c4a1eeaa84b137eefa78bce9555b`
- Encoder checkpoint SHA-256:
  `1c66067583f652a95e10f92cdc85c81137c89ffe1e1a12fbd123f85b50fcfccc`

The official source archive and checkpoint archive were retrieved from GitHub.
The application code and checkpoint files are not redistributed here.

## Input conversion

The handoff spectra are measured with Mo K-alpha radiation at 0.70932 A. Their
two-theta values were converted to Cu K-alpha at 1.5406 A by Bragg-angle
equivalence and linearly interpolated to XDecomposer's native 10-80 degree grid
with 3500 points. Intensities were max-normalized after interpolation.

`scripts/prepare_xdecomposer_references.py` generated 3500-point candidate
references from the same four frozen CIF files. Each stick pattern was
convolved with a 0.05 degree Gaussian and max-normalized. The reference table
is included as `candidate_references.csv`.

## Adaptation

XDecomposer natively returns four decomposed component patterns and four
activity logits. The frozen adapter computes cosine similarity and derivative
cosine between each component and each candidate reference, applies the
repository's top-peak penalty, and multiplies by the component activity
probability. For each candidate, the score is the maximum over the four
components. This is a ranking adapter, not a calibrated probability.

The adapter uses `alpha=0.5`, `margin=5` grid points, and the repository's
soft-mask model configuration. No parameter is tuned against the panel truth.

## Reproducibility

The 25-query run was repeated without changes. Both prediction files have
SHA-256
`1b77160bdaf82caa0f848ca18fda7ba9068038d12cc635675db2238f4b08fd73`.
Both raw-response files have SHA-256
`245452a9fdc6e57e5c6f4ba7500aec8430e1bc807ba0c2e78adbc6c83c445fe3`.

The adapter contains no truth-table input path. These results are retrospective
external-method evidence, not prospective validation.

