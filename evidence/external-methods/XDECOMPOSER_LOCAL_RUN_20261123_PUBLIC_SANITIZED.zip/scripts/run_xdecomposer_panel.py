"""Run the frozen candidate panel through the official XDecomposer checkpoint."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch

PHASES = ("A", "B", "C", "D")
MO_KALPHA = 0.70932
CU_KALPHA = 1.5406
GRID = np.linspace(10.0, 80.0, 3500)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cosine(left: np.ndarray, right: np.ndarray) -> float:
    left = left - left.mean()
    right = right - right.mean()
    denominator = np.linalg.norm(left) * np.linalg.norm(right) + 1e-8
    return float(np.dot(left, right) / denominator)


def derivative_cosine(left: np.ndarray, right: np.ndarray) -> float:
    left_difference = np.diff(left)
    right_difference = np.diff(right)
    return cosine(left_difference, right_difference)


def peak_penalty(
    predicted: np.ndarray,
    reference: np.ndarray,
    margin: int = 5,
) -> float:
    top_indices = np.argsort(reference)[-3:]
    strong_threshold = 0.1 * float(reference.max())
    valid = 0
    strong_count = 0
    for index in top_indices:
        if reference[index] < strong_threshold:
            continue
        strong_count += 1
        lower = max(0, int(index) - margin)
        upper = min(len(predicted), int(index) + margin + 1)
        if float(predicted[lower:upper].max()) > 0.05 * float(predicted.max()):
            valid += 1
    return 1.0 if valid >= min(2, strong_count) else 0.0


def mo_to_cu_two_theta(two_theta_mo: np.ndarray) -> np.ndarray:
    theta_mo = np.radians(two_theta_mo / 2.0)
    argument = (CU_KALPHA / MO_KALPHA) * np.sin(theta_mo)
    return 2.0 * np.degrees(np.arcsin(argument))


def standardize_spectrum(path: Path) -> np.ndarray:
    raw = np.loadtxt(path)
    angle_cu = mo_to_cu_two_theta(raw[:, 0])
    pattern = np.interp(GRID, angle_cu, raw[:, 1], left=0.0, right=0.0)
    maximum = float(pattern.max())
    if maximum <= 0:
        raise ValueError(f"spectrum has no positive intensity: {path}")
    return pattern / maximum


def candidate_root(manifest_path: Path, manifest: dict) -> Path:
    if manifest["spectra"][0]["path"].startswith("input/"):
        return manifest_path.parent.parent
    return manifest_path.parent


def load_checkpoints(separation_path: Path, encoder_path: Path) -> tuple[torch.nn.Module, dict]:
    from src.models.xdecomposer import build_xdecomposer
    from src.models.xrd_transformer import XRDMaskedAutoencoder

    separation = torch.load(
        separation_path,
        map_location="cpu",
        weights_only=False,
    )
    encoder = torch.load(
        encoder_path,
        map_location="cpu",
        weights_only=False,
    )
    separation_config = separation["config"]
    encoder_config = encoder["config"]
    masked_encoder = XRDMaskedAutoencoder(
        xrd_length=separation_config["xrd_length"],
        d_model=encoder_config["d_model"],
        n_layers=encoder_config["n_layers"],
        n_heads=encoder_config["n_heads"],
        decoder_d_model=encoder_config["decoder_dim"],
        decoder_n_layers=encoder_config["decoder_layers"],
    )
    model = build_xdecomposer(
        masked_encoder,
        num_sources=separation_config["num_phases"],
        cnn_channels=separation_config["cnn_channels"],
        cnn_kernels=separation_config["cnn_kernels"],
        cnn_strides=separation_config["cnn_strides"],
        use_transformer=True,
        use_film=True,
        use_skip_connections=True,
        mask_type="soft",
    )
    state = {
        key.removeprefix("module."): value
        for key, value in separation["model_state_dict"].items()
    }
    model.load_state_dict(state)
    model.eval()
    metadata = {
        "num_sources": int(separation_config["num_phases"]),
        "xrd_length": int(separation_config["xrd_length"]),
        "separation_epoch": int(separation["epoch"]),
        "encoder_epoch": int(encoder["epoch"]),
    }
    return model, metadata


def candidate_scores(
    predictions: np.ndarray,
    activities: np.ndarray,
    references: dict[str, np.ndarray],
    alpha: float,
    margin: int,
) -> tuple[dict[str, float], list[dict]]:
    scores = {phase: float("-inf") for phase in PHASES}
    details = []
    for slot in range(predictions.shape[0]):
        predicted = predictions[slot]
        for phase in PHASES:
            reference = references[phase]
            similarity = cosine(predicted, reference)
            derivative = derivative_cosine(predicted, reference)
            penalty = peak_penalty(predicted, reference, margin=margin)
            score = float(
                activities[slot]
                * (alpha * similarity + (1.0 - alpha) * derivative)
                * penalty
            )
            scores[phase] = max(scores[phase], score)
            details.append(
                {
                    "slot": slot,
                    "phase_id": phase,
                    "activity": float(activities[slot]),
                    "cosine": similarity,
                    "derivative_cosine": derivative,
                    "peak_penalty": penalty,
                    "score": score,
                }
            )
    return scores, details


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--references", type=Path, required=True)
    parser.add_argument("--xdecomposer-root", type=Path, required=True)
    parser.add_argument("--separation-checkpoint", type=Path, required=True)
    parser.add_argument("--encoder-checkpoint", type=Path, required=True)
    parser.add_argument("--predictions-out", type=Path, required=True)
    parser.add_argument("--raw-out", type=Path, required=True)
    parser.add_argument("--alpha", type=float, default=0.5)
    parser.add_argument("--margin", type=int, default=5)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()

    torch.set_num_threads(args.threads)
    sys.path.insert(0, str(args.xdecomposer_root))
    model, model_metadata = load_checkpoints(
        args.separation_checkpoint,
        args.encoder_checkpoint,
    )

    reference_frame = np.loadtxt(args.references, delimiter=",", skiprows=1)
    if reference_frame.shape[1] != 5:
        raise ValueError("candidate reference table must contain angle and A-D")
    if not np.allclose(reference_frame[:, 0], GRID):
        raise ValueError("candidate reference table is not on the frozen grid")
    references = {
        phase: reference_frame[:, index + 1]
        for index, phase in enumerate(PHASES)
    }

    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    root = candidate_root(args.manifest, manifest)
    input_hashes = []
    for record in manifest["candidates"] + manifest["spectra"]:
        path = root / record["path"]
        observed = sha256(path)
        if observed != record["sha256"]:
            raise ValueError(f"input hash mismatch: {path}")
        input_hashes.append({"path": record["path"], "sha256": observed})

    rows = []
    raw = {}
    for spectrum in manifest["spectra"]:
        pattern = standardize_spectrum(root / spectrum["path"])
        tensor = torch.tensor(pattern, dtype=torch.float32).reshape(1, 1, -1)
        with torch.no_grad():
            predictions, activity_logits = model(tensor)
        predicted = predictions[0].numpy()
        activities = torch.sigmoid(activity_logits)[0].numpy()
        scores, details = candidate_scores(
            predicted,
            activities,
            references,
            alpha=args.alpha,
            margin=args.margin,
        )
        raw[spectrum["query_id"]] = {
            "activities": activities.tolist(),
            "scores": scores,
            "slot_candidate_details": details,
        }
        for phase in PHASES:
            rows.append(
                {
                    "method_id": "xdecomposer",
                    "query_id": spectrum["query_id"],
                    "phase_id": phase,
                    "score": scores[phase],
                }
            )

    rows.sort(key=lambda row: (row["query_id"], row["phase_id"]))
    args.predictions_out.parent.mkdir(parents=True, exist_ok=True)
    text = "method_id,query_id,phase_id,score\n" + "".join(
        f"{row['method_id']},{row['query_id']},{row['phase_id']},{row['score']:.17g}\n"
        for row in rows
    )
    args.predictions_out.write_text(text, encoding="utf-8", newline="")
    args.raw_out.write_text(
        json.dumps(
            {
                "status": "xdecomposer_panel_complete",
                "method_id": "xdecomposer",
                "claim_boundary": (
                    "Retrospective label-blind execution on a frozen four-candidate "
                    "panel; this is adapted native decomposition output, not a "
                    "prospective validation."
                ),
                "execution": {
                    "repository": "https://github.com/Licht0812/XDecomposer",
                    "commit": "3aec2505fa7de0f0f1e8b8f01f8b1f4bc8b96bf1",
                    "license": "MIT",
                    "checkpoint_archive_sha256": "1a7125e2dddf2deaf29647a20d32349bd011749a2f2611e160fb519390b562b7",
                    "model": model_metadata,
                    "adaptation": (
                        "The model outputs four decomposed components. Each component "
                        "is scored against the four frozen candidate references by "
                        "cosine, derivative cosine and a top-peak penalty. The phase "
                        "score is the maximum activity-weighted slot score. Scores "
                        "are ranking evidence, not probabilities."
                    ),
                    "alpha": args.alpha,
                    "peak_margin_grid_points": args.margin,
                    "radiation_conversion": (
                        "Mo K-alpha 0.70932 A to Cu K-alpha 1.5406 A, then "
                        "linear interpolation to the fixed 10-80 degree grid"
                    ),
                    "input_hashes": input_hashes,
                    "reference_sha256": sha256(args.references),
                    "separation_checkpoint_sha256": sha256(
                        args.separation_checkpoint
                    ),
                    "encoder_checkpoint_sha256": sha256(args.encoder_checkpoint),
                },
                "responses": raw,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"wrote {len(rows)} predictions")
    print(f"predictions_sha256={sha256(args.predictions_out)}")
    print(f"raw_sha256={sha256(args.raw_out)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
