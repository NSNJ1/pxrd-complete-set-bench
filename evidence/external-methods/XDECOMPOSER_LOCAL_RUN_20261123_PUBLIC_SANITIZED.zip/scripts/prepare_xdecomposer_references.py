"""Build 3500-point candidate references for the XDecomposer adapter."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def profile_from_sticks(
    positions: np.ndarray,
    intensities: np.ndarray,
    grid: np.ndarray,
    sigma: float,
) -> np.ndarray:
    profile = np.zeros_like(grid)
    for position, intensity in zip(positions, intensities):
        profile += intensity * np.exp(-0.5 * ((grid - position) / sigma) ** 2)
    maximum = float(profile.max())
    if maximum <= 0:
        raise ValueError("candidate reference has no intensity on the target grid")
    return profile / maximum


def candidate_root(manifest_path: Path, manifest: dict) -> Path:
    if manifest["candidates"][0]["path"].startswith("input/"):
        return manifest_path.parent.parent
    return manifest_path.parent


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--points", type=int, default=3500)
    parser.add_argument("--sigma", type=float, default=0.05)
    args = parser.parse_args()

    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    root = candidate_root(args.manifest, manifest)
    grid = np.linspace(10.0, 80.0, args.points)
    columns = [grid]
    audit = []
    calculator = XRDCalculator(wavelength=1.5406)
    for candidate in manifest["candidates"]:
        path = root / candidate["path"]
        if sha256(path) != candidate["sha256"]:
            raise ValueError(f"candidate hash mismatch: {path}")
        structure = CifParser(str(path)).parse_structures(primitive=False)[0]
        pattern = calculator.get_pattern(
            structure,
            two_theta_range=(10.0, 80.0),
            scaled=True,
        )
        profile = profile_from_sticks(pattern.x, pattern.y, grid, args.sigma)
        columns.append(profile)
        audit.append(
            {
                "phase_id": candidate["phase_id"],
                "formula": candidate["formula"],
                "cif_sha256": candidate["sha256"],
                "peaks_on_grid": int(len(pattern.x)),
                "reference_max": float(profile.max()),
            }
        )

    frame = np.column_stack(columns)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.savetxt(
        args.out,
        frame,
        delimiter=",",
        header="angle,A,B,C,D",
        comments="",
        fmt="%.10g",
    )
    print(f"wrote {args.out}")
    print(f"sha256={sha256(args.out)}")
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
