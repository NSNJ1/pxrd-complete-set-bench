# Evidence sanitization notice

Original evidence SHA-256: `0801d3928376e369f2c8263db440b77f6232bf81f79c86f3175fca357bb67a89`

Windows user-profile components and credential-like strings were replaced in text artifacts. Recorded scientific outputs, source commits, environment locks, exit codes and method parameters were not changed.
