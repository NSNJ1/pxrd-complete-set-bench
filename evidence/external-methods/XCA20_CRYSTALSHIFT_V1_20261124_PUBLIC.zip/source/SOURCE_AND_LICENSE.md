# Source and licence

- Paper DOI: `10.1038/s43588-021-00059-2`
- Query repository: `https://github.com/bnl/pub-Maffettone_2020_08`
- Query commit: `a7024480137b39bf396ccda2474bdf4304b21f4a`
- Repository licence: BSD-3-Clause
- The 31 source CIFs and measured TFRecord are included unchanged.
- The benchmark uses these records retrospectively. The cohort was already
  consumed by the project's broader source-stratified analysis.
