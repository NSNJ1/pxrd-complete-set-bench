# XCA 20-family CrystalShift stress result

## Scope

This is a 30-query, 20-family, 31-structure retrospective panel from the
already consumed XCA Ni-Co-Al measured thin-film cohort. The selected queries
contain 18 single-phase and 12 two-phase examples. CrystalShift was locally
adapted; this is not a fresh holdout or prospective experiment.

## Results

| Method | Phase AP | Top-1 has a true phase | all@3 | all@5 |
| --- | ---: | ---: | ---: | ---: |
| Random | 16.3% | 6.7% | 0.0% | 10.0% |
| Global Pearson | 63.9% | 60.0% | 53.3% | 53.3% |
| Eight-window Pearson | 63.3% | 46.7% | 60.0% | 70.0% |
| Released XCA vector | 54.2% | 40.0% | 46.7% | 60.0% |
| CrystalShift adapted | 30.0% | 0.0% | 30.0% | 53.3% |

CrystalShift minus eight-window Pearson:

- phase AP: -0.3330;
- 95% interval: -0.4534 to
  -0.1769;
- all-present@3: -30.0 percentage
  points;
- all-present@3 interval: -51.9 to
  -4.0 percentage points.

The same direction holds against global Pearson. This is evidence that a more
complex external phase-combination method is not automatically stronger than a
simple profile-similarity baseline when the task is a 20-family review
shortlist.

## Reproduction

The first and second formal runs produced byte-identical method outputs:

- predictions SHA-256:
  `e44f3d44b22d2ba47ba515f15ac2dbdb9efb1de2c782ddf89d125b0883aa841d`;
- sets SHA-256:
  `05ea2d28d60b12f679c5fb725ec316a73c888cb7e6371cbbcf969f4dfde38a76`;
- evaluation SHA-256:
  `39575355eb4a331cd23af642f4c2b73d79b586dbdbd16a98f48bd1b67fcd2a8b`.

Julia emitted a `SparseArraysExt` extension warning; all 30 queries completed
and the process exited with code 0.

## Claim limits

The cohort is thin-film data, not random powders. The selected set has 11
expert-label clusters, so intervals remain wide. No three-phase query entered
the frozen subset. These results support second-source robustness of the
20-candidate diagnostic, not a universal leaderboard claim.
