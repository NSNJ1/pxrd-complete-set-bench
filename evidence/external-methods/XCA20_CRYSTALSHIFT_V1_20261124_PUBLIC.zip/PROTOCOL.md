# XCA 20-family CrystalShift stress panel

Status: frozen before the CrystalShift run  
Freeze date: 2026-11-24  
Source: XCA Ni-Co-Al released measured thin-film patterns  
Claim type: retrospective second-source-family stress test

## Why this panel exists

The controlled AriadneX panel uses four candidates, and the RealBind stress
panel is single phase. Neither establishes how one external implementation
behaves in a 20-candidate multiphase library. This panel holds the candidate
count near the smallest realistic phase-library setting and uses a source
family that is distinct from RealBind/opXRD.

The XCA cohort was already consumed in the project's broader source-stratified
analysis. This panel is therefore not a fresh holdout and cannot be called
prospective validation.

## Inputs

- measured patterns: `NiCoAl.tfrecords`;
- 31 official reference CIFs from the source repository;
- 20 candidate phase families after applying the source's frozen family map;
- precomputed project baseline scores for the same cohort;
- CrystalShift commit `c4884ca1dbbd78135cd50f5e17141cdc0b6f43c8`;
- Cu K-alpha wavelength `1.54060 A`.

The public handoff contains only:

- 30 label-blind selected spectra;
- query identifiers, radiation and wavelength;
- candidate CIFs and family identifiers.

Labels, source filenames and target families are evaluator-side files.

## Query selection

Selection is independent of model output and phase cardinality:

```text
sha256("20261125|query_selection|" + source_name)
```

The first 30 source records in ascending digest order are retained. Public
query IDs are then assigned in a separate digest order:

```text
sha256("20261125|query_order|" + source_name)
```

Candidate display order is also independent:

```text
sha256("20261125|candidate_order|" + CIF stem)
```

The realized 1/2/3-phase distribution is reported after selection. It is not
rebalanced based on method results.

## Candidate-family contract

Each of the 31 official CIF variants belongs to one of the 20 source phase
families. CrystalShift scores every structure variant. A family receives the
maximum inclusion score among its variants. All methods are evaluated on the
same 20-family library.

## Methods

- deterministic random ranking, seed `20261124`;
- global square-root Pearson scores frozen in the XCA baseline table;
- eight-window square-root Pearson scores frozen in the XCA baseline table;
- the source authors' released XCA XRD-only probability vector;
- adapted CrystalShift.

The first three project/source baselines were computed previously on the full
XCA cohort. Their family-level scores are subset to the selected 30 queries;
they were not refit after CrystalShift.

Adapted CrystalShift settings:

- Gauss profile, `width_init=0.1`;
- `max_depth=3`;
- `k_expand=3`;
- `std_noise=0.01`;
- `mean_theta=[1.0, 0.5, 0.5]`;
- `std_theta=[0.1, 0.05, 0.1]`;
- LM, `maxiter=32`, regularization and Simple mode;
- `normalization_constant=2.5`;
- equal scores use the conservative/worst rank.

## Endpoints

- phase AP macro;
- top-1 contains a true phase;
- mean reciprocal rank of the best true phase;
- all-present@1, 2, 3 and 5;
- mean minimum review budget containing every true phase.

The primary comparison is CrystalShift minus eight-window Pearson. Secondary
comparisons are CrystalShift minus global Pearson and CrystalShift minus the
released XCA vector.

Interval estimation resamples the expert phase-region label as a cluster with
replacement for 10,000 repeats, seed `20261124`. Repeated clusters receive
their proper multiplicity.

## Claim boundary

This is a small retrospective stress test on an already consumed measured
thin-film cohort. It can test whether the 20-candidate finding survives one
additional source family. It cannot establish:

- prospective performance;
- random-powder generalization, because these are textured films;
- quantitative phase fractions;
- universal state of the art;
- a stable community leaderboard.
