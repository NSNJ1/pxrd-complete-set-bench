"""Prepare a label-blind XCA 20-family CrystalShift panel.

The public handoff contains measured profiles and candidate structures, but no
query labels or source-to-target mapping. Evaluator-side files are written
separately.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
from tfrecord.reader import tfrecord_loader

SEED = 20261125
PANEL_SIZE = 30
TWO_THETA_MIN = 20.0
TWO_THETA_MAX = 89.93999843671914
POINT_COUNT = 3498
WAVELENGTH_ANGSTROM = 1.54060


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(seed: int, role: str, value: str) -> str:
    payload = f"{seed}|{role}|{value}".encode()
    return hashlib.sha256(payload).hexdigest()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load_queries(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    seen: set[str] = set()
    for record in tfrecord_loader(str(path), None):
        source_name = record["source_fname"].decode("utf-8")
        label = record["str_label"].decode("utf-8")
        values = np.frombuffer(record["X_raw"], dtype="<f4")
        if len(values) != POINT_COUNT:
            raise ValueError(f"{source_name}: expected {POINT_COUNT} points")
        if source_name in seen:
            raise ValueError(f"duplicate source identity: {source_name}")
        seen.add(source_name)
        rows.append(
            {
                "source_name": source_name,
                "query_id": Path(source_name).stem,
                "label": label.replace("/", ","),
                "intensity": values.astype(np.float64),
            }
        )
    if len(rows) != 342:
        raise ValueError(f"expected 342 XCA records, found {len(rows)}")
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tfrecord", type=Path, required=True)
    parser.add_argument("--cif-dir", type=Path, required=True)
    parser.add_argument("--mapping-json", type=Path, required=True)
    parser.add_argument("--baseline-scores", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    mapping_record = json.loads(args.mapping_json.read_text(encoding="utf-8"))
    mapping = {
        cif_stem: family_id.replace(",", ";")
        for cif_stem, family_id in mapping_record["cohort"][
            "reference_family_mapping"
        ].items()
    }
    queries = load_queries(args.tfrecord)

    selected = sorted(
        queries,
        key=lambda row: digest(SEED, "query_selection", str(row["source_name"])),
    )[:PANEL_SIZE]
    selected = sorted(
        selected,
        key=lambda row: digest(SEED, "query_order", str(row["source_name"])),
    )

    cif_paths = sorted(args.cif_dir.glob("*.cif"))
    if len(cif_paths) != 31:
        raise ValueError(f"expected 31 official CIFs, found {len(cif_paths)}")
    missing = sorted(path.stem for path in cif_paths if path.stem not in mapping)
    if missing:
        raise ValueError(f"missing family mapping for: {missing}")
    cif_paths = sorted(
        cif_paths,
        key=lambda path: digest(SEED, "candidate_order", path.stem),
    )

    public_dir = args.out_dir / "public"
    evaluator_dir = args.out_dir / "evaluator"
    spectra_dir = public_dir / "spectra"
    structure_dir = public_dir / "cif"
    spectra_dir.mkdir(parents=True, exist_ok=True)
    structure_dir.mkdir(parents=True, exist_ok=True)
    evaluator_dir.mkdir(parents=True, exist_ok=True)

    candidate_rows: list[dict[str, object]] = []
    candidate_id_by_cif: dict[str, str] = {}
    for position, path in enumerate(cif_paths, start=1):
        candidate_id = f"xca20v1_s{position:02d}"
        copied_path = structure_dir / f"{candidate_id}.cif"
        shutil.copyfile(path, copied_path)
        candidate_id_by_cif[path.stem] = candidate_id
        candidate_rows.append(
            {
                "phase_id": candidate_id,
                "cif_file": f"cif/{candidate_id}.cif",
                "family_id": mapping[path.stem],
                "source_cif": path.name,
                "sha256": sha256(copied_path),
            }
        )

    two_theta = np.linspace(TWO_THETA_MIN, TWO_THETA_MAX, POINT_COUNT)
    query_rows: list[dict[str, object]] = []
    target_rows: list[dict[str, object]] = []
    for row in selected:
        query_id = f"xca20v1_q{len(query_rows) + 1:02d}"
        intensity = np.asarray(row["intensity"], dtype=np.float64)
        intensity = np.clip(intensity, 0.0, None)
        maximum = float(intensity.max())
        if maximum <= 0.0:
            raise ValueError(f"{row['source_name']}: empty intensity")
        intensity = intensity / maximum
        spectrum_path = spectra_dir / f"{query_id}.xy"
        spectrum_path.write_text(
            "".join(
                f"{x:.10f} {y:.12g}\n"
                for x, y in zip(two_theta, intensity, strict=True)
            ),
            encoding="utf-8",
            newline="\n",
        )
        positive_families = sorted(
            {family_id.replace(",", ";") for family_id in str(row["label"]).split("+")}
        )
        query_rows.append(
            {
                "query_id": query_id,
                "spectrum_file": f"spectra/{query_id}.xy",
                "radiation": "Cu",
                "wavelength_angstrom": WAVELENGTH_ANGSTROM,
            }
        )
        target_rows.append(
            {
                "query_id": query_id,
                "source_name": row["source_name"],
                "label": row["label"],
                "positive_families": "|".join(positive_families),
                "positive_count": len(positive_families),
            }
        )

    write_csv(public_dir / "candidates.csv", candidate_rows)
    write_csv(public_dir / "queries.csv", query_rows)
    write_csv(evaluator_dir / "query_targets.csv", target_rows)
    selected_sources = {str(row["source_name"]) for row in target_rows}
    baseline = pd.read_csv(args.baseline_scores)
    baseline = baseline.loc[baseline["source_fname"].isin(selected_sources)].copy()
    if set(baseline["source_fname"]) != selected_sources:
        raise ValueError("baseline score table does not cover the selected queries")
    baseline.to_csv(
        evaluator_dir / "baseline_scores.csv",
        index=False,
        lineterminator="\n",
    )
    (args.out_dir / "selection.json").write_text(
        json.dumps(
            {
                "status": "xca20_v1_selection_frozen",
                "seed": SEED,
                "panel_size": PANEL_SIZE,
                "source_tfrecord_sha256": sha256(args.tfrecord),
                "family_mapping_sha256": sha256(args.mapping_json),
                "baseline_scores_sha256": sha256(args.baseline_scores),
                "candidate_count": len(candidate_rows),
                "candidate_family_count": len(
                    {row["family_id"] for row in candidate_rows}
                ),
                "candidate_order": [
                    {
                        "phase_id": row["phase_id"],
                        "source_cif": row["source_cif"],
                        "family_id": row["family_id"],
                    }
                    for row in candidate_rows
                ],
                "query_order": target_rows,
                "selection_rule": (
                    "Take 30 query records by ascending SHA-256 of "
                    "seed|query_selection|source_name; then give public query "
                    "identifiers in a separate SHA-256 order. Labels are not "
                    "used by either ordering rule."
                ),
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    counts = {
        str(count): sum(row["positive_count"] == count for row in target_rows)
        for count in sorted({row["positive_count"] for row in target_rows})
    }
    print(
        json.dumps(
            {
                "status": "xca20_v1_prepared",
                "queries": len(query_rows),
                "structures": len(candidate_rows),
                "families": len({row["family_id"] for row in candidate_rows}),
                "positive_count_distribution": counts,
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
