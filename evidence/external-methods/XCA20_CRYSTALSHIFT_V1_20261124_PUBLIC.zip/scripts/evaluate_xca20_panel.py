"""Evaluate XCA family ranking for the frozen label-blind 30-query panel."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

SEED = 20261124
BOOTSTRAP_REPEATS = 10_000
BUDGETS = (1, 2, 3, 5)
BASELINE_COLUMNS = {
    "global_sqrt_pearson": "sqrt_global_pearson",
    "window_sqrt_pearson": "sqrt_window_pearson",
    "source_xca_xrd_only": "source_xca_xrd_only",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def random_scores(source_name: str, family_ids: list[str]) -> np.ndarray:
    values = []
    for family_id in family_ids:
        payload = f"{SEED}|{source_name}|{family_id}".encode()
        digest = hashlib.sha256(payload).digest()
        values.append(int.from_bytes(digest[:8], "big") / (2**64 - 1))
    return np.asarray(values, dtype=np.float64)


def conservative_rank(scores: np.ndarray, present: np.ndarray) -> int:
    positive_scores = scores[present.astype(bool)]
    if len(positive_scores) == 0:
        raise ValueError("query has no positive family")
    worst_positive = float(positive_scores.min())
    return int((scores >= worst_positive).sum())


def best_positive_rank(scores: np.ndarray, present: np.ndarray) -> int:
    positive_scores = scores[present.astype(bool)]
    if len(positive_scores) == 0:
        raise ValueError("query has no positive family")
    best_positive = float(positive_scores.max())
    return int((scores > best_positive).sum() + 1)


def percentile(values: np.ndarray) -> list[float]:
    return [
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    ]


def query_metrics(
    scores: np.ndarray,
    labels: np.ndarray,
) -> dict[str, float]:
    minimum_budget = conservative_rank(scores, labels)
    best_rank = best_positive_rank(scores, labels)
    return {
        "phase_ap": float(average_precision_score(labels, scores)),
        "top1_present": float(best_rank == 1),
        "best_positive_reciprocal_rank": float(1.0 / best_rank),
        "minimum_all_present_budget": float(minimum_budget),
        **{
            f"all_present_at_{budget}": float(minimum_budget <= budget)
            for budget in BUDGETS
        },
    }


def summarize(values: pd.DataFrame, method: str) -> dict[str, float]:
    return {
        "phase_ap_macro": float(values[f"phase_ap__{method}"].mean()),
        "top1_present": float(values[f"top1_present__{method}"].mean()),
        "best_positive_mrr": float(
            values[f"best_positive_reciprocal_rank__{method}"].mean()
        ),
        **{
            f"all_present_at_{budget}": float(
                values[f"all_present_at_{budget}__{method}"].mean()
            )
            for budget in BUDGETS
        },
        "mean_minimum_all_present_budget": float(
            values[f"minimum_all_present_budget__{method}"].mean()
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    public_dir = args.dataset / "public"
    evaluator_dir = args.dataset / "evaluator"
    candidates = pd.read_csv(public_dir / "candidates.csv")
    targets = pd.read_csv(evaluator_dir / "query_targets.csv")
    baseline_scores_path = evaluator_dir / "baseline_scores.csv"
    predicted = pd.read_csv(args.predictions)

    family_ids = sorted(candidates["family_id"].unique())
    if len(family_ids) != 20:
        raise ValueError(f"expected 20 candidate families, found {len(family_ids)}")
    candidate_family = dict(
        zip(candidates["phase_id"], candidates["family_id"], strict=True)
    )
    if predicted.duplicated(["query_id", "phase_id"]).any():
        raise ValueError("duplicate CrystalShift prediction")
    expected_query_ids = set(targets["query_id"])
    expected_phase_ids = set(candidates["phase_id"])
    if set(predicted["query_id"]) != expected_query_ids:
        raise ValueError("CrystalShift query coverage does not match")
    if set(predicted["phase_id"]) != expected_phase_ids:
        raise ValueError("CrystalShift candidate coverage does not match")
    if len(predicted) != len(targets) * len(candidates):
        raise ValueError("CrystalShift prediction grid is incomplete")

    baseline = pd.read_csv(baseline_scores_path)
    baseline["family"] = baseline["family"].str.replace(",", ";", regex=False)
    baseline = baseline.loc[baseline["family"].isin(family_ids)].copy()
    baseline_by_source = {
        source_name: group.set_index("family")
        for source_name, group in baseline.groupby("source_fname", sort=False)
    }
    family_position = {
        family_id: position for position, family_id in enumerate(family_ids)
    }
    query_position = {
        query_id: position for position, query_id in enumerate(targets["query_id"])
    }
    crystalshift_family = np.full(
        (len(targets), len(family_ids)),
        -np.inf,
        dtype=np.float64,
    )
    for row in predicted.itertuples(index=False):
        position = family_position[candidate_family[row.phase_id]]
        crystalshift_family[query_position[row.query_id], position] = max(
            crystalshift_family[query_position[row.query_id], position],
            float(row.score),
        )
    if not np.isfinite(crystalshift_family).all():
        raise ValueError("family aggregation left a missing score")

    matrices = {
        "deterministic_random": np.stack(
            [
                random_scores(str(row.source_name), family_ids)
                for row in targets.itertuples(index=False)
            ]
        ),
        "crystalshift_adapted_20": crystalshift_family,
    }
    for method, column in BASELINE_COLUMNS.items():
        matrix = np.empty((len(targets), len(family_ids)), dtype=np.float64)
        for query_index, row in enumerate(targets.itertuples(index=False)):
            source_scores = baseline_by_source.get(str(row.source_name))
            if source_scores is None:
                raise ValueError(f"missing baseline row for {row.source_name}")
            for candidate_index, family_id in enumerate(family_ids):
                matrix[query_index, candidate_index] = float(
                    source_scores.at[family_id, column]
                )
        matrices[method] = matrix

    label_matrix = np.zeros((len(targets), len(family_ids)), dtype=np.int8)
    for query_index, row in enumerate(targets.itertuples(index=False)):
        positive = set(str(row.positive_families).split("|"))
        for family_id in positive:
            if family_id not in family_position:
                raise ValueError(f"unknown positive family: {family_id}")
            label_matrix[query_index, family_position[family_id]] = 1
    if np.any(label_matrix.sum(axis=1) == 0):
        raise ValueError("a selected query has no positive label")

    query_rows: list[dict[str, object]] = []
    for query_index, row in enumerate(targets.itertuples(index=False)):
        metrics: dict[str, object] = {
            "query_id": row.query_id,
            "source_name": row.source_name,
            "label": row.label,
            "cluster_id": row.label,
            "positive_count": int(row.positive_count),
        }
        for method, matrix in matrices.items():
            values = query_metrics(matrix[query_index], label_matrix[query_index])
            metrics.update(
                {f"{name}__{method}": value for name, value in values.items()}
            )
        query_rows.append(metrics)
    query_table = pd.DataFrame(query_rows)

    methods = {method: summarize(query_table, method) for method in matrices}
    clusters = np.asarray(query_table["cluster_id"].astype(str))
    unique_clusters = np.unique(clusters)
    cluster_indices = {
        cluster: np.flatnonzero(clusters == cluster) for cluster in unique_clusters
    }
    rng = np.random.default_rng(SEED)
    selected_clusters = rng.choice(
        unique_clusters,
        size=(BOOTSTRAP_REPEATS, len(unique_clusters)),
        replace=True,
    )
    bootstrap_samples = {
        method: {endpoint: np.empty(BOOTSTRAP_REPEATS) for endpoint in methods[method]}
        for method in methods
    }
    metric_columns = {
        "phase_ap_macro": "phase_ap",
        "top1_present": "top1_present",
        "best_positive_mrr": "best_positive_reciprocal_rank",
        **{
            f"all_present_at_{budget}": f"all_present_at_{budget}" for budget in BUDGETS
        },
        "mean_minimum_all_present_budget": "minimum_all_present_budget",
    }
    endpoint_columns = {
        method: {
            endpoint: f"{metric_columns[endpoint]}__{method}"
            for endpoint in methods[method]
        }
        for method in methods
    }
    for repeat, sampled in enumerate(selected_clusters):
        sample_indices = np.concatenate(
            [cluster_indices[cluster] for cluster in sampled]
        )
        for method, columns in endpoint_columns.items():
            for endpoint, column in columns.items():
                bootstrap_samples[method][endpoint][repeat] = float(
                    query_table.iloc[sample_indices][column].mean()
                )
    for method, method_result in methods.items():
        method_result["bootstrap_ci95"] = {
            endpoint: percentile(samples)
            for endpoint, samples in bootstrap_samples[method].items()
        }

    comparisons = {}
    for left in (
        "crystalshift_adapted_20",
        "window_sqrt_pearson",
        "source_xca_xrd_only",
    ):
        right = (
            "window_sqrt_pearson"
            if left == "crystalshift_adapted_20"
            else "global_sqrt_pearson"
        )
        comparisons[f"{left}_minus_{right}"] = {
            endpoint: {
                "estimate": methods[left][endpoint] - methods[right][endpoint],
                "ci95": percentile(
                    bootstrap_samples[left][endpoint]
                    - bootstrap_samples[right][endpoint]
                ),
            }
            for endpoint in methods[left]
            if endpoint != "bootstrap_ci95"
        }

    report = {
        "status": "xca20_crystalshift_evaluated",
        "claim_boundary": (
            "Retrospective 30-query subset of an already consumed measured "
            "thin-film source. CrystalShift was locally adapted. This is not a "
            "fresh holdout, prospective validation, or universal SOTA result."
        ),
        "contract": {
            "queries": len(targets),
            "candidate_families": len(family_ids),
            "candidate_structures": len(candidates),
            "bootstrap_repeats": BOOTSTRAP_REPEATS,
            "bootstrap_clusters": len(unique_clusters),
            "seed": SEED,
            "tie_rule": "conservative",
        },
        "inputs": {
            "source_tfrecord_sha256": json.loads(
                (args.dataset / "selection.json").read_text(encoding="utf-8")
            )["source_tfrecord_sha256"],
            "selection_sha256": sha256(args.dataset / "selection.json"),
            "predictions_sha256": sha256(args.predictions),
            "baseline_scores_sha256": sha256(baseline_scores_path),
            "protocol_sha256": sha256(args.protocol),
        },
        "query_distribution": {
            str(count): int((query_table["positive_count"] == count).sum())
            for count in sorted(query_table["positive_count"].unique())
        },
        "methods": methods,
        "paired_deltas": comparisons,
    }
    args.out.mkdir(parents=True, exist_ok=True)
    query_table.to_csv(
        args.out / "query_metrics.csv",
        index=False,
        lineterminator="\n",
    )
    (args.out / "evaluation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"evaluation_sha256={sha256(args.out / 'evaluation.json')}")
    print(f"query_metrics_sha256={sha256(args.out / 'query_metrics.csv')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
