# Public evidence package

## What to give a method executor

Only the `public/` directory is the label-blind handoff. It contains query
spectra, candidate structures, a candidate table and precomputed candidate
sticks where applicable.

Do not give a new executor `evaluator/`, `source/`, `results/` or
`reproduction/` before the run. Those directories contain labels or method
outputs and are included here for post-run audit and exact replay.

## Reproducibility layers

1. regenerate the public panel from the included source with `scripts/`;
2. run the frozen external method from `public/` only;
3. compare method output against `results/`;
4. rescore against `evaluator/` and compare with `REPRODUCTION_CHECK.json`.

`FILE_MANIFEST.json` hashes every file except the manifest itself.
