# DeltaXRDbench fresh-release 20-candidate replay

Status: frozen before method execution  
Freeze date: 2026-11-24  
External release: DeltaXRDbench dataset v1.1.0  
Archive SHA-256:
`815cf737fe9166ec4e83e0aec91b01854ab4fc6cfeac481e83110bdf7de390b`

## Why this test exists

DeltaXRDbench is a new external benchmark release that this project has not
previously consumed. We use its released experimental-profile mixture tracks to
test the project's fixed-candidate review question. This is not an independent
field collection: the RRUFF and opXRD lineages overlap with sources used
elsewhere in the project. It is also not a prospective physical-mixing
experiment. DeltaXRDbench explicitly states that its mixtures are constructed
from measured source patterns and do not reproduce every effect of a physically
mixed specimen.

The test therefore asks a narrower question:

> When a new external benchmark release supplies frozen two- and three-phase
> queries, measured-source peak complexity and hidden CIF truth, do the
> 20-candidate conclusions survive?

## Sources

- `rruff-Cu`: measured RRUFF source profiles;
- `opxrd-Cu`: measured opXRD source profiles;
- 30 mixture queries selected independently from each source;
- all positive reference CIFs supplied in the release manifest;
- 20 candidate structures per query.

A structure is eligible only when the released CIF can be parsed and the
standardized structure has at most 100 atoms. This follows the common
small-structure limit used by recent PXRD benchmark implementations and avoids
making runtime depend on pathological unit cells. A mixture query is eligible
only when every positive structure passes this structural filter. Eligibility is
determined without reference-pattern or method scores.

The raw measured patterns and source CIFs remain under their provider terms and
are not redistributed in the public evidence package. The public package
contains only record hashes, selection rules, derived spectra required by the
licence, and aggregate method outputs unless source terms explicitly permit
redistribution.

## Query selection

Only structurally eligible records with `task = identification.multi` are
eligible.

```text
score = sha256("20261126|query_selection|" + sample_id)
```

Take the first 30 query records per source in ascending score order. Assign
public query identifiers in a separate hash order. The selection does not use
phase cardinality, phase identity, mixture fractions or method output.

The observed 2/3-phase distribution is reported after selection without
rebalancing.

## Candidate-library construction

For query \(q\), include every released positive CIF. Add negative CIFs sampled
without replacement from the eligible unique structure pool of the same source
until the library has exactly 20 structures. Selected CIFs are rewritten through
the same parser to a standardized, runnable representation.

Negative priority:

```text
sha256("20261126|negative_selection|" + query_id + "|" + phase_id)
```

Candidate display order is independently hashed:

```text
sha256("20261126|candidate_order|" + query_id + "|" + phase_id)
```

Source UIDs and answer-side mappings are removed from the public query table.

## Methods

- deterministic random ranking, seed `20261124`;
- global square-root Pearson;
- eight-window square-root Pearson;
- adapted CrystalShift.jl at commit
  `c4884ca1dbbd78135cd50f5e17141cdc0b6f43c8`.

Reference patterns for Pearson baselines use pymatgen XRDCalculator with Cu
Ka1 `1.54060 A`, Cu Ka2 `1.54439 A` in a 2:1 amplitude ratio, and Gaussian
FWHM `0.1 degrees`.

CrystalShift uses Cu Ka1 `1.54060 A`, Gauss `width_init=0.1`,
`max_depth=3`, `k_expand=3`, `std_noise=0.01`,
`mean_theta=[1.0,0.5,0.5]`, `std_theta=[0.1,0.05,0.1]`,
LM with `maxiter=32`, regularization, Simple mode and
`normalization_constant=2.5`.

All ties use conservative/worst rank.

## Endpoints

Primary:

- phase AP macro;
- all-present@3.

Secondary:

- top-1 contains a true phase;
- best-positive reciprocal rank;
- all-present@1, 2 and 5;
- mean minimum review budget covering every positive.

Paired query-level bootstrap uses 10,000 repeats and seed `20261124`.

## Acceptance

- both source panels contain exactly 30 queries;
- every query contains exactly 20 candidates;
- every released positive is represented by its exact CIF identity;
- every method has a complete 600-score grid per source;
- formal CrystalShift run completes with exit code 0;
- repeated prediction and set files are byte-identical;
- evaluator outputs reproduce byte-for-byte.

## Claim boundary

This new-release replay can strengthen external-benchmark portability. It cannot
be called a new independent experimental collection, a physical multiphase
specimen test or prospective validation.
