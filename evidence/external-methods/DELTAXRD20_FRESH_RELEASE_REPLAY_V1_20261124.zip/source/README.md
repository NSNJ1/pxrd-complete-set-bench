# DeltaXRDbench datasets v1.1.0

Multi-target MP500 dataset update, extending [v1.0.0](https://github.com/DeltaGanjiang/deltaxrdbench/releases/tag/v1.0.0).

| Dataset / folder | Type | Single-phase | Mixtures |
| --- | --- | ---: | ---: |
| `mp500-Cu` | Simulated Cu Kα | 10,000 | 30,000 |
| `rruff-Cu` | Experimental structure–pattern pairs | 1,164 | 10,000 |
| `opxrd-Cu` | Experimental structure–pattern pairs | 880 | 10,000 |
| `MP500-Co` | Simulated Co Kα | 1,000 | 500 |
| `MP500-Mo` | Simulated Mo Kα | 1,000 | 500 |
| `MP500-Cr` | Simulated Cr Kα | 1,000 | 500 |
| `MP500-Fe` | Simulated Fe Kα | 1,000 | 500 |
| `MP500-Ag` | Simulated Ag Kα | 1,000 | 500 |

**Total: 69,544 patterns across eight datasets.** The five new targets add 7,500 patterns and share the same 1,000 MP500 structures and 500 mixture compositions. Every new mixture contains two or three distinct phases, each with a model mass fraction of at least 10%.

### New target simulations

| Target | Kα₁ / Å | Kα₂ / Å | Nominal weighted mean / Å |
| --- | ---: | ---: | ---: |
| Co | 1.7890 | 1.7929 | 1.7903 |
| Mo | 0.7093 | 0.7136 | 0.7107 |
| Cr | 2.2897 | 2.2936 | 2.2910 |
| Fe | 1.9360 | 1.9400 | 1.9374 |
| Ag | 0.5594 | 0.5638 | 0.5609 |

The new scans use separate Kα₁/Kα₂ lines at a 2:1 ratio, a 10–80° 2θ range, and 0.01° steps. They include Lorentz-polarization factors, pseudo-Voigt peak profiles, instrument and size/strain broadening, thermal damping, small angle offsets, retained backgrounds, Poisson counting noise and detector read noise. Mixtures combine unnormalized phase signals before adding one background and noise realization. Seed: `20261117`.

These are synthetic scans under generic laboratory conditions, not calibrated measurements from a specific instrument. Composition-specific fluorescence, absorption/microabsorption, preferred orientation, Kβ contamination and axial divergence are not modeled. Fractions are model mass fractions, not calibrated experimental concentrations.

### Download and use

Download **`datasets.zip`** for the complete dataset bundle, then extract it into your local `datasets/` directory:

```bash
unzip datasets.zip -d datasets/
```

The archive contains the eight folders listed above directly at its root. The original Cu datasets now have explicit `-Cu` folder suffixes. Each folder contains `patterns.h5`, `manifest.jsonl`, reference `structures/*.cif`, a README and per-file `checksums.json`. The new targets also include simulation settings, source-CIF checksums and per-sample signal/background components. Source paths in `selection.json` are relative to the dataset folder.

**`SHA256SUMS`** contains attachment checksums. To verify the bundle:

```bash
shasum -a 256 -c SHA256SUMS
```

Download all four release attachments before running the command, or verify the `datasets.zip` entry alone. **`MP500-target-validation.json`** records successful checks for all 7,500 new patterns, source CIFs, labels, fractions, backgrounds, count-noise statistics and target pairing. **`MP500-target-preview.png`** compares the five new targets.

This is a dataset release. No new data-generation scripts, generation tests or local reflection caches are included in the attachments or committed for this release.
