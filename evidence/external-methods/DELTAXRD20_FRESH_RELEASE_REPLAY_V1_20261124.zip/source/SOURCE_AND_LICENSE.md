# Source and licence

- Release: DeltaXRDbench dataset v1.1.0
- GitHub release:
  `https://github.com/DeltaGanjiang/deltaxrdbench/releases/tag/v1.1.0`
- Combined archive SHA-256:
  `815cf737fe9166ec4e83e0aec91b01854ab4fc6cfeac481e83110bdf7de390b`
- RRUFF and opXRD source terms remain with their original providers.
- The DeltaXRDbench repository states that a project licence must be added
  before public redistribution of its code or artifacts.

This evidence package therefore does not redistribute the raw spectra, source
CIF files or the upstream archive. It includes source hashes, panel metadata,
scripts, derived scores and results so an auditor can download the official
release and regenerate the panel.
