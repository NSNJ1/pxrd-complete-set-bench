# DeltaXRDbench v1.1.0 fresh-release 20-candidate replay

## Scope

Two 30-query panels were drawn independently from the RRUFF-Cu and opXRD-Cu
mixture tracks of the newly released DeltaXRDbench dataset v1.1.0. Each query
has a 20-structure candidate library containing every reference positive plus
hash-selected negatives from the same source. RRUFF contains 16 two-phase and
14 three-phase queries; opXRD contains 15 and 15. CrystalShift was locally
adapted.

This is a new external benchmark release to this project, not an independent
physical multiphase collection. DeltaXRDbench constructs its mixtures from
measured source profiles rather than physically mixed specimens.

## RRUFF

| Method | Phase AP | Top-1 has a true phase | all-present@3 | all-present@5 |
| --- | ---: | ---: | ---: | ---: |
| Random | 25.9% | 20.0% | 0.0% | 0.0% |
| Global Pearson | 97.5% | 100.0% | 90.0% | 100.0% |
| Eight-window Pearson | 98.3% | 100.0% | 93.3% | 100.0% |
| CrystalShift adapted | 89.5% | 96.7% | 70.0% | 76.7% |

CrystalShift minus eight-window Pearson:

- phase AP: -0.0888
  (-0.1496 to
  -0.0365);
- all-present@3: -23.3
  percentage points
  (-40.0 to
  -6.7).

## opXRD

| Method | Phase AP | Top-1 has a true phase | all-present@3 | all-present@5 |
| --- | ---: | ---: | ---: | ---: |
| Random | 27.0% | 26.7% | 0.0% | 0.0% |
| Global Pearson | 56.6% | 70.0% | 16.7% | 26.7% |
| Eight-window Pearson | 57.8% | 70.0% | 13.3% | 23.3% |
| CrystalShift adapted | 48.8% | 50.0% | 16.7% | 20.0% |

CrystalShift minus eight-window Pearson:

- phase AP: -0.0904
  (-0.1859 to
  -0.0051);
- all-present@3: 3.3
  percentage points
  (-6.7 to
  13.3).

## Source interaction

For the CrystalShift-minus-window comparison, the RRUFF-minus-opXRD interaction
is:

- phase AP: 0.15 percentage
  points
  (-10.42 to
  10.78);
- all-present@3:
  -26.7 percentage points
  (-46.7 to
  -6.7).

The phase-AP disadvantage is consistent across the two lineages. The
all-present@3 conclusion is not: the external method is significantly worse on
RRUFF, indistinguishable on opXRD, and the source interaction excludes zero.

This is the strongest evidence for the paper's revised thesis. The benchmark is
not merely reporting that a simple baseline wins. It shows that the conclusion
about a method depends on source and endpoint even when the candidate budget is
held at 20.

## Reproduction

Both panels were run twice. Prediction and set files are byte-identical. All
seven derived result tables are byte-identical between the first and repeated
evaluation. The Julia process emitted a `SparseArraysExt` extension warning but
completed every query and exited with code zero.
