using CrystalShift
using Statistics

const K_EXPAND = 3
const STD_NOISE = 0.01
const MEAN_THETA = [1.0, 0.5, 0.5]
const STD_THETA = [0.1, 0.05, 0.1]
const NORMALIZATION_CONSTANT = 2.5

function option(args, name, default=nothing; required=false)
    prefix = name * "="
    for arg in args
        if startswith(arg, prefix)
            return split(arg, "="; limit=2)[2]
        end
    end
    if required
        error("missing required option: " * name)
    end
    return default
end

function read_csv_rows(path)
    lines = readlines(path)
    isempty(lines) && error("empty CSV: " * path)
    header = split(strip(lines[1]), ',')
    rows = Vector{Dict{String,String}}()
    for line in lines[2:end]
        isempty(strip(line)) && continue
        values = split(strip(line), ',')
        length(values) == length(header) ||
            error("wrong field count in " * path)
        push!(
            rows,
            Dict(header[index] => String(values[index])
                 for index in eachindex(header)),
        )
    end
    return rows
end

function load_candidates(path)
    raw = replace(read(path, String), "\r\n" => "\n")
    segments = [
        strip(segment)
        for segment in split(raw, "#\n")
        if !isempty(strip(segment))
    ]
    !isempty(segments) || error("no candidate blocks found")
    phases = [
        CrystalPhase(String(segment), 0.1, CrystalShift.Gauss())
        for segment in segments
    ]
    ids = [phase.id + 1 for phase in phases]
    sort(ids) == collect(1:length(phases)) ||
        error("candidate IDs are not 1..$(length(phases)): $(ids)")
    return phases
end

function load_spectrum(path, wavelength_angstrom)
    x = Float64[]
    y = Float64[]
    for line in eachline(path)
        values = split(strip(line))
        isempty(values) && continue
        length(values) >= 2 || error("bad spectrum row in " * path)
        push!(x, parse(Float64, values[1]))
        push!(y, parse(Float64, values[2]))
    end
    q = 4pi .* sin.(deg2rad.(x ./ 2.0)) ./ (wavelength_angstrom / 10.0)
    order = sortperm(q)
    q = q[order]
    y = y[order]
    length(q) >= 100 || error("too few valid points in " * path)
    sorted_y = sort(copy(y))
    baseline_index = max(1, ceil(Int, 0.01 * length(sorted_y)))
    baseline = sorted_y[baseline_index]
    y = max.(y .- baseline, 0.0)
    maximum_y = maximum(y)
    maximum_y > 0.0 || error("zero normalized spectrum in " * path)
    y ./= maximum_y
    return q, y
end

function local_phase_indices(node, local_by_global)
    return sort(
        unique(
            [
                local_by_global[phase.id + 1]
                for phase in node.phase_model.CPs
                if haskey(local_by_global, phase.id + 1)
            ],
        ),
    )
end

function run_query(path, phases, wavelength_angstrom, max_depth)
    x, y = load_spectrum(path, wavelength_angstrom)
    first_peak = minimum(
        minimum(peak.q for peak in phase.peaks)
        for phase in phases
    )
    last_peak = maximum(
        maximum(peak.q for peak in phase.peaks)
        for phase in phases
    )
    keep = (x .>= first_peak) .& (x .<= last_peak)
    x = x[keep]
    y = y[keep]
    length(x) >= 100 || error("too few common q points in " * path)
    local_by_global = Dict(
        phase.id + 1 => index
        for (index, phase) in enumerate(phases)
    )
    tree = Lazytree(phases, x)
    results = search!(
        tree,
        x,
        y,
        max_depth,
        K_EXPAND,
        false,
        false,
        8.0,
        STD_NOISE,
        MEAN_THETA,
        STD_THETA;
        method=LM,
        maxiter=32,
        regularization=true,
        optimize_mode=Simple,
        em_loop_num=1,
    )
    nodes = reduce(vcat, results[2:end])
    probabilities = get_probabilities(
        nodes,
        x,
        y,
        MEAN_THETA,
        STD_THETA;
        renormalize=true,
        normalization_constant=NORMALIZATION_CONSTANT,
    )
    inclusion = zeros(Float64, length(phases))
    for index in eachindex(nodes)
        for local_index in local_phase_indices(nodes[index], local_by_global)
            inclusion[local_index] += probabilities[index]
        end
    end
    order = sortperm(eachindex(inclusion), by=i -> (-inclusion[i], i))
    ranks = zeros(Int, length(inclusion))
    for (rank, phase_index) in enumerate(order)
        ranks[phase_index] = rank
    end
    probability_order = sortperm(probabilities, rev=true)
    return inclusion, ranks, nodes, probabilities, probability_order, local_by_global
end

function write_output(path, query_id, inclusion, ranks, candidate_ids)
    open(path, "a") do handle
        for index in eachindex(inclusion)
            println(
                handle,
                join(
                    (
                        query_id,
                        candidate_ids[index],
                        string(inclusion[index]),
                        string(ranks[index]),
                    ),
                    ",",
                ),
            )
        end
    end
end

function write_sets(
    path,
    query_id,
    nodes,
    probabilities,
    probability_order,
    candidate_ids,
    local_by_global,
)
    open(path, "a") do handle
        top_indices = probability_order[
            1:min(10, length(probability_order))
        ]
        for index in top_indices
            members = local_phase_indices(nodes[index], local_by_global)
            println(
                handle,
                join(
                    (
                        query_id,
                        join(candidate_ids[members], "|"),
                        string(probabilities[index]),
                    ),
                    ",",
                ),
            )
        end
    end
end

function main()
    args = ARGS
    sticks = option(args, "--sticks", required=true)
    queries_path = option(args, "--queries", required=true)
    spectra_dir = option(args, "--spectra-dir", required=true)
    candidates_path = option(args, "--candidates", required=true)
    candidate_sets_path = option(args, "--candidate-sets", required=true)
    predictions_out = option(args, "--out", required=true)
    sets_out = option(args, "--sets", required=true)
    max_depth = parse(Int, option(args, "--max-depth", "3"))
    max_queries = parse(
        Int,
        option(args, "--max-queries", string(typemax(Int))),
    )
    query_rows = read_csv_rows(queries_path)
    candidate_rows = read_csv_rows(candidates_path)
    candidate_set_rows = read_csv_rows(candidate_sets_path)
    candidate_ids = [row["candidate_id"] for row in candidate_rows]
    phases = load_candidates(sticks)
    length(candidate_ids) == length(phases) ||
        error("candidate table and stick blocks disagree")
    phase_by_id = Dict(
        candidate_ids[index] => phases[index]
        for index in eachindex(candidate_ids)
    )
    candidates_by_query = Dict{String,Vector{Tuple{Int,String}}}()
    for row in candidate_set_rows
        push!(
            get!(candidates_by_query, row["query_id"], Tuple{Int,String}[]),
            (parse(Int, row["rank_position"]), row["candidate_id"]),
        )
    end
    for (query_id, rows) in candidates_by_query
        sort!(rows)
        candidates_by_query[query_id] = rows
    end
    open(predictions_out, "w") do handle
        println(handle, "query_id,phase_id,score,rank")
    end
    open(sets_out, "w") do handle
        println(handle, "query_id,set,probability")
    end
    for (query_number, row) in enumerate(query_rows)
        query_number > max_queries && break
        query_id = row["query_id"]
        query_set = candidates_by_query[query_id]
        selected_ids = [candidate_id for (_, candidate_id) in query_set]
        selected_phases = [phase_by_id[candidate_id] for candidate_id in selected_ids]
        wavelength_angstrom = parse(Float64, row["wavelength_angstrom"])
        spectrum_path = joinpath(spectra_dir, basename(row["spectrum_file"]))
        inclusion, ranks, nodes, probabilities, probability_order, local_by_global =
            run_query(
                spectrum_path,
                selected_phases,
                wavelength_angstrom,
                max_depth,
            )
        write_output(
            predictions_out,
            query_id,
            inclusion,
            ranks,
            selected_ids,
        )
        write_sets(
            sets_out,
            query_id,
            nodes,
            probabilities,
            probability_order,
            selected_ids,
            local_by_global,
        )
        println("CRYSTALSHIFT_QUERY_PASS query_id=", query_id)
    end
    println("CRYSTALSHIFT_RUN_PASS")
end

main()
