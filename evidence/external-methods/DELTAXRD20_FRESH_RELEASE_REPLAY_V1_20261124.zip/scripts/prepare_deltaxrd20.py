"""Prepare fresh-release DeltaXRDbench 20-candidate review panels."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import warnings
from pathlib import Path

import h5py
import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter

warnings.filterwarnings("ignore", category=UserWarning)

SEED = 20261126
QUERY_COUNT = 30
CANDIDATE_COUNT = 20
MAX_ATOMS = 100
WAVELENGTH_ANGSTROM = 1.54060
SOURCES = {
    "rruff": "rruff-Cu",
    "opxrd": "opxrd-Cu",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(seed: int, role: str, value: str) -> str:
    payload = f"{seed}|{role}|{value}".encode()
    return hashlib.sha256(payload).hexdigest()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load_manifest(path: Path) -> list[dict[str, object]]:
    rows = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if not rows:
        raise ValueError(f"empty manifest: {path}")
    return rows


def standardized_cif(structure: Structure) -> str:
    try:
        return str(CifWriter(structure, symprec=0.1))
    except (ValueError, RuntimeError):
        return str(CifWriter(structure))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release-root", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    all_selection: dict[str, object] = {}
    for source_name, directory_name in SOURCES.items():
        source_root = args.release_root / directory_name
        manifest_path = source_root / "manifest.jsonl"
        pattern_path = source_root / "patterns.h5"
        manifest = load_manifest(manifest_path)

        structure_pool: dict[str, Path] = {}
        for row in manifest:
            ground_truth = row["ground_truth"]
            for phase_id, structure_file in zip(
                ground_truth["phase_ids"],
                ground_truth["structure_files"],
                strict=True,
            ):
                structure_pool[str(phase_id)] = source_root / str(structure_file)
        for path in structure_pool.values():
            if not path.is_file():
                raise FileNotFoundError(path)

        eligible_structures: dict[str, Structure] = {}
        excluded_structures = []
        for phase_id, path in sorted(structure_pool.items()):
            try:
                structure = Structure.from_file(path, occupancy_tolerance=2.0)
            except (KeyError, TypeError, ValueError) as exc:
                excluded_structures.append(
                    {
                        "phase_id": phase_id,
                        "reason": f"parse_error:{type(exc).__name__}",
                    }
                )
                continue
            if len(structure) > MAX_ATOMS:
                excluded_structures.append(
                    {
                        "phase_id": phase_id,
                        "reason": f"atom_count:{len(structure)}",
                    }
                )
                continue
            eligible_structures[phase_id] = structure

        multi_rows = []
        for row in manifest:
            if row["task"] != "identification.multi":
                continue
            positive_phase_ids = [
                str(value) for value in row["ground_truth"]["phase_ids"]
            ]
            if all(phase_id in eligible_structures for phase_id in positive_phase_ids):
                multi_rows.append(row)
        if len(multi_rows) < QUERY_COUNT:
            raise ValueError(f"{source_name}: too few eligible mixture records")

        selected = sorted(
            multi_rows,
            key=lambda row: digest(SEED, "query_selection", str(row["sample_id"])),
        )[:QUERY_COUNT]
        selected = sorted(
            selected,
            key=lambda row: digest(SEED, "query_order", str(row["sample_id"])),
        )

        public_dir = args.out_dir / source_name / "public"
        evaluator_dir = args.out_dir / source_name / "evaluator"
        spectra_dir = public_dir / "spectra"
        cif_dir = public_dir / "cif"
        spectra_dir.mkdir(parents=True, exist_ok=True)
        cif_dir.mkdir(parents=True, exist_ok=True)
        evaluator_dir.mkdir(parents=True, exist_ok=True)

        query_rows: list[dict[str, object]] = []
        target_rows: list[dict[str, object]] = []
        candidate_set_rows: list[dict[str, object]] = []
        selected_libraries: dict[str, list[str]] = {}
        for query_number, row in enumerate(selected, start=1):
            query_id = f"dxr_{source_name}_q{query_number:02d}"
            positive_phase_ids = [
                str(value) for value in row["ground_truth"]["phase_ids"]
            ]
            if not 2 <= len(positive_phase_ids) <= 3:
                raise ValueError(f"unexpected positive count for {row['sample_id']}")
            if len(set(positive_phase_ids)) != len(positive_phase_ids):
                raise ValueError(f"duplicate positive identity for {row['sample_id']}")
            negative_pool = [
                phase_id
                for phase_id in eligible_structures
                if phase_id not in set(positive_phase_ids)
            ]
            negative_pool.sort(
                key=lambda phase_id: digest(
                    SEED,
                    "negative_selection",
                    f"{row['sample_id']}|{phase_id}",
                )
            )
            selected_candidates = [
                *positive_phase_ids,
                *negative_pool[: CANDIDATE_COUNT - len(positive_phase_ids)],
            ]
            if len(selected_candidates) != CANDIDATE_COUNT:
                raise ValueError("candidate-library construction failed")
            selected_candidates.sort(
                key=lambda phase_id: digest(
                    SEED,
                    "candidate_order",
                    f"{query_id}|{phase_id}",
                )
            )
            selected_libraries[query_id] = selected_candidates
            for candidate_position, phase_id in enumerate(
                selected_candidates,
                start=1,
            ):
                candidate_set_rows.append(
                    {
                        "query_id": query_id,
                        "rank_position": candidate_position,
                        "candidate_id": f"dxr_{source_name}_{candidate_position:02d}",
                        "phase_id": phase_id,
                    }
                )

            input_record = row["input"]
            if input_record["archive"] != "patterns.h5":
                raise ValueError("unexpected pattern archive")
            target_rows.append(
                {
                    "query_id": query_id,
                    "sample_id": row["sample_id"],
                    "positive_phase_ids": "|".join(positive_phase_ids),
                    "positive_count": len(positive_phase_ids),
                    "fractions": "|".join(
                        str(value) for value in row["metadata"].get("fractions", [])
                    ),
                }
            )

        all_phase_ids = sorted(
            {
                phase_id
                for candidates in selected_libraries.values()
                for phase_id in candidates
            },
            key=lambda phase_id: digest(SEED, "global_candidate_order", phase_id),
        )
        global_candidate_id = {
            phase_id: f"dxr_{source_name}_s{position:04d}"
            for position, phase_id in enumerate(all_phase_ids, start=1)
        }
        candidate_rows = []
        for phase_id in all_phase_ids:
            candidate_id = global_candidate_id[phase_id]
            copied_path = cif_dir / f"{candidate_id}.cif"
            structure = eligible_structures[phase_id]
            copied_path.write_text(
                standardized_cif(structure),
                encoding="utf-8",
                newline="\n",
            )
            candidate_rows.append(
                {
                    "candidate_id": candidate_id,
                    "phase_id": phase_id,
                    "cif_file": f"cif/{candidate_id}.cif",
                    "atom_count": len(structure),
                    "sha256": sha256(copied_path),
                }
            )
        candidate_id_by_phase = {
            row["phase_id"]: row["candidate_id"] for row in candidate_rows
        }
        for candidate_set_row in candidate_set_rows:
            candidate_set_row["candidate_id"] = candidate_id_by_phase[
                candidate_set_row.pop("phase_id")
            ]
        for target_row in target_rows:
            positives = str(target_row["positive_phase_ids"]).split("|")
            target_row["target_candidate_ids"] = "|".join(
                candidate_id_by_phase[phase_id] for phase_id in positives
            )

        two_theta: np.ndarray
        multi_intensity: h5py.Dataset
        with h5py.File(pattern_path, "r") as handle:
            two_theta = np.asarray(handle["two_theta_deg"], dtype=np.float64)
            multi_intensity = handle["multi_intensity"]
            for row, target_row in zip(selected, target_rows, strict=True):
                query_id = str(target_row["query_id"])
                intensity = np.asarray(
                    multi_intensity[int(row["input"]["index"])],
                    dtype=np.float64,
                )
                intensity = np.clip(intensity, 0.0, None)
                maximum = float(intensity.max())
                if maximum <= 0.0:
                    raise ValueError(f"empty intensity for {query_id}")
                intensity /= maximum
                spectrum_path = spectra_dir / f"{query_id}.xy"
                spectrum_path.write_text(
                    "".join(
                        f"{x:.10f} {y:.12g}\n"
                        for x, y in zip(two_theta, intensity, strict=True)
                    ),
                    encoding="utf-8",
                    newline="\n",
                )
                query_rows.append(
                    {
                        "query_id": query_id,
                        "spectrum_file": f"spectra/{query_id}.xy",
                        "radiation": "Cu",
                        "wavelength_angstrom": WAVELENGTH_ANGSTROM,
                    }
                )

        write_csv(public_dir / "queries.csv", query_rows)
        write_csv(public_dir / "candidates.csv", candidate_rows)
        write_csv(public_dir / "candidate_sets.csv", candidate_set_rows)
        write_csv(evaluator_dir / "targets.csv", target_rows)
        cardinality_counts = {
            str(count): sum(row["positive_count"] == count for row in target_rows)
            for count in sorted({row["positive_count"] for row in target_rows})
        }
        all_selection[source_name] = {
            "queries": len(query_rows),
            "unique_candidate_structures": len(candidate_rows),
            "eligible_unique_structures": len(eligible_structures),
            "excluded_structures": excluded_structures,
            "query_positive_count_distribution": cardinality_counts,
            "manifest_sha256": sha256(manifest_path),
            "patterns_sha256": sha256(pattern_path),
            "query_order": target_rows,
            "candidate_order": candidate_rows,
        }

    (args.out_dir / "selection.json").write_text(
        json.dumps(
            {
                "status": "deltaxrd20_v1_selection_frozen",
                "seed": SEED,
                "release": "DeltaXRDbench dataset v1.1.0",
                "archive_sha256": sha256(args.archive),
                "sources": all_selection,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {
                "status": "deltaxrd20_prepared",
                "sources": {
                    name: {
                        "queries": values["queries"],
                        "unique_candidates": values["unique_candidate_structures"],
                        "positive_counts": values["query_positive_count_distribution"],
                    }
                    for name, values in all_selection.items()
                },
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
