"""Evaluate the DeltaXRDbench fresh-release 20-candidate replay."""

from __future__ import annotations

import argparse
import hashlib
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from sklearn.metrics import average_precision_score

warnings.filterwarnings("ignore", category=UserWarning)

SEED = 20261124
BOOTSTRAP_REPEATS = 10_000
BUDGETS = (1, 2, 3, 5)
FWHM = 0.1
KA1 = 1.54060
KA2 = 1.54439
ENDPOINT_COLUMNS = {
    "phase_ap_macro": "phase_ap",
    "top1_present": "top1_present",
    "best_positive_mrr": "best_positive_reciprocal_rank",
    **{f"all_present_at_{budget}": f"all_present_at_{budget}" for budget in BUDGETS},
    "mean_minimum_all_present_budget": "minimum_all_present_budget",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def random_scores(query_id: str, candidate_ids: list[str]) -> np.ndarray:
    values = []
    for candidate_id in candidate_ids:
        digest = hashlib.sha256(f"{SEED}|{query_id}|{candidate_id}".encode()).digest()
        values.append(int.from_bytes(digest[:8], "big") / (2**64 - 1))
    return np.asarray(values, dtype=np.float64)


def simulated_pattern(
    path: Path,
    two_theta: np.ndarray,
    calculator_ka1: XRDCalculator,
    calculator_ka2: XRDCalculator,
) -> np.ndarray:
    structure = Structure.from_file(path, occupancy_tolerance=2.0)
    intensity = np.zeros_like(two_theta)
    sigma = FWHM / (2.0 * np.sqrt(2.0 * np.log(2.0)))
    for calculator, amplitude_scale in (
        (calculator_ka1, 1.0),
        (calculator_ka2, 0.5),
    ):
        pattern = calculator.get_pattern(
            structure,
            scaled=False,
            two_theta_range=(float(two_theta[0]), float(two_theta[-1])),
        )
        for position, amplitude in zip(
            pattern.x,
            pattern.y,
            strict=True,
        ):
            intensity += (
                amplitude_scale
                * amplitude
                * np.exp(-0.5 * np.square((two_theta - position) / sigma))
            )
    maximum = float(intensity.max())
    if maximum <= 0.0:
        raise ValueError(f"empty simulated pattern: {path}")
    return intensity / maximum


def pearson_scores(
    query: np.ndarray,
    candidate_patterns: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    root_query = np.sqrt(np.clip(query, 0.0, None))
    root_candidates = np.sqrt(np.clip(candidate_patterns, 0.0, None))
    root_query = (root_query - root_query.mean()) / (root_query.std() + 1e-9)
    root_candidates = (
        root_candidates - root_candidates.mean(axis=1, keepdims=True)
    ) / (root_candidates.std(axis=1, keepdims=True) + 1e-9)
    global_scores = root_candidates @ root_query / len(query)
    window_scores = np.zeros_like(global_scores)
    for window in np.array_split(np.arange(len(query)), 8):
        query_window = root_query[window]
        candidate_window = root_candidates[:, window]
        query_window = (query_window - query_window.mean()) / (
            query_window.std() + 1e-9
        )
        candidate_window = (
            candidate_window - candidate_window.mean(axis=1, keepdims=True)
        ) / (candidate_window.std(axis=1, keepdims=True) + 1e-9)
        window_scores += candidate_window @ query_window / len(window)
    return global_scores, window_scores / 8.0


def conservative_rank(scores: np.ndarray, labels: np.ndarray) -> int:
    positive_scores = scores[labels.astype(bool)]
    worst_positive = float(positive_scores.min())
    return int((scores >= worst_positive).sum())


def best_positive_rank(scores: np.ndarray, labels: np.ndarray) -> int:
    positive_scores = scores[labels.astype(bool)]
    best_positive = float(positive_scores.max())
    return int((scores > best_positive).sum() + 1)


def percentile(values: np.ndarray) -> list[float]:
    return [
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    ]


def query_metrics(scores: np.ndarray, labels: np.ndarray) -> dict[str, float]:
    minimum_budget = conservative_rank(scores, labels)
    best_rank = best_positive_rank(scores, labels)
    return {
        "phase_ap": float(average_precision_score(labels, scores)),
        "top1_present": float(best_rank == 1),
        "best_positive_reciprocal_rank": float(1.0 / best_rank),
        "minimum_all_present_budget": float(minimum_budget),
        **{
            f"all_present_at_{budget}": float(minimum_budget <= budget)
            for budget in BUDGETS
        },
    }


def summarize(values: pd.DataFrame, method: str) -> dict[str, float]:
    return {
        "phase_ap_macro": float(values[f"phase_ap__{method}"].mean()),
        "top1_present": float(values[f"top1_present__{method}"].mean()),
        "best_positive_mrr": float(
            values[f"best_positive_reciprocal_rank__{method}"].mean()
        ),
        **{
            f"all_present_at_{budget}": float(
                values[f"all_present_at_{budget}__{method}"].mean()
            )
            for budget in BUDGETS
        },
        "mean_minimum_all_present_budget": float(
            values[f"minimum_all_present_budget__{method}"].mean()
        ),
    }


def bootstrap_paired_delta(
    query_metrics_path: Path,
    left: str,
    right: str,
    seed: int,
) -> dict[str, np.ndarray]:
    table = pd.read_csv(query_metrics_path)
    rng = np.random.default_rng(seed)
    sampled = rng.integers(0, len(table), size=(BOOTSTRAP_REPEATS, len(table)))
    output = {}
    for endpoint, column in ENDPOINT_COLUMNS.items():
        left_values = table[f"{column}__{left}"].to_numpy(dtype=np.float64)
        right_values = table[f"{column}__{right}"].to_numpy(dtype=np.float64)
        output[endpoint] = np.asarray(
            [
                left_values[indices].mean() - right_values[indices].mean()
                for indices in sampled
            ]
        )
    return output


def evaluate_source(
    source_name: str,
    dataset_root: Path,
    predictions_path: Path,
    protocol_path: Path,
    out_dir: Path,
) -> dict[str, object]:
    public_dir = dataset_root / "public"
    evaluator_dir = dataset_root / "evaluator"
    candidates = pd.read_csv(public_dir / "candidates.csv")
    candidate_sets = pd.read_csv(public_dir / "candidate_sets.csv")
    queries = pd.read_csv(public_dir / "queries.csv")
    targets = pd.read_csv(evaluator_dir / "targets.csv")
    predictions = pd.read_csv(predictions_path)

    candidate_path = dict(
        zip(candidates["candidate_id"], candidates["cif_file"], strict=True)
    )
    candidates_by_query = {
        query_id: group.sort_values("rank_position")["candidate_id"].tolist()
        for query_id, group in candidate_sets.groupby("query_id", sort=False)
    }
    target_by_query = {
        row.query_id: str(row.target_candidate_ids).split("|")
        for row in targets.itertuples(index=False)
    }
    query_path = dict(zip(queries["query_id"], queries["spectrum_file"], strict=True))
    expected_candidate_pairs = {
        (query_id, candidate_id)
        for query_id, selected in candidates_by_query.items()
        for candidate_id in selected
    }
    observed_candidate_pairs = set(
        zip(
            predictions["query_id"],
            predictions["phase_id"],
            strict=True,
        )
    )
    if expected_candidate_pairs != observed_candidate_pairs:
        raise ValueError(f"{source_name}: prediction coverage does not match")
    if predictions.duplicated(["query_id", "phase_id"]).any():
        raise ValueError(f"{source_name}: duplicate prediction")

    two_theta = np.loadtxt(
        public_dir / str(next(iter(query_path.values()))),
        usecols=0,
    )
    profile_cache: dict[str, np.ndarray] = {}
    calculator_ka1 = XRDCalculator(wavelength=KA1)
    calculator_ka2 = XRDCalculator(wavelength=KA2)
    for candidate_id in sorted(candidate_path):
        profile_cache[candidate_id] = simulated_pattern(
            public_dir / candidate_path[candidate_id],
            two_theta,
            calculator_ka1,
            calculator_ka2,
        )

    method_rows = []
    query_rows = []
    for query_id in queries["query_id"]:
        selected = candidates_by_query[query_id]
        query_intensity = np.loadtxt(
            public_dir / query_path[query_id],
            usecols=1,
        )
        candidate_patterns = np.stack(
            [profile_cache[candidate_id] for candidate_id in selected]
        )
        global_scores, window_scores = pearson_scores(
            query_intensity,
            candidate_patterns,
        )
        crystal_values = predictions.loc[predictions["query_id"] == query_id].set_index(
            "phase_id"
        )
        crystal_scores = np.asarray(
            [crystal_values.at[candidate_id, "score"] for candidate_id in selected],
            dtype=np.float64,
        )
        score_matrix = {
            "deterministic_random": random_scores(query_id, selected),
            "global_sqrt_pearson": global_scores,
            "window_sqrt_pearson": window_scores,
            "crystalshift_adapted_20": crystal_scores,
        }
        labels = np.asarray(
            [candidate_id in target_by_query[query_id] for candidate_id in selected],
            dtype=np.int8,
        )
        for candidate_index, candidate_id in enumerate(selected):
            method_rows.append(
                {
                    "query_id": query_id,
                    "candidate_id": candidate_id,
                    **{
                        method: float(scores[candidate_index])
                        for method, scores in score_matrix.items()
                    },
                }
            )
        row: dict[str, object] = {
            "query_id": query_id,
            "positive_count": int(labels.sum()),
        }
        for method, scores in score_matrix.items():
            values = query_metrics(scores, labels)
            row.update({f"{name}__{method}": value for name, value in values.items()})
        query_rows.append(row)
    query_table = pd.DataFrame(query_rows)
    methods = {
        method: summarize(query_table, method)
        for method in (
            "deterministic_random",
            "global_sqrt_pearson",
            "window_sqrt_pearson",
            "crystalshift_adapted_20",
        )
    }

    rng = np.random.default_rng(SEED)
    sampled = rng.integers(
        0,
        len(query_table),
        size=(BOOTSTRAP_REPEATS, len(query_table)),
    )
    bootstrap = {
        method: {endpoint: np.empty(BOOTSTRAP_REPEATS) for endpoint in ENDPOINT_COLUMNS}
        for method in methods
    }
    for repeat, indices in enumerate(sampled):
        for method in methods:
            for endpoint, column in ENDPOINT_COLUMNS.items():
                bootstrap[method][endpoint][repeat] = float(
                    query_table[f"{column}__{method}"].iloc[indices].mean()
                )
    for method, method_result in methods.items():
        method_result["bootstrap_ci95"] = {
            endpoint: percentile(samples)
            for endpoint, samples in bootstrap[method].items()
        }

    comparison_specs = (
        ("crystalshift_adapted_20", "window_sqrt_pearson"),
        ("crystalshift_adapted_20", "global_sqrt_pearson"),
        ("window_sqrt_pearson", "global_sqrt_pearson"),
    )
    comparisons = {}
    for left, right in comparison_specs:
        comparisons[f"{left}_minus_{right}"] = {
            endpoint: {
                "estimate": methods[left][endpoint] - methods[right][endpoint],
                "ci95": percentile(
                    bootstrap[left][endpoint] - bootstrap[right][endpoint]
                ),
            }
            for endpoint in ENDPOINT_COLUMNS
        }

    out_dir.mkdir(parents=True, exist_ok=True)
    method_table = pd.DataFrame(method_rows)
    method_table.to_csv(
        out_dir / f"method_scores_{source_name}.csv",
        index=False,
        lineterminator="\n",
    )
    query_table.to_csv(
        out_dir / f"query_metrics_{source_name}.csv",
        index=False,
        lineterminator="\n",
    )
    report = {
        "status": f"deltaxrd20_{source_name}_evaluated",
        "claim_boundary": (
            "Fresh external benchmark release replay on mixtures constructed "
            "from measured single-phase source profiles. This is not an "
            "independent physical multiphase collection or prospective test."
        ),
        "contract": {
            "queries": len(query_table),
            "candidates_per_query": 20,
            "unique_candidate_structures": len(candidates),
            "positive_count_distribution": {
                str(count): int((query_table["positive_count"] == count).sum())
                for count in sorted(query_table["positive_count"].unique())
            },
            "bootstrap_repeats": BOOTSTRAP_REPEATS,
            "seed": SEED,
            "tie_rule": "conservative",
        },
        "inputs": {
            "dataset_manifest_sha256": sha256(dataset_root.parent / "selection.json"),
            "queries_sha256": sha256(public_dir / "queries.csv"),
            "candidates_sha256": sha256(public_dir / "candidates.csv"),
            "candidate_sets_sha256": sha256(public_dir / "candidate_sets.csv"),
            "targets_sha256": sha256(evaluator_dir / "targets.csv"),
            "predictions_sha256": sha256(predictions_path),
            "protocol_sha256": sha256(protocol_path),
        },
        "methods": methods,
        "paired_deltas": comparisons,
    }
    (out_dir / f"evaluation_{source_name}.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-root", type=Path, required=True)
    parser.add_argument("--rruff-predictions", type=Path, required=True)
    parser.add_argument("--opxrd-predictions", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    summaries = {}
    for source_name, predictions_path in (
        ("rruff", args.rruff_predictions),
        ("opxrd", args.opxrd_predictions),
    ):
        summaries[source_name] = evaluate_source(
            source_name,
            args.dataset_root / source_name,
            predictions_path,
            args.protocol,
            args.out,
        )
    args.out.mkdir(parents=True, exist_ok=True)
    interactions = {}
    for left, right in (
        ("crystalshift_adapted_20", "window_sqrt_pearson"),
        ("crystalshift_adapted_20", "global_sqrt_pearson"),
    ):
        rruff_delta = bootstrap_paired_delta(
            args.out / "query_metrics_rruff.csv",
            left,
            right,
            20261127,
        )
        opxrd_delta = bootstrap_paired_delta(
            args.out / "query_metrics_opxrd.csv",
            left,
            right,
            20261128,
        )
        interactions[f"rruff_minus_opxrd__{left}_minus_{right}"] = {
            endpoint: {
                "estimate": (
                    summaries["rruff"]["methods"][left][endpoint]
                    - summaries["rruff"]["methods"][right][endpoint]
                    - summaries["opxrd"]["methods"][left][endpoint]
                    + summaries["opxrd"]["methods"][right][endpoint]
                ),
                "ci95": percentile(rruff_delta[endpoint] - opxrd_delta[endpoint]),
            }
            for endpoint in ENDPOINT_COLUMNS
        }
    combined = {
        "status": "deltaxrd20_two_source_evaluated",
        "sources": summaries,
        "cross_source_interactions": interactions,
        "claim_boundary": (
            "Two-source fresh-release replay. Results are reported separately "
            "and are never presented as independent physical source families."
        ),
    }
    (args.out / "evaluation.json").write_text(
        json.dumps(combined, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(combined, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
