# RealBind 20-candidate panel, protocol v2

Status: frozen before V2 method execution  
Freeze date: 2026-11-24  
Source: RealBind mini 1.1.3  
Claim type: external retrospective single-phase boundary evidence

## Why v1 is not reportable

The first 20-candidate development run exposed two input-contract defects:

1. the public query file included the source UID and target candidate ID;
2. candidate and query positions were aligned in the same order.

Although the CrystalShift script did not read those metadata fields, the input
files allowed an avoidable shortcut. No V1 performance number is used for
method selection or final claims.

V2 uses a new deterministic seed and independent candidate/query ordering.

## Inputs

- RealBind mini source SHA-256:
  `00bd4742f0af524f9f88bcd98c16dfc59d4b77470597c296c34af4f6ad3d9678`;
- benchmark structure table SHA-256:
  `4279ae9759d97daacd5e7d31cfb1a43355a0c6a208e168961ddfea67bea14837`;
- mini-data licence: CC BY 4.0;
- underlying measured source: opXRD CC BY 4.0.

## V2 selection

Seed: `20261125`.

Candidate selection:

```text
sha256("20261125|selection|" + uid)
```

Take the first 20 structurally serializable candidates in ascending digest
order.

Candidate display order:

```text
sha256("20261125|candidate_order|" + uid)
```

Query display order:

```text
sha256("20261125|query_order|" + uid)
```

Candidate and query IDs are assigned independently in those two orders.
The public query file contains only:

- query ID;
- spectrum path;
- radiation;
- wavelength.

Source UID, target candidate and truth labels exist only in evaluator-side
files. CIFs are generated from the frozen RealBind structure objects.

## Methods and parameters

Baselines:

- deterministic random, seed `20261124`;
- global mask-aware square-root Pearson;
- eight-window mask-aware square-root Pearson.

Adapted CrystalShift:

- commit `c4884ca1dbbd78135cd50f5e17141cdc0b6f43c8`;
- Julia 1.10.13;
- Gauss, `width_init=0.1`;
- `max_depth=2`;
- `k_expand=3`;
- `std_noise=0.01`;
- `mean_theta=[1.0,0.5,0.5]`;
- `std_theta=[0.1,0.05,0.1]`;
- LM, `maxiter=32`, regularization, Simple mode;
- `normalization_constant=2.5`;
- equal-score ties use ascending candidate ID.

The CrystalShift execution is local and adapted. It is not an independent run.

## Endpoints and gates

Primary:

- Recall@1;
- Recall@3;
- MRR;
- query AP.

Secondary: Recall@5 and Recall@10.

Cluster bootstrap uses 10,000 repeats and seed `20261124`.

Acceptance requires:

- 20 measured queries;
- 20 independent candidate CIFs;
- exactly 400 prediction rows;
- no target or source UID in the CrystalShift input;
- successful completion of all 20 queries;
- exact candidate/query ID coverage.

The panel remains single-phase and retrospective. It cannot support a
multiphase, universal SOTA or prospective claim.
