"""Build CrystalShift candidate-stick blocks for an arbitrary CIF library."""

from __future__ import annotations

import argparse
from pathlib import Path

from pymatgen.io.cif import CifParser
from xrayutilities.materials.cif import CIFFile
from xrayutilities.materials.material import Crystal
from xrayutilities.simpack import PowderDiffraction

Q_MIN_NM_INV = 5.0
Q_MAX_NM_INV = 65.0
WAVELENGTH_ANGSTROM = 0.70932
THRESHOLD = 0.001


def parse_number(value: str) -> float:
    return float(value.split("(", 1)[0])


def crystal_system(path: Path) -> str:
    structure = CifParser(path).parse_structures(primitive=False)[0]
    _, number = structure.get_space_group_info(symprec=0.1)
    if number <= 2:
        return "triclinic"
    if number <= 15:
        return "monoclinic"
    if number <= 74:
        return "orthorhombic"
    if number <= 142:
        return "tetragonal"
    if number <= 167:
        return "trigonal"
    if number <= 194:
        return "hexagonal"
    return "cubic"


def phase_name(block: dict) -> str:
    formula = (
        block.get("_chemical_formula_structural")
        or block.get("_chemical_formula_sum")
        or "unknown"
    )
    formula = formula.replace(" ", "")
    group = (
        block.get("_symmetry_space_group_name_H-M")
        or block.get("_space_group_name_H-M_alt")
        or "unknown"
    )
    return f"{formula}_{group.strip().strip(chr(39))}"


def write_candidate(handle, index: int, path: Path, block: dict) -> None:
    a = parse_number(block["_cell_length_a"])
    b = parse_number(block["_cell_length_b"])
    c = parse_number(block["_cell_length_c"])
    alpha = parse_number(block["_cell_angle_alpha"])
    beta = parse_number(block["_cell_angle_beta"])
    gamma = parse_number(block["_cell_angle_gamma"])
    handle.write(
        f"{index},{phase_name(block)},{crystal_system(path)},"
        f"{a},{b},{c},{alpha},{beta},{gamma}\n"
    )
    lattice = CIFFile(path).SGLattice()
    crystal = Crystal(path.stem, lattice)
    diffraction = PowderDiffraction(
        crystal,
        wl=WAVELENGTH_ANGSTROM,
    ).data
    peaks = []
    for reflection, values in diffraction.items():
        q_nm_inv = float(values["qpos"]) * 10.0
        intensity = float(values["r"])
        if not (Q_MIN_NM_INV < q_nm_inv < Q_MAX_NM_INV):
            continue
        peaks.append((reflection, q_nm_inv, intensity))
    if not peaks:
        raise ValueError(f"no reflections in range for {path}")
    normalizer = max(item[2] for item in peaks)
    for reflection, q_nm_inv, intensity in peaks:
        if intensity / normalizer <= THRESHOLD:
            continue
        h, k, l = reflection
        handle.write(f"{h},{k},{l},{q_nm_inv:.17g},{intensity:.17g}\n")
    handle.write("#\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    candidates = sorted(args.candidates.glob("*.cif"))
    if not candidates:
        raise ValueError("no CIF files found")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8", newline="\n") as handle:
        for index, path in enumerate(candidates):
            first = CifParser(path).as_dict()
            block = first[next(iter(first))]
            write_candidate(handle, index, path, block)
    print(f"CRYSTALSHIFT_STICKS_PASS out={args.out} candidates={len(candidates)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
