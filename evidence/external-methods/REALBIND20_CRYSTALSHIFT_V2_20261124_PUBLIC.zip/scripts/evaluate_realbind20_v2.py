"""Evaluate RealBind 20-candidate baselines and adapted CrystalShift."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

SEED = 20261124
BOOTSTRAP_REPEATS = 10_000
Q_GRID = np.linspace(0.5, 6.5, 1024)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def random_scores(query_uid: str, candidate_uids: list[str]) -> np.ndarray:
    values = []
    for candidate_uid in candidate_uids:
        digest = hashlib.sha256(f"{SEED}|{query_uid}|{candidate_uid}".encode()).digest()
        values.append(int.from_bytes(digest[:8], "big") / (2**64 - 1))
    return np.asarray(values, dtype=np.float64)


def global_scores(
    query: np.ndarray,
    mask: np.ndarray,
    candidates: np.ndarray,
) -> np.ndarray:
    if mask.sum() < 10:
        return np.full(len(candidates), -np.inf)
    root_query = np.sqrt(np.clip(query[mask], 0.0, None))
    root_query = (root_query - root_query.mean()) / (root_query.std() + 1e-9)
    root_candidates = np.sqrt(np.clip(candidates[:, mask], 0.0, None))
    root_candidates = (
        root_candidates - root_candidates.mean(axis=1, keepdims=True)
    ) / (root_candidates.std(axis=1, keepdims=True) + 1e-9)
    return root_candidates @ root_query / mask.sum()


def window_scores(
    query: np.ndarray,
    mask: np.ndarray,
    candidates: np.ndarray,
) -> np.ndarray:
    indices = np.flatnonzero(mask)
    total = np.zeros(len(candidates), dtype=np.float64)
    valid = 0
    for window in np.array_split(indices, 8):
        if len(window) < 10:
            continue
        local = np.zeros_like(mask)
        local[window] = True
        total += global_scores(query, local, candidates)
        valid += 1
    return total / valid if valid else np.full(len(candidates), -np.inf)


def conservative_ranks(scores: np.ndarray, target: int) -> int:
    target_score = scores[target]
    if not np.isfinite(target_score):
        return len(scores)
    return int((scores >= target_score).sum() - 1)


def percentile(values: np.ndarray) -> list[float]:
    return [
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-npz", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    selection = json.loads(
        (args.dataset / "selection.json").read_text(encoding="utf-8")
    )
    candidate_order = selection["candidate_order"]
    query_order = selection["query_order"]
    candidate_source_indices = [int(row["source_index"]) for row in candidate_order]
    query_source_indices = [int(row["source_index"]) for row in query_order]
    query_uids = [row["query_uid"] for row in query_order]
    candidate_uids = [row["uid"] for row in candidate_order]
    candidate_ids = [row["candidate_id"] for row in candidate_order]
    target_by_query = {
        row["query_id"]: row["target_candidate_id"] for row in query_order
    }

    with np.load(args.source_npz, allow_pickle=True) as payload:
        all_queries = np.asarray(payload["X_query"], dtype=np.float64)
        all_masks = np.asarray(payload["M_query"], dtype=bool)
        all_candidates = np.asarray(payload["X_cand"], dtype=np.float64)
    queries = all_queries[query_source_indices]
    masks = all_masks[query_source_indices]
    candidate_patterns = all_candidates[candidate_source_indices]

    predicted = pd.read_csv(args.predictions)
    if len(predicted) != len(query_order) * len(candidate_order):
        raise ValueError("CrystalShift prediction grid is incomplete")
    if predicted.duplicated(["query_id", "phase_id"]).any():
        raise ValueError("duplicate CrystalShift predictions")
    expected_queries = {row["query_id"] for row in query_order}
    if set(predicted["query_id"]) != expected_queries:
        raise ValueError("CrystalShift query identities do not match")
    if set(predicted["phase_id"]) != set(candidate_ids):
        raise ValueError("CrystalShift candidate identities do not match")

    score_matrices = {
        "deterministic_random": np.stack(
            [
                random_scores(query_uids[index], candidate_uids)
                for index in range(len(query_order))
            ]
        ),
        "global_sqrt_pearson": np.stack(
            [
                global_scores(queries[index], masks[index], candidate_patterns)
                for index in range(len(query_order))
            ]
        ),
        "window_sqrt_pearson": np.stack(
            [
                window_scores(queries[index], masks[index], candidate_patterns)
                for index in range(len(query_order))
            ]
        ),
    }
    crystal_scores = np.empty((len(query_order), len(candidate_order)))
    phase_position = {phase_id: index for index, phase_id in enumerate(candidate_ids)}
    query_position = {row["query_id"]: index for index, row in enumerate(query_order)}
    for row in predicted.itertuples(index=False):
        crystal_scores[
            query_position[row.query_id],
            phase_position[row.phase_id],
        ] = float(row.score)
    if not np.isfinite(crystal_scores).all():
        raise ValueError("CrystalShift score matrix contains missing values")
    score_matrices["crystalshift_adapted_20"] = crystal_scores

    targets = np.asarray(
        [candidate_ids.index(target_by_query[row["query_id"]]) for row in query_order]
    )
    labels = np.zeros_like(score_matrices["deterministic_random"], dtype=np.int8)
    labels[np.arange(len(targets)), targets] = 1
    per_query = {}
    for method, scores in score_matrices.items():
        ranks = np.asarray(
            [
                conservative_ranks(scores[index], targets[index])
                for index in range(len(targets))
            ]
        )
        query_ap = np.asarray(
            [
                average_precision_score(labels[index], scores[index])
                for index in range(len(targets))
            ]
        )
        per_query[method] = {
            "ranks": ranks,
            "query_ap": query_ap,
            "metrics": {
                "recall_at_1": float((ranks < 1).mean()),
                "recall_at_3": float((ranks < 3).mean()),
                "recall_at_5": float((ranks < 5).mean()),
                "recall_at_10": float((ranks < 10).mean()),
                "mrr": float((1.0 / (ranks + 1.0)).mean()),
                "phase_ap_macro": float(query_ap.mean()),
            },
        }

    rng = np.random.default_rng(SEED)
    selected_queries = rng.integers(
        0,
        len(targets),
        size=(BOOTSTRAP_REPEATS, len(targets)),
    )
    bootstrap = {
        method: {
            endpoint: np.empty(BOOTSTRAP_REPEATS)
            for endpoint in (
                "recall_at_1",
                "recall_at_3",
                "recall_at_5",
                "mrr",
                "phase_ap_macro",
            )
        }
        for method in score_matrices
    }
    for repeat, sample in enumerate(selected_queries):
        for method in score_matrices:
            ranks = per_query[method]["ranks"][sample]
            query_ap = per_query[method]["query_ap"][sample]
            bootstrap[method]["recall_at_1"][repeat] = np.mean(ranks < 1)
            bootstrap[method]["recall_at_3"][repeat] = np.mean(ranks < 3)
            bootstrap[method]["recall_at_5"][repeat] = np.mean(ranks < 5)
            bootstrap[method]["mrr"][repeat] = np.mean(1.0 / (ranks + 1.0))
            bootstrap[method]["phase_ap_macro"][repeat] = query_ap.mean()

    methods = {}
    for method, values in per_query.items():
        methods[method] = {
            **values["metrics"],
            "bootstrap_ci95": {
                endpoint: percentile(samples)
                for endpoint, samples in bootstrap[method].items()
            },
        }

    comparisons = {}
    for left, right in (
        ("crystalshift_adapted_20", "global_sqrt_pearson"),
        ("crystalshift_adapted_20", "window_sqrt_pearson"),
        ("window_sqrt_pearson", "global_sqrt_pearson"),
    ):
        name = f"{left}_minus_{right}"
        comparisons[name] = {
            endpoint: {
                "estimate": methods[left][endpoint] - methods[right][endpoint],
                "ci95": percentile(
                    bootstrap[left][endpoint] - bootstrap[right][endpoint]
                ),
            }
            for endpoint in bootstrap[left]
        }

    query_table = pd.DataFrame(
        {
            "query_id": [row["query_id"] for row in query_order],
            "uid": query_uids,
            "target_candidate_id": [
                target_by_query[row["query_id"]] for row in query_order
            ],
            **{
                f"{method}_rank": values["ranks"]
                for method, values in per_query.items()
            },
            **{
                f"{method}_ap": values["query_ap"]
                for method, values in per_query.items()
            },
        }
    )
    query_table.to_csv(
        args.out / "query_metrics.csv",
        index=False,
        lineterminator="\n",
    )

    report = {
        "status": "realbind20_evaluated",
        "claim_boundary": (
            "External retrospective single-phase boundary panel. The "
            "CrystalShift run is a local adapted execution, not an independent "
            "execution and not multiphase validation."
        ),
        "contract": {
            "queries": len(query_order),
            "candidates": len(candidate_order),
            "bootstrap_repeats": BOOTSTRAP_REPEATS,
            "seed": SEED,
            "tie_rule": "conservative",
        },
        "inputs": {
            "source_npz_sha256": sha256(args.source_npz),
            "selection_sha256": sha256(args.dataset / "selection.json"),
            "predictions_sha256": sha256(args.predictions),
            "protocol_sha256": sha256(args.protocol),
        },
        "methods": methods,
        "paired_deltas": comparisons,
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "evaluation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"evaluation_sha256={sha256(args.out / 'evaluation.json')}")
    print(f"query_metrics_sha256={sha256(args.out / 'query_metrics.csv')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
