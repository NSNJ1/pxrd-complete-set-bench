"""Prepare the leakage-corrected RealBind 20-candidate panel."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter

SEED = 20261125
WAVELENGTH_ANGSTROM = 0.70932
Q_GRID_ANGSTROM_INV = np.linspace(0.5, 6.5, 1024)
PANEL_SIZE = 20


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(seed: int, role: str, uid: str) -> str:
    return hashlib.sha256(f"{seed}|{role}|{uid}".encode()).hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-npz", type=Path, required=True)
    parser.add_argument("--structures", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    with np.load(args.source_npz, allow_pickle=True) as payload:
        query_profiles = np.asarray(payload["X_query"], dtype=np.float64)
        query_masks = np.asarray(payload["M_query"], dtype=bool)
        query_uids = np.asarray(payload["query_uid"]).astype(str)
        candidate_uids = np.asarray(payload["cand_uid"]).astype(str)
        targets = np.asarray(payload["target"], dtype=int)
    if len(query_profiles) != 104 or len(candidate_uids) != 104:
        raise ValueError("expected the 104 x 104 RealBind mini source")
    if not np.array_equal(targets, np.arange(len(targets))):
        raise ValueError("this protocol requires the one-to-one RealBind mini grid")
    if not np.array_equal(query_uids, candidate_uids):
        raise ValueError("query and candidate identities must coincide")

    structures = pd.read_parquet(args.structures).set_index("uid")
    selected = []
    for source_index in sorted(
        range(len(candidate_uids)),
        key=lambda index: digest(SEED, "selection", candidate_uids[index]),
    ):
        uid = candidate_uids[source_index]
        if uid not in structures.index:
            continue
        try:
            structure = Structure.from_dict(
                json.loads(structures.at[uid, "structure_json"])
            )
        except (KeyError, TypeError, ValueError, json.JSONDecodeError):
            continue
        selected.append(
            {
                "source_index": source_index,
                "uid": uid,
                "structure": structure,
            }
        )
        if len(selected) == PANEL_SIZE:
            break
    if len(selected) != PANEL_SIZE:
        raise ValueError(f"only {len(selected)} structures could be prepared")

    candidates = sorted(
        selected,
        key=lambda row: digest(SEED, "candidate_order", row["uid"]),
    )
    queries = sorted(
        selected,
        key=lambda row: digest(SEED, "query_order", row["uid"]),
    )
    candidate_id_by_uid = {
        row["uid"]: f"rb20v2_c{position:02d}"
        for position, row in enumerate(candidates, start=1)
    }
    query_id_by_uid = {
        row["uid"]: f"rb20v2_q{position:02d}"
        for position, row in enumerate(queries, start=1)
    }

    dataset = args.out_dir
    spectra_dir = dataset / "spectra"
    candidate_dir = dataset / "candidates"
    spectra_dir.mkdir(parents=True, exist_ok=True)
    candidate_dir.mkdir(parents=True, exist_ok=True)

    two_theta = 2.0 * np.degrees(
        np.arcsin(
            np.clip(
                Q_GRID_ANGSTROM_INV * WAVELENGTH_ANGSTROM / (4.0 * np.pi),
                0.0,
                1.0,
            )
        )
    )
    candidate_rows = []
    for row in candidates:
        candidate_id = candidate_id_by_uid[row["uid"]]
        cif_path = candidate_dir / f"{candidate_id}.cif"
        cif_path.write_text(
            str(CifWriter(row["structure"], symprec=0.1)),
            encoding="utf-8",
            newline="\n",
        )
        candidate_rows.append(
            {
                "phase_id": candidate_id,
                "cif_file": f"candidates/{candidate_id}.cif",
                "uid": row["uid"],
                "formula": row["structure"].composition.reduced_formula,
                "sha256": sha256(cif_path),
            }
        )

    public_query_rows = []
    evaluator_query_rows = []
    truth_rows = []
    for row in queries:
        query_id = query_id_by_uid[row["uid"]]
        target_candidate_id = candidate_id_by_uid[row["uid"]]
        spectrum_path = spectra_dir / f"{query_id}.xy"
        intensity = np.clip(
            query_profiles[row["source_index"]] * query_masks[row["source_index"]],
            0.0,
            None,
        )
        maximum = float(intensity.max())
        if maximum <= 0:
            raise ValueError(f"zero measured profile for {row['uid']}")
        intensity = intensity / maximum
        spectrum_path.write_text(
            "".join(
                f"{x:.10f} {y:.12g}\n"
                for x, y in zip(two_theta, intensity, strict=True)
            ),
            encoding="utf-8",
            newline="\n",
        )
        public_query_rows.append(
            {
                "query_id": query_id,
                "spectrum_file": f"spectra/{query_id}.xy",
                "radiation": "Mo",
                "wavelength_angstrom": WAVELENGTH_ANGSTROM,
            }
        )
        evaluator_query_rows.append(
            {
                "query_id": query_id,
                "source_index": row["source_index"],
                "query_uid": row["uid"],
                "target_candidate_id": target_candidate_id,
            }
        )
        for candidate in candidate_rows:
            truth_rows.append(
                {
                    "query_id": query_id,
                    "candidate_id": candidate["phase_id"],
                    "present": int(candidate["phase_id"] == target_candidate_id),
                }
            )

    write_csv(dataset / "candidates.csv", candidate_rows)
    write_csv(dataset / "queries.csv", public_query_rows)
    write_csv(dataset / "query_targets.csv", evaluator_query_rows)
    write_csv(dataset / "truth.csv", truth_rows)
    (dataset / "selection.json").write_text(
        json.dumps(
            {
                "status": "realbind20_v2_selection_frozen",
                "seed": SEED,
                "panel_size": PANEL_SIZE,
                "source_npz_sha256": sha256(args.source_npz),
                "structures_sha256": sha256(args.structures),
                "candidate_order": [
                    {
                        "candidate_id": candidate_id_by_uid[row["uid"]],
                        "source_index": row["source_index"],
                        "uid": row["uid"],
                    }
                    for row in candidates
                ],
                "query_order": evaluator_query_rows,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {
                "status": "realbind20_v2_prepared",
                "queries": len(public_query_rows),
                "candidates": len(candidate_rows),
                "truth_rows": len(truth_rows),
                "public_truth_columns": list(public_query_rows[0]),
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
