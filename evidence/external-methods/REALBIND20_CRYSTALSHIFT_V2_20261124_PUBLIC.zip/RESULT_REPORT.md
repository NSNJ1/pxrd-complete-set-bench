# RealBind 20-candidate CrystalShift stress result

## Scope

This is a 20-query, 20-candidate boundary panel using measured single-phase
opXRD records from RealBind mini. It is retrospective. CrystalShift was run
locally with the frozen adapter and is not an independent execution.

## Acceptance

- 20/20 queries completed;
- 400 expected crystal-structure prediction rows;
- 20 independent candidate CIFs;
- public queries contain no source UID or target;
- V1, which exposed a shortcut-prone metadata layout, is excluded.

## Results

| Method | Phase AP | Top-1 has a true phase | all@3 | all@5 |
| --- | ---: | ---: | ---: | ---: |
| Random | 15.6% | 5.0% | 10.0% | 25.0% |
| Global Pearson | 90.8% | 85.0% | 100.0% | 100.0% |
| Eight-window Pearson | 100.0% | 100.0% | 100.0% | 100.0% |
| CrystalShift adapted | 84.2% | 75.0% | 90.0% | 100.0% |

CrystalShift minus eight-window Pearson:

- phase AP: -0.1583, 95% cluster-bootstrap interval -0.2875 to -0.0500;
- Recall@1: -25 percentage points, interval -45 to -10;
- Recall@3: -10 percentage points, interval -25 to 0.

CrystalShift minus global Pearson is not significant for Recall@1 or MRR. The
scientifically defensible conclusion is narrower: on this low-cardinality
single-phase boundary panel, the more elaborate external implementation did
not beat the simplest strong spectral baseline.

## Reproduction

The first and second formal runs produced byte-identical prediction and set
files:

- predictions SHA-256:
  `58b832b19da0a90c404cb2396ff1ee1dc9f1d5d8832e00f6faef8644e1ff6910`;
- sets SHA-256:
  `7a3c99448ce7656c855749efdfc685982eb78857bb31c3276a931689d6a8e635`;
- evaluation SHA-256:
  `a730d6e22ea6e232df06a48ff92698bf9b197b89e61f33c59b63ce69999c9b0c`.

`REPRODUCTION_CHECK.json` records all equality checks. Julia emitted a
`SparseArraysExt` extension warning; all 20 queries completed and the process
exited with code 0.
