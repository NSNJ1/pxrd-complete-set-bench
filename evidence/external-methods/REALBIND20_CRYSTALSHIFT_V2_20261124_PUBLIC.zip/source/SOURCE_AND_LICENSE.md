# Source and licence

- RealBind DOI: `10.5281/zenodo.23140154`
- Mini data licence: CC BY 4.0
- Underlying measured source: opXRD, CC BY 4.0
- RealBind code licence: MIT
- Candidate structures: Crystallography Open Database, CC0 1.0

The source NPZ is included unchanged. Candidate identifiers and spectra were
frozen locally without modifying the measured intensities.
