# Evidence sanitization notice

Original evidence SHA-256: `fe70d2e921828049a368f15a9f2d28a411cfae4120a116a188b7327d8043cf32`

Only Windows user-profile path components in raw failed-command logs were replaced with `<redacted-user>`. Method outputs, environment locks, commit identifiers, exit codes, and method parameters were not changed.
