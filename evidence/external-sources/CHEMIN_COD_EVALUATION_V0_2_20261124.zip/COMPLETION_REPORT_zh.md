# NASA CheMin 外部 benchmark v0.2 完成报告

日期：2026-11-24  
状态：`blind_public_handoff_audit_passed`

## 先给结论

这次补上的不是一个普通数据文件，而是一条新的、仪器与地质背景都不同的实测
外部来源：NASA MSL CheMin。最终可发布版本为 `dataset_v2_cod`。

同时发现并纠正了一个比“标签是否写进 CSV”更严重的公开风险：初版 v0.1 的候选
参考谱来自 RRUFF 峰表变换。RRUFF 在 AHED 的登记页
`10.48667/pre9-s770` 链到 CC BY-NC-ND 4.0，不适合把变换后的候选谱直接放进
开放 benchmark。因此 v0.1 只保留为内部可行性审计；公开版改用明确为 CC0 1.0
的 Crystallography Open Database（COD）结构。

当前结果可以支持：

- 一个许可证边界清楚、标签隐藏、双跑完全一致的外部 PXRD benchmark；
- 44 条实测 CheMin 多相谱、20 个矿物族候选、58 条 COD 参考谱；
- 41 个样品组、880 个 query-candidate truth cell；
- 严格按样品组重采样的 10,000 次 bootstrap；
- 对 v1 内部候选与 v2 公开候选的清楚分离，不把不可再分发数据混入公开包。

当前结果不能支持：

- 声称我们的模型已经在 CheMin 上超过频率先验；
- 把 CheMin 称为前瞻验证；
- 声称已经解决开放世界未知相识别；
- 仅凭这一来源就宣称整篇论文与所有一区同类论文完全平齐。

## 为什么必须换参考库

| 项目 | v0.1 内部版 | v0.2 公开版 |
| --- | --- | --- |
| 实测查询 | NASA CheMin | 同一批 NASA CheMin |
| 候选来源 | RRUFF + 少量 Materials Project | COD |
| 候选谱再分发 | 不适宜公开 | 允许 |
| 公开状态 | 内部审计 | blind handoff 已通过 |
| 参考谱数量 | 52 | 58 |

RRUFF 记录本身可以用于内部研究，但 AHED 登记页的许可链接是
CC BY-NC-ND 4.0。ND 会限制分享改编材料，而由峰表展开为连续参考谱正是改编。
继续把 v0.1 称为“开放、可复现 benchmark”会留下真实的法律风险。

COD 首页明确写明数据库与数据均为公共领域，采用 CC0 1.0。v0.2 在
`evaluator/reference_provenance.csv` 中逐条保留 COD 编号、原始作者、文章、
DOI、CIF URL 和哈希，以满足学术致谢；公开 blind 包只保留不透明 ID 与数值谱。

## 任务定义

任务不是生成新的晶体结构，也不是开放式发现未知矿物。任务是：

> 给定一条实测 Co K-alpha CheMin 粉晶衍射谱和一个冻结的 20 族候选库，
> 对候选族排序，使真实 reported phase families 尽可能进入固定审阅预算。

这是一个 `closed-library, known-family, complete-set retrieval` 任务。

数据规模：

- 44 条查询谱；
- 20 个候选矿物族；
- 58 条参考谱；
- 每条谱真实包含 6-10 个族，平均 8.159 个；
- 41 个样品组；
- 38 个组只有一条谱，3 个组有两条谱；
- 所有重复分析按样品组绑定，不按单个文件拆开。

## 泄漏控制

最终 blind 包有 107 个 ZIP 条目，公开数据树有 104 个文件：

- 44 条原始谱；
- 58 条参考谱；
- `queries.csv` 和 `candidates.csv`；
- 没有 `truth.csv`；
- 没有 evaluator 文件；
- 没有 CheMin MIN/RDA 产品 ID；
- 没有样品名；
- 没有矿物族名或别名；
- 没有 COD 编号；
- 没有 fold 或 sample-group 元数据。

独立审计同时检查了：

- 所有 106 个被列出的文件哈希；
- ZIP CRC；
- 固定时间戳；
- ZIP comment；
- 加密标志；
- truth/evaluator 路径；
- query 与 reference 的精确重复；
- reference 网格和最大值归一化。

结果为 0 个泄漏命中、0 个重复谱、0 个重复参考谱。

## 复现结果

两次独立的本地完整运行结果：

- `evaluation.json` 字节完全一致；
- `predictions.csv` 字节完全一致；
- canonical SHA-256：
  `4d385a83009c0c1f47864910ece64b3e055453736bd4395ed6f5e89069519cc3`；
- predictions SHA-256：
  `2b9723620348a533f15217e3547a12aa4e1ce374deba835b2aa13670a1f42d5b`。

blind ZIP 重复构建两次：

- SHA-256 均为
  `2e3134fad775b8992284a7f7855b12dad2307d158c0c109087b847daee4c1231`；
- 705,444 bytes；
- 107 entries；
- 完全字节一致。

## v0.2 基线结果

所有区间按 41 个 CheMin 样品组重采样，10,000 repeats，seed 20261124。

| 方法 | Micro AP | Macro AP | Top-1 hit | Recall@1 | Recall@8 | AllPresent@8 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| hash random | 0.4020 | 0.4723 | 0.2955 | 0.0353 | 0.4154 | 0.0000 |
| leave-group-out prior | 0.8520 | 0.8827 | 0.9773 | 0.1215 | 0.7828 | 0.0682 |
| global sqrt Pearson | 0.6408 | 0.7291 | 1.0000 | 0.1253 | 0.6205 | 0.0000 |
| eight-window sqrt Pearson | 0.6785 | 0.7085 | 1.0000 | 0.1253 | 0.5709 | 0.0000 |

Window Pearson minus prior：

- Micro AP：`-0.1735`，95% CI `[-0.2257, -0.1187]`；
- Macro AP：`-0.1743`，95% CI `[-0.2179, -0.1278]`；
- Top-1 hit：`+0.0227`，95% CI `[0.0000, 0.0714]`；
- Recall@1：`+0.0038`，95% CI `[0.0000, 0.0119]`；
- AllPresent@8：`-0.0682`，95% CI `[-0.1523, 0.0000]`。

因此预先冻结的“谱匹配必须同时改善 micro AP 和 macro AP”门槛失败。这个结论
不是“谱没有信息”，因为简单谱匹配的 Top-1 命中是 100%，而频率先验是 97.7%；
它说明在当前非常偏斜的 CheMin 矿物先验下，频率基线在整组 AP 与完整集合上更强。

论文必须写成：

> 新外部来源本身有效，但它暴露的是 prevalence shortcut；
> 当前 simple profile baselines 没有在整体 AP 上超过 leak-free prior。

不能写成：

> 我们的谱方法在 CheMin 上达到 state of the art。

## 候选可辨识性

20 个候选族共有 190 个两两组合。

- 最大跨族参考谱 Pearson 是 Bassanite-Anhydrite 的 0.7322；
- 高于 0.98 的组合数为 0；
- 高于 0.995 的组合数为 0；
- 无精确重复参考谱。

这说明当前 COD 候选库没有因为候选谱几乎相同而把任务人为做坏。Bassanite 与
Anhydrite 同属硫酸钙水化体系，相似是矿物学上合理的难点，不是标签泄漏。

## 与一区标准的距离

CheMin 补上了真正的跨仪器、跨地质背景、Co K-alpha 来源，且许可清楚、盲包审计
通过。项目综合评分从 `8.97/10` 谨慎上调到约 `9.04/10`。这是项目审查分，不是
期刊接收概率。

但“完整一区平齐”仍不能宣布，剩余三个硬缺口没有变化：

1. 前瞻来源：CheMin 仍是公开历史数据，不是标签冻结后才采到的前瞻样本；
2. 核心七来源的结构/prototype 近重复审计仍未全部完成；
3. 最终正文和主图仍需作者重写、统一证据边界和生产级排版。

CheMin 的价值在于把“数据覆盖与许可可公开性”一项补强，而不是把 retrospective
来源伪装成 prospective 证据。

## 下一步最高收益

不再对 CheMin 调 Pearson 窗口、平滑或权重。那只会用同一批 44 条谱增加过拟合。

按收益排序：

1. 完成核心来源的结构/prototype 近重复审计；
2. 锁定一个标签未见的前瞻多相来源；
3. 把 CheMin v0.2 整合进项目公开 release，并完成独立复现；
4. 作者按 benchmark 论文逻辑重写正文和主图。

## 文件位置

- 公开 blind ZIP：
  `handoff/chemin_cod_public_v0_2.zip`
- 独立审计：
  `handoff/PUBLIC_HANDOFF_AUDIT.json`
- v0.2 协议：
  `PROTOCOL_COD_V0_2.md`
- v0.2 预冻结评估计划：
  `EVALUATION_PLAN_COD_V0_2.md`
- 第一次完整评估：
  `runs/cod_run_a_20261124/evaluation.json`
- 第二次完整评估：
  `runs/cod_run_b_20261124/evaluation.json`
- 参考来源逐条记录：
  `dataset_v2_cod/evaluator/reference_provenance.csv`

