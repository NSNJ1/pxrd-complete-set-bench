"""Build and audit a deterministic blind public CheMin handoff."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

import pandas as pd

DOC_DATE = (2026, 11, 24, 0, 0, 0)
README = """# CheMin closed-library complete-set benchmark v0.2

This package contains a blind evaluation input for closed-library,
known-family retrieval from measured Mars CheMin X-ray diffraction patterns.

## Task

For each query spectrum, rank the candidate families so that every family
reported by the source enters a fixed review budget.

## Files

- `queries.csv`: opaque query IDs, Co K-alpha wavelength and spectrum paths.
- `candidates.csv`: opaque candidate-family IDs and numeric reference-profile
  paths.
- `spectra/`: raw measured two-column spectra.
- `reference_profiles/`: structure-derived profiles on a common normalized
  grid.
- `PUBLIC_MANIFEST.json`: counts, contracts and hashes.
- `CHECKSUMS.sha256`: per-file SHA-256 values.

## Evaluation boundary

This is retrospective, closed-library and known-family retrieval. It does not
tell whether a candidate is absent from the source catalogue, and it does not
measure amorphous content, phases below the reporting limit or prospective
performance.

The query labels, sample groups and candidate provenance are intentionally
withheld from this blind package. A method must not be described as label-blind
if the executor has access to those withheld files.

## Licences and attribution

- Measured spectra: NASA Planetary Data System, MSL CheMin derived products.
  Cite the PDS dataset and the release used by the benchmark.
- Candidate reference structures: Crystallography Open Database records
  dedicated to the public domain under CC0 1.0.
- Project-created derived profiles and documentation: CC BY 4.0.

No non-redistributable upstream candidate profiles are included.
"""


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def forbidden_tokens(dataset: Path) -> set[str]:
    families = json.loads(
        (dataset / "evaluator/candidate_families.json").read_text(
            encoding="utf-8"
        )
    )
    values = {"RRUFF", "COD"}
    for family in families:
        values.add(str(family["family"]))
        values.update(
            alias
            for alias in str(family.get("aliases", "")).split("|")
            if alias
        )
        for reference in family["references"]:
            for key in ("mineral", "chemname", "cod_id"):
                value = reference.get(key)
                if value:
                    values.add(str(value))
    return {
        value.strip().upper()
        for value in values
        if len(value.strip()) >= 3
    }


def zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=DOC_DATE)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    return info


def write_text_entry(
    archive: zipfile.ZipFile,
    name: str,
    text: str,
) -> None:
    archive.writestr(zip_info(name), text.encode("utf-8"))


def public_manifest(dataset: Path, public_files: list[Path]) -> dict:
    queries = pd.read_csv(dataset / "public/queries.csv")
    candidates = pd.read_csv(dataset / "public/candidates.csv")
    return {
        "status": "chemin_public_blind_v0_2",
        "queries": len(queries),
        "candidate_families": candidates["candidate_id"].nunique(),
        "reference_profiles": candidates["reference_id"].nunique(),
        "spectra": len(list((dataset / "public/spectra").glob("*.xy"))),
        "radiation": "Co",
        "wavelength_angstrom": 1.78897,
        "reference_grid": {
            "minimum_two_theta_deg": 3.0,
            "maximum_two_theta_deg": 51.95,
            "points": 980,
            "fwhm_deg": 0.20,
        },
        "licenses": {
            "measured_spectra": (
                "NASA PDS CheMin derived products; cite the upstream PDS "
                "dataset and release"
            ),
            "reference_structures": "CC0-1.0 (Crystallography Open Database)",
            "project_derived_profiles": "CC BY 4.0",
        },
        "claim_boundary": (
            "Retrospective closed-library known-family retrieval; query labels "
            "and candidate provenance are withheld from this blind package."
        ),
        "files": {
            path.relative_to(dataset / "public").as_posix(): sha256(path)
            for path in public_files
        },
    }


def scan_archive(path: Path, forbidden: set[str]) -> dict:
    hits = set()
    names = []
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            names.append(info.filename)
            if info.comment:
                hits.update(
                    token
                    for token in forbidden
                    if token in info.comment.decode("utf-8", "ignore").upper()
                )
            upper_name = info.filename.upper()
            hits.update(token for token in forbidden if token in upper_name)
            if info.is_dir():
                continue
            raw = archive.read(info)
            if b"\x00" in raw[:4096]:
                continue
            text = raw.decode("utf-8", errors="ignore").upper()
            hits.update(token for token in forbidden if token in text)
    return {
        "entries": len(names),
        "names": names,
        "forbidden_hits": sorted(hits),
        "zip_comments_present": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError(f"refusing to overwrite {args.out}")
    args.out.parent.mkdir(parents=True, exist_ok=True)

    public_root = args.dataset / "public"
    public_files = sorted(
        path for path in public_root.rglob("*") if path.is_file()
    )
    manifest = public_manifest(args.dataset, public_files)
    manifest_text = (
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2)
        + "\n"
    )
    file_hashes = {
        path.relative_to(public_root).as_posix(): sha256(path)
        for path in public_files
    }
    file_hashes["README.md"] = hashlib.sha256(README.encode("utf-8")).hexdigest()
    file_hashes["PUBLIC_MANIFEST.json"] = hashlib.sha256(
        manifest_text.encode("utf-8")
    ).hexdigest()
    checksum_text = "".join(
        f"{digest}  {name}\n"
        for name, digest in sorted(file_hashes.items())
    )

    with zipfile.ZipFile(
        args.out,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        write_text_entry(archive, "README.md", README)
        write_text_entry(archive, "PUBLIC_MANIFEST.json", manifest_text)
        write_text_entry(archive, "CHECKSUMS.sha256", checksum_text)
        for path in public_files:
            archive.writestr(
                zip_info(path.relative_to(public_root).as_posix()),
                path.read_bytes(),
            )

    forbidden = forbidden_tokens(args.dataset)
    audit = scan_archive(args.out, forbidden)
    if audit["forbidden_hits"]:
        raise ValueError(
            f"blind handoff contains forbidden tokens: {audit['forbidden_hits']}"
        )
    expected = {
        "README.md",
        "PUBLIC_MANIFEST.json",
        "CHECKSUMS.sha256",
        *[
            path.relative_to(public_root).as_posix()
            for path in public_files
        ],
    }
    if set(audit["names"]) != expected:
        raise ValueError("blind handoff entries differ from the intended tree")

    report = {
        "status": "chemin_blind_handoff_built",
        "archive": args.out.name,
        "archive_sha256": sha256(args.out),
        "archive_bytes": args.out.stat().st_size,
        "entries": audit["entries"],
        "forbidden_hits": audit["forbidden_hits"],
        "contains_truth": any(
            re.search(r"(^|/)truth\.csv$", name, re.IGNORECASE)
            for name in audit["names"]
        ),
        "contains_evaluator_files": any(
            name.startswith("evaluator/") for name in audit["names"]
        ),
    }
    if report["contains_truth"] or report["contains_evaluator_files"]:
        raise ValueError("private evaluation material leaked into blind handoff")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
