"""Independent integrity and leakage audit of the blind CheMin handoff."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import re
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

EXPECTED_TIMESTAMP = (2026, 11, 24, 0, 0, 0)


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def file_sha256(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def source_terms(dataset: Path) -> tuple[set[str], set[str]]:
    families = json.loads(
        (dataset / "evaluator/candidate_families.json").read_text(
            encoding="utf-8"
        )
    )
    labels = set()
    cod_ids = set()
    for family in families:
        labels.add(str(family["family"]))
        labels.update(
            item
            for item in str(family.get("aliases", "")).split("|")
            if item
        )
        for reference in family["references"]:
            for key in ("mineral", "chemname"):
                if reference.get(key):
                    labels.add(str(reference[key]))
            if reference.get("cod_id"):
                cod_ids.add(str(reference["cod_id"]))
    labels.update({"RRUFF"})
    return (
        {
            value.strip().upper()
            for value in labels
            if len(value.strip()) >= 3
        },
        cod_ids,
    )


def read_checksums(raw: bytes) -> dict[str, str]:
    result = {}
    for line in raw.decode("utf-8").splitlines():
        digest, name = line.split("  ", 1)
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError(f"invalid checksum line: {line!r}")
        if name in result:
            raise ValueError(f"duplicate checksum entry: {name}")
        result[name] = digest
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--repeat-archive", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    labels, cod_ids = source_terms(args.dataset)
    entries = {}
    timestamps = set()
    comments = []
    encrypted = []
    with zipfile.ZipFile(args.archive) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC test failed")
        for info in archive.infolist():
            if info.is_dir():
                raise ValueError("directory entries are not permitted")
            if info.filename in entries:
                raise ValueError(f"duplicate ZIP entry: {info.filename}")
            if info.flag_bits & 0x1:
                encrypted.append(info.filename)
            if info.comment:
                comments.append(info.filename)
            timestamps.add(info.date_time)
            entries[info.filename] = archive.read(info)

    if timestamps != {EXPECTED_TIMESTAMP}:
        raise ValueError(f"non-deterministic ZIP timestamps: {sorted(timestamps)}")
    if comments or encrypted:
        raise ValueError(
            f"ZIP comments/encryption present: {comments}, {encrypted}"
        )

    required = {
        "README.md",
        "PUBLIC_MANIFEST.json",
        "CHECKSUMS.sha256",
        "queries.csv",
        "candidates.csv",
    }
    missing = required - set(entries)
    if missing:
        raise ValueError(f"required ZIP entries missing: {sorted(missing)}")
    if any(
        re.search(r"(^|/)truth\.csv$", name, re.IGNORECASE)
        or name.startswith("evaluator/")
        for name in entries
    ):
        raise ValueError("private evaluator files are present")

    manifest = json.loads(entries["PUBLIC_MANIFEST.json"].decode("utf-8"))
    queries = pd.read_csv(io.BytesIO(entries["queries.csv"]))
    candidates = pd.read_csv(io.BytesIO(entries["candidates.csv"]))
    if len(queries) != 44:
        raise ValueError("expected 44 queries")
    if candidates["candidate_id"].nunique() != 20:
        raise ValueError("expected 20 candidate families")
    if candidates["reference_id"].nunique() != 58:
        raise ValueError("expected 58 reference profiles")

    expected_entries = {
        "README.md",
        "PUBLIC_MANIFEST.json",
        "CHECKSUMS.sha256",
        "queries.csv",
        "candidates.csv",
    }
    expected_entries.update(queries["spectrum_file"].astype(str))
    expected_entries.update(candidates["profile_file"].astype(str))
    if set(entries) != expected_entries:
        raise ValueError(
            "ZIP entry set differs from query/candidate manifest: "
            f"missing={sorted(expected_entries - set(entries))}, "
            f"extra={sorted(set(entries) - expected_entries)}"
        )

    checksums = read_checksums(entries["CHECKSUMS.sha256"])
    if set(checksums) != set(entries) - {"CHECKSUMS.sha256"}:
        raise ValueError("checksum coverage is incomplete")
    checksum_mismatches = [
        name
        for name, digest in checksums.items()
        if sha256_bytes(entries[name]) != digest
    ]
    if checksum_mismatches:
        raise ValueError(f"checksum mismatches: {checksum_mismatches}")

    text_hits = set()
    name_hits = set()
    for name, payload in entries.items():
        upper_name = name.upper()
        name_hits.update(item for item in labels if item in upper_name)
        name_hits.update(item for item in cod_ids if item in upper_name)
        text = payload.decode("utf-8", errors="ignore").upper()
        text_hits.update(item for item in labels if item in text)
    if text_hits or name_hits:
        raise ValueError(
            f"forbidden source terms in handoff: text={sorted(text_hits)}, "
            f"names={sorted(name_hits)}"
        )

    spectrum_hashes = []
    query_ids = queries["query_id"].astype(str).tolist()
    if len(query_ids) != len(set(query_ids)):
        raise ValueError("duplicate public query ID")
    if not all(re.fullmatch(r"cheminq_\d{3}", value) for value in query_ids):
        raise ValueError("unexpected public query-ID format")
    for row in queries.itertuples(index=False):
        payload = entries[str(row.spectrum_file)]
        spectrum_hashes.append(sha256_bytes(payload))
        points = np.loadtxt(io.BytesIO(payload), dtype=np.float64)
        if points.ndim != 2 or points.shape[1] != 2:
            raise ValueError(f"invalid spectrum shape: {row.spectrum_file}")
        if not np.isfinite(points).all() or points[:, 1].min() < 0:
            raise ValueError(f"invalid spectrum values: {row.spectrum_file}")
        if np.any(np.diff(points[:, 0]) <= 0):
            raise ValueError(f"unsorted spectrum angle: {row.spectrum_file}")
    if len(spectrum_hashes) != len(set(spectrum_hashes)):
        raise ValueError("duplicate public spectra")

    profile_hashes = []
    expected_grid = None
    candidate_ids = sorted(candidates["candidate_id"].astype(str).unique())
    if not all(re.fullmatch(r"chemins_\d{3}", value) for value in candidate_ids):
        raise ValueError("unexpected public candidate-ID format")
    for row in candidates.itertuples(index=False):
        payload = entries[str(row.profile_file)]
        profile_hashes.append(sha256_bytes(payload))
        frame = pd.read_csv(io.BytesIO(payload))
        if list(frame.columns) != [
            "two_theta_deg",
            "intensity_normalized",
        ]:
            raise ValueError(f"invalid reference columns: {row.profile_file}")
        grid = frame["two_theta_deg"].to_numpy(dtype=np.float64)
        intensity = frame["intensity_normalized"].to_numpy(dtype=np.float64)
        if len(grid) != 980 or not np.isfinite(grid).all():
            raise ValueError(f"invalid reference grid: {row.profile_file}")
        if expected_grid is None:
            expected_grid = grid
        elif not np.allclose(grid, expected_grid, rtol=0.0, atol=1e-8):
            raise ValueError("reference profiles use different grids")
        if (
            not np.isfinite(intensity).all()
            or intensity.min() < 0
            or not math.isclose(
                float(intensity.max()),
                1.0,
                rel_tol=0.0,
                abs_tol=1e-9,
            )
        ):
            raise ValueError(f"invalid reference intensity: {row.profile_file}")
    if len(profile_hashes) != len(set(profile_hashes)):
        raise ValueError("duplicate public reference profiles")

    repeat_identical = None
    if args.repeat_archive is not None:
        repeat_identical = file_sha256(args.archive) == file_sha256(
            args.repeat_archive
        )
        if not repeat_identical:
            raise ValueError("repeated handoff archives are not byte-identical")

    report = {
        "status": "chemin_blind_handoff_audit_passed",
        "archive": args.archive.name,
        "archive_sha256": file_sha256(args.archive),
        "archive_bytes": args.archive.stat().st_size,
        "entries": len(entries),
        "queries": len(queries),
        "candidate_families": len(candidate_ids),
        "reference_profiles": len(candidates),
        "checksums_verified": len(checksums),
        "zip_crc_verified": True,
        "deterministic_timestamps": True,
        "zip_comments": 0,
        "encrypted_entries": 0,
        "truth_files": 0,
        "evaluator_files": 0,
        "forbidden_source_terms": [],
        "duplicate_query_spectra": 0,
        "duplicate_reference_profiles": 0,
        "reference_grid_points": 980,
        "reference_profiles_max_normalized": True,
        "repeat_archive_byte_identical": repeat_identical,
        "public_manifest_status": manifest["status"],
        "claim_boundary": manifest["claim_boundary"],
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
