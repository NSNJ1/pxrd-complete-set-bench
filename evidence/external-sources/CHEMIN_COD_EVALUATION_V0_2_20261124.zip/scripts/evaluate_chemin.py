"""Evaluate frozen baselines on the leakage-controlled CheMin benchmark."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import average_precision_score

SEED = 20261124
BOOTSTRAP_REPEATS = 10_000
BUDGETS = (1, 3, 5, 8)
PRIMARY_CONTRAST = "eight_window_minus_prior"
PRIMARY_ENDPOINTS = (
    "micro_ap",
    "macro_ap",
    "top1_present",
    "recall_at_1",
    "all_present_at_8",
)
METHODS = (
    "deterministic_hash_random",
    "leave_group_out_frequency",
    "global_sqrt_pearson",
    "eight_window_sqrt_pearson",
)

MANIFEST_DATASET_FILES = {
    "queries": Path("public/queries.csv"),
    "candidates": Path("public/candidates.csv"),
    "truth": Path("evaluator/truth.csv"),
    "query_metadata": Path("evaluator/query_metadata.csv"),
    "candidate_families": Path("evaluator/candidate_families.json"),
    "reference_provenance": Path("evaluator/reference_provenance.csv"),
}
SUPPORTED_MANIFEST_STATUSES = {
    "chemin_benchmark_v0_1_prepared",
    "chemin_benchmark_v0_2_cod_prepared",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def stable_digest(*parts: object) -> str:
    text = "|".join(str(part) for part in parts)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical_digest(payload: dict) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def require_columns(
    frame: pd.DataFrame,
    expected: set[str],
    name: str,
) -> None:
    missing = expected - set(frame.columns)
    extra = set(frame.columns) - expected
    if missing or extra:
        raise ValueError(
            f"{name} columns differ: missing={sorted(missing)}, "
            f"extra={sorted(extra)}"
        )


def read_profile(path: Path) -> tuple[np.ndarray, np.ndarray]:
    frame = pd.read_csv(path)
    require_columns(
        frame,
        {"two_theta_deg", "intensity_normalized"},
        path.name,
    )
    grid = frame["two_theta_deg"].to_numpy(dtype=np.float64)
    intensity = frame["intensity_normalized"].to_numpy(dtype=np.float64)
    if not np.isfinite(grid).all() or not np.isfinite(intensity).all():
        raise ValueError(f"non-finite reference profile: {path}")
    if np.any(np.diff(grid) <= 0):
        raise ValueError(f"reference grid is not strictly increasing: {path}")
    if intensity.min() < 0:
        raise ValueError(f"negative reference intensity: {path}")
    if not math.isclose(float(intensity.max()), 1.0, rel_tol=0.0, abs_tol=1e-9):
        raise ValueError(f"reference profile is not max-normalized: {path}")
    return grid, intensity


def read_spectrum(path: Path) -> tuple[np.ndarray, np.ndarray]:
    points = np.loadtxt(path, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"expected a two-column spectrum: {path}")
    if not np.isfinite(points).all():
        raise ValueError(f"non-finite spectrum: {path}")
    if np.any(np.diff(points[:, 0]) <= 0):
        raise ValueError(f"spectrum angle is not strictly increasing: {path}")
    if points[:, 1].min() < 0:
        raise ValueError(f"negative spectrum intensity: {path}")
    return points[:, 0], points[:, 1]


def resample_query(
    two_theta: np.ndarray,
    intensity: np.ndarray,
    grid: np.ndarray,
) -> np.ndarray:
    values = np.interp(grid, two_theta, intensity, left=0.0, right=0.0)
    values = np.sqrt(np.clip(values, 0.0, None))
    if float(values.std()) <= 1e-12:
        raise ValueError("spectrum has no usable variance after preprocessing")
    return values


def sqrt_profile(profile: np.ndarray) -> np.ndarray:
    values = np.sqrt(np.clip(profile, 0.0, None))
    if float(values.std()) <= 1e-12:
        raise ValueError("reference profile has no usable variance")
    return values


def pearson(left: np.ndarray, right: np.ndarray) -> float:
    left_centered = left - float(left.mean())
    right_centered = right - float(right.mean())
    denominator = float(
        np.sqrt(
            np.dot(left_centered, left_centered)
            * np.dot(right_centered, right_centered)
        )
    )
    if denominator <= 1e-15:
        return 0.0
    value = float(np.dot(left_centered, right_centered) / denominator)
    return min(1.0, max(-1.0, value))


def load_dataset(root: Path) -> dict:
    manifest_path = root / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("status") not in SUPPORTED_MANIFEST_STATUSES:
        raise ValueError("unexpected dataset manifest status")

    hash_checks = {}
    for key, relative_path in MANIFEST_DATASET_FILES.items():
        if not (root / relative_path).exists():
            continue
        observed = sha256(root / relative_path)
        expected = manifest["hashes"].get(key)
        hash_checks[key] = {
            "path": relative_path.as_posix(),
            "expected": expected,
            "observed": observed,
            "matches": observed == expected,
        }
    if not all(item["matches"] for item in hash_checks.values()):
        mismatches = [
            key for key, item in hash_checks.items() if not item["matches"]
        ]
        raise ValueError(f"dataset manifest hash mismatch: {mismatches}")

    queries = pd.read_csv(root / "public/queries.csv")
    candidates = pd.read_csv(root / "public/candidates.csv")
    truth = pd.read_csv(root / "evaluator/truth.csv")
    metadata = pd.read_csv(root / "evaluator/query_metadata.csv")
    families = json.loads(
        (root / "evaluator/candidate_families.json").read_text(encoding="utf-8")
    )
    require_columns(
        queries,
        {
            "query_id",
            "spectrum_file",
            "radiation",
            "wavelength_angstrom",
        },
        "queries.csv",
    )
    require_columns(
        candidates,
        {"candidate_id", "reference_id", "profile_file"},
        "candidates.csv",
    )
    require_columns(
        truth,
        {"query_id", "candidate_id", "present"},
        "truth.csv",
    )
    require_columns(
        metadata,
        {
            "query_id",
            "min_product_id",
            "rda_product_id",
            "sample_group",
            "fold",
        },
        "query_metadata.csv",
    )

    query_ids = tuple(sorted(queries["query_id"].astype(str).unique()))
    candidate_ids = tuple(
        sorted(candidates["candidate_id"].astype(str).unique())
    )
    reference_ids = tuple(
        sorted(candidates["reference_id"].astype(str).unique())
    )
    if len(query_ids) != 44 or len(candidate_ids) != 20:
        raise ValueError("expected 44 queries and 20 candidate families")
    if len(reference_ids) < len(candidate_ids):
        raise ValueError("each candidate family needs a reference profile")
    if len(set(reference_ids)) != len(reference_ids):
        raise ValueError("duplicate reference identifiers")
    if set(queries["query_id"]) != set(metadata["query_id"]):
        raise ValueError("query metadata does not cover the public queries")
    if set(truth["query_id"]) != set(query_ids):
        raise ValueError("truth does not cover the public queries")
    if set(truth["candidate_id"]) != set(candidate_ids):
        raise ValueError("truth does not cover the public candidates")
    if len(truth) != len(query_ids) * len(candidate_ids):
        raise ValueError("truth is not a complete query-candidate table")
    if truth.duplicated(["query_id", "candidate_id"]).any():
        raise ValueError("duplicate query-candidate truth row")
    if not truth["present"].isin([0, 1]).all():
        raise ValueError("truth labels must be binary")

    labels = (
        truth.pivot(index="query_id", columns="candidate_id", values="present")
        .reindex(index=query_ids, columns=candidate_ids)
        .to_numpy(dtype=np.int8)
    )
    if not np.isfinite(labels).all() or (labels.sum(axis=1) < 1).any():
        raise ValueError("every query must have at least one positive family")

    metadata = metadata.set_index("query_id").reindex(query_ids)
    if metadata["sample_group"].isna().any():
        raise ValueError("missing sample-group assignment")
    if metadata["sample_group"].astype(str).str.strip().eq("").any():
        raise ValueError("blank sample-group assignment")
    fold_counts = metadata.groupby("sample_group")["fold"].nunique()
    grouped_folds = bool(fold_counts.eq(1).all())
    if not grouped_folds:
        raise ValueError("sample group has inconsistent folds")

    family_rows = {row["candidate_id"]: row for row in families}
    if set(family_rows) != set(candidate_ids):
        raise ValueError("candidate-family metadata does not cover candidates")
    family_reference_ids = {
        candidate: tuple(
            sorted(reference["reference_id"] for reference in row["references"])
        )
        for candidate, row in family_rows.items()
    }
    linked_reference_ids = {
        reference
        for references in family_reference_ids.values()
        for reference in references
    }
    if linked_reference_ids != set(reference_ids):
        raise ValueError("candidate table and family metadata disagree")
    if sum(
        len(references) for references in family_reference_ids.values()
    ) != len(reference_ids):
        raise ValueError("a reference profile belongs to multiple families")

    profile_by_id = {}
    profile_hashes = {}
    grid = None
    for row in candidates.itertuples(index=False):
        reference_id = str(row.reference_id)
        profile_path = root / "public" / str(row.profile_file)
        local_grid, profile = read_profile(profile_path)
        if grid is None:
            grid = local_grid
        elif not np.allclose(local_grid, grid, rtol=0.0, atol=1e-8):
            raise ValueError("reference profiles use different grids")
        profile_by_id[reference_id] = sqrt_profile(profile)
        profile_hashes[reference_id] = sha256(profile_path)
    if grid is None or len(grid) != 980:
        raise ValueError("the frozen reference grid must have 980 points")
    if not (
        math.isclose(float(grid[0]), 3.0, abs_tol=1e-8)
        and math.isclose(float(grid[-1]), 51.95, abs_tol=1e-8)
    ):
        raise ValueError("unexpected reference-grid endpoints")

    query_matrix = []
    spectrum_hashes = []
    query_table = queries.set_index("query_id").reindex(query_ids)
    for query_id in query_ids:
        row = query_table.loc[query_id]
        spectrum_path = root / "public" / str(row["spectrum_file"])
        x, y = read_spectrum(spectrum_path)
        query_matrix.append(resample_query(x, y, grid))
        spectrum_hashes.append(sha256(spectrum_path))
    query_matrix_array = np.vstack(query_matrix)

    reference_to_family = {
        reference_id: candidate_id
        for candidate_id, references in family_reference_ids.items()
        for reference_id in references
    }
    if len(reference_to_family) != len(reference_ids):
        raise ValueError("reference-to-family mapping is not one-to-one")

    duplicate_spectra = len(spectrum_hashes) - len(set(spectrum_hashes))
    duplicate_profiles = len(profile_hashes) - len(set(profile_hashes.values()))
    if duplicate_spectra or duplicate_profiles:
        raise ValueError(
            "exact duplicate spectra or reference profiles are not allowed"
        )

    family_aliases = {}
    for candidate_id, row in family_rows.items():
        aliases = {
            str(row["family"]),
            *str(row.get("aliases", "")).split("|"),
        }
        family_aliases[candidate_id] = {
            alias.strip().upper() for alias in aliases if alias.strip()
        }
    public_audit = audit_public_tree(
        root,
        query_ids,
        reference_ids,
        family_aliases,
    )
    if public_audit["forbidden_tokens"]:
        raise ValueError(
            "mineral label tokens found in public tree: "
            f"{public_audit['forbidden_tokens']}"
        )
    if public_audit["unexpected_files"]:
        raise ValueError(
            f"unexpected public files: {public_audit['unexpected_files']}"
        )

    tree_records = []
    for path in sorted(root.rglob("*")):
        if path.is_file():
            tree_records.append(
                f"{path.relative_to(root).as_posix()} {sha256(path)}"
            )
    tree_sha256 = hashlib.sha256(
        ("\n".join(tree_records) + "\n").encode("utf-8")
    ).hexdigest()

    return {
        "root": root,
        "manifest": manifest,
        "hash_checks": hash_checks,
        "tree_sha256": tree_sha256,
        "queries": queries,
        "candidates": candidates,
        "truth": truth,
        "metadata": metadata,
        "families": family_rows,
        "query_ids": query_ids,
        "candidate_ids": candidate_ids,
        "labels": labels,
        "grid": grid,
        "query_matrix": query_matrix_array,
        "profile_by_id": profile_by_id,
        "family_reference_ids": family_reference_ids,
        "public_audit": public_audit,
        "grouped_folds": grouped_folds,
    }


def audit_public_tree(
    root: Path,
    query_ids: tuple[str, ...],
    reference_ids: tuple[str, ...],
    family_aliases: dict[str, set[str]],
) -> dict:
    public = root / "public"
    observed = {
        path.relative_to(public).as_posix()
        for path in public.rglob("*")
        if path.is_file()
    }
    expected = {"queries.csv", "candidates.csv"}
    expected.update(f"spectra/{query_id}.xy" for query_id in query_ids)
    expected.update(
        f"reference_profiles/{reference_id}.csv"
        for reference_id in reference_ids
    )
    forbidden = sorted(
        {
            alias
            for aliases in family_aliases.values()
            for alias in aliases
            if len(alias) >= 3
        }
    )
    text_records = []
    for relative_path in sorted(observed):
        path = public / relative_path
        text_records.append(relative_path.upper())
        try:
            text_records.append(
                path.read_text(encoding="utf-8", errors="ignore").upper()
            )
        except OSError as error:
            raise ValueError(f"cannot read public file: {path}") from error
    public_text = "\n".join(text_records)
    forbidden_hits = sorted(
        token for token in forbidden if token.upper() in public_text
    )
    source_metadata_hits = sorted(
        token
        for token in (
            "MIN_PRODUCT",
            "RDA_PRODUCT",
            "SAMPLE_GROUP",
            "QUERY_METADATA",
            "TRUTH",
            "COD",
            "RRUFF",
        )
        if token in public_text
    )
    return {
        "files": len(observed),
        "expected_files": len(expected),
        "unexpected_files": sorted(observed - expected),
        "missing_files": sorted(expected - observed),
        "public_truth_file_present": (public / "truth.csv").exists(),
        "forbidden_tokens": sorted(set(forbidden_hits + source_metadata_hits)),
        "label_token_scan": (
            "UTF-8 text content and relative filenames; public package has no "
            "ZIP container in the frozen dataset"
        ),
    }


def ranking_token(
    query_id: str,
    candidate_id: str,
) -> int:
    return int(
        stable_digest("rank_tie", query_id, candidate_id, SEED)[:16],
        16,
    )


def ranking_order(
    scores: np.ndarray,
    tie_tokens: np.ndarray,
) -> np.ndarray:
    if scores.shape != tie_tokens.shape:
        raise ValueError("score and tie-token matrices must have equal shape")
    return np.lexsort((tie_tokens, -scores), axis=1)


def random_scores(
    query_ids: tuple[str, ...],
    candidate_ids: tuple[str, ...],
) -> np.ndarray:
    return np.asarray(
        [
            [
                int(
                    stable_digest("random_score", SEED, query_id, candidate_id)[
                        :16
                    ],
                    16,
                )
                / float(2**64)
                for candidate_id in candidate_ids
            ]
            for query_id in query_ids
        ],
        dtype=np.float64,
    )


def leave_group_out_frequency(
    labels: np.ndarray,
    query_ids: tuple[str, ...],
    metadata: pd.DataFrame,
) -> np.ndarray:
    groups = metadata["sample_group"].astype(str).to_numpy()
    scores = np.empty_like(labels, dtype=np.float64)
    for query_index, query_id in enumerate(query_ids):
        current_group = groups[query_index]
        outside = groups != current_group
        if not outside.any():
            raise ValueError(
                f"no out-of-group queries available for prior of {query_id}"
            )
        scores[query_index] = labels[outside].mean(axis=0)
    return scores


def reference_correlations(
    query_vector: np.ndarray,
    profiles: np.ndarray,
) -> np.ndarray:
    centered_query = query_vector - float(query_vector.mean())
    centered_profiles = profiles - profiles.mean(axis=1, keepdims=True)
    numerator = centered_profiles @ centered_query
    denominator = np.sqrt(
        np.sum(centered_profiles * centered_profiles, axis=1)
        * float(np.dot(centered_query, centered_query))
    )
    result = np.zeros(len(profiles), dtype=np.float64)
    usable = denominator > 1e-15
    result[usable] = numerator[usable] / denominator[usable]
    return np.clip(result, -1.0, 1.0)


def family_max_scores(
    reference_scores: np.ndarray,
    reference_ids: tuple[str, ...],
    candidate_ids: tuple[str, ...],
    family_reference_ids: dict[str, tuple[str, ...]],
) -> np.ndarray:
    reference_index = {
        reference_id: index
        for index, reference_id in enumerate(reference_ids)
    }
    result = np.empty(
        (reference_scores.shape[0], len(candidate_ids)),
        dtype=np.float64,
    )
    for candidate_index, candidate_id in enumerate(candidate_ids):
        indices = [
            reference_index[reference_id]
            for reference_id in family_reference_ids[candidate_id]
        ]
        result[:, candidate_index] = reference_scores[:, indices].max(axis=1)
    return result


def spectral_scores(
    dataset: dict,
    windowed: bool,
) -> tuple[np.ndarray, dict]:
    query_matrix = dataset["query_matrix"]
    reference_ids = tuple(
        sorted(dataset["profile_by_id"])
    )
    profiles = np.vstack(
        [dataset["profile_by_id"][reference_id] for reference_id in reference_ids]
    )
    if windowed:
        windows = [
            block
            for block in np.array_split(
                np.arange(len(dataset["grid"])),
                8,
            )
            if len(block) >= 8
        ]
        reference_scores = np.empty(
            (query_matrix.shape[0], len(reference_ids)),
            dtype=np.float64,
        )
        for query_index, query_vector in enumerate(query_matrix):
            window_scores = np.zeros(
                (len(windows), len(reference_ids)),
                dtype=np.float64,
            )
            active = np.zeros_like(window_scores, dtype=bool)
            for window_index, block in enumerate(windows):
                local_scores = reference_correlations(
                    query_vector[block],
                    profiles[:, block],
                )
                window_scores[window_index] = local_scores
                active[window_index] = (
                    np.std(profiles[:, block], axis=1) > 1e-12
                )
            active_count = active.sum(axis=0)
            if (active_count == 0).any():
                raise ValueError("a reference profile has no active windows")
            reference_scores[query_index] = (
                window_scores * active
            ).sum(axis=0) / active_count
        window_records = [
            {
                "start_deg": float(dataset["grid"][block[0]]),
                "end_deg": float(dataset["grid"][block[-1]]),
                "points": len(block),
            }
            for block in windows
        ]
        preprocessing = {
            "transform": "sqrt(clip(intensity, 0, inf))",
            "resampling": "linear interpolation onto the frozen reference grid",
            "window_count_requested": 8,
            "window_count": len(windows),
            "windows": window_records,
            "window_score": (
                "per reference, unweighted mean Pearson across windows where "
                "that reference has nonzero variance"
            ),
        }
    else:
        reference_scores = np.vstack(
            [
                reference_correlations(query_vector, profiles)
                for query_vector in query_matrix
            ]
        )
        preprocessing = {
            "transform": "sqrt(clip(intensity, 0, inf))",
            "resampling": "linear interpolation onto the frozen reference grid",
            "score": "global Pearson correlation",
        }
    family_scores = family_max_scores(
        reference_scores,
        reference_ids,
        dataset["candidate_ids"],
        dataset["family_reference_ids"],
    )
    return family_scores, preprocessing


def metric_values(
    labels: np.ndarray,
    scores: np.ndarray,
    query_ids: tuple[str, ...],
    candidate_ids: tuple[str, ...],
) -> dict:
    tie_tokens = np.asarray(
        [
            [ranking_token(query_id, candidate_id) for candidate_id in candidate_ids]
            for query_id in query_ids
        ],
        dtype=np.uint64,
    )
    order = ranking_order(scores, tie_tokens)
    query_ap = np.empty(len(query_ids), dtype=np.float64)
    top1_present = np.empty(len(query_ids), dtype=np.float64)
    recall = {
        budget: np.empty(len(query_ids), dtype=np.float64)
        for budget in BUDGETS
    }
    all_present = {
        budget: np.empty(len(query_ids), dtype=np.float64)
        for budget in BUDGETS
    }
    reciprocal_rank = np.empty(len(query_ids), dtype=np.float64)
    tied_top1_queries = 0
    for query_index in range(len(query_ids)):
        local_labels = labels[query_index]
        local_scores = scores[query_index]
        query_ap[query_index] = average_precision_score(
            local_labels,
            local_scores,
        )
        ranked_labels = local_labels[order[query_index]]
        positives = int(local_labels.sum())
        top1_present[query_index] = float(ranked_labels[0] == 1)
        if np.count_nonzero(local_scores == local_scores.max()) > 1:
            tied_top1_queries += 1
        for budget in BUDGETS:
            hits = int(ranked_labels[:budget].sum())
            recall[budget][query_index] = hits / positives
            all_present[budget][query_index] = float(hits == positives)
        positive_ranks = np.flatnonzero(ranked_labels) + 1
        reciprocal_rank[query_index] = 1.0 / float(positive_ranks.min())

    values = {
        "micro_ap": float(average_precision_score(labels.ravel(), scores.ravel())),
        "macro_ap": float(query_ap.mean()),
        "top1_present": float(top1_present.mean()),
        "mrr": float(reciprocal_rank.mean()),
    }
    for budget in BUDGETS:
        values[f"recall_at_{budget}"] = float(recall[budget].mean())
    for budget in BUDGETS:
        values[f"all_present_at_{budget}"] = float(
            all_present[budget].mean()
        )
    diagnostics = {
        "queries_with_exact_top_score_ties": tied_top1_queries,
        "ties_resolved_by": "SHA-256 ranking token, never by truth or ID suffix",
        "query_ap": query_ap,
        "top1_present_per_query": top1_present,
        "mrr_per_query": reciprocal_rank,
        "recall_per_query": recall,
        "all_present_per_query": all_present,
    }
    return {"values": values, "diagnostics": diagnostics}


def percentile_interval(values: np.ndarray) -> list[float]:
    return [
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    ]


def paired_bootstrap_p_value(
    difference: np.ndarray,
) -> float:
    lower_tail = (1 + int(np.sum(difference <= 0))) / (len(difference) + 1)
    upper_tail = (1 + int(np.sum(difference >= 0))) / (len(difference) + 1)
    return float(min(1.0, 2.0 * min(lower_tail, upper_tail)))


def holm_adjust(
    values: dict[str, float],
) -> dict[str, float]:
    ordered = sorted(values.items(), key=lambda item: item[1])
    adjusted = {}
    running = 0.0
    total = len(ordered)
    for rank, (name, value) in enumerate(ordered, start=1):
        running = max(running, min(1.0, (total - rank + 1) * value))
        adjusted[name] = running
    return adjusted


def bootstrap_metrics(
    dataset: dict,
    score_matrices: dict[str, np.ndarray],
    metric_results: dict[str, dict],
    repeats: int,
) -> dict[str, dict[str, np.ndarray]]:
    candidate_ids = dataset["candidate_ids"]
    labels = dataset["labels"]
    metadata = dataset["metadata"]
    groups = tuple(sorted(metadata["sample_group"].astype(str).unique()))
    query_index_by_group = {
        group: np.flatnonzero(
            metadata["sample_group"].astype(str).to_numpy() == group
        )
        for group in groups
    }
    pair_groups = np.repeat(
        metadata["sample_group"].astype(str).to_numpy(),
        len(candidate_ids),
    )
    pair_index_by_group = {
        group: np.flatnonzero(pair_groups == group)
        for group in groups
    }
    pair_labels = labels.ravel()
    pair_scores = {
        method: values.ravel()
        for method, values in score_matrices.items()
    }
    samples = {
        method: {
            endpoint: np.empty(repeats, dtype=np.float64)
            for endpoint in PRIMARY_ENDPOINTS
        }
        for method in METHODS
    }
    rng = np.random.default_rng(SEED)
    for repeat in range(repeats):
        selected = rng.choice(groups, size=len(groups), replace=True)
        pair_indices = np.concatenate(
            [pair_index_by_group[group] for group in selected]
        )
        query_indices = np.concatenate(
            [query_index_by_group[group] for group in selected]
        )
        for method in METHODS:
            diagnostics = metric_results[method]["diagnostics"]
            samples[method]["micro_ap"][repeat] = average_precision_score(
                pair_labels[pair_indices],
                pair_scores[method][pair_indices],
            )
            samples[method]["macro_ap"][repeat] = float(
                diagnostics["query_ap"][query_indices].mean()
            )
            samples[method]["top1_present"][repeat] = float(
                diagnostics["top1_present_per_query"][query_indices].mean()
            )
            samples[method]["recall_at_1"][repeat] = float(
                diagnostics["recall_per_query"][1][query_indices].mean()
            )
            samples[method]["all_present_at_8"][repeat] = float(
                diagnostics["all_present_per_query"][8][query_indices].mean()
            )
    return samples


def contrast_report(
    left: str,
    right: str,
    point_metrics: dict[str, dict],
    bootstrap: dict[str, dict[str, np.ndarray]],
) -> dict:
    contrast = {
        endpoint: {
            "estimate": float(
                point_metrics[left]["values"][endpoint]
                - point_metrics[right]["values"][endpoint]
            ),
            "ci95": percentile_interval(
                bootstrap[left][endpoint] - bootstrap[right][endpoint]
            ),
            "p_value": paired_bootstrap_p_value(
                bootstrap[left][endpoint] - bootstrap[right][endpoint]
            ),
        }
        for endpoint in PRIMARY_ENDPOINTS
    }
    adjusted = holm_adjust(
        {
            endpoint: values["p_value"]
            for endpoint, values in contrast.items()
        }
    )
    for endpoint, value in adjusted.items():
        contrast[endpoint]["p_value_holm"] = value
    return contrast


def candidate_ambiguity(dataset: dict) -> dict:
    reference_ids = tuple(sorted(dataset["profile_by_id"]))
    profiles = np.vstack(
        [dataset["profile_by_id"][reference_id] for reference_id in reference_ids]
    )
    candidate_ids = dataset["candidate_ids"]
    family_references = dataset["family_reference_ids"]
    pairs = []
    for left_index, left_candidate in enumerate(candidate_ids):
        for right_candidate in candidate_ids[left_index + 1 :]:
            left_ref_indices = [
                reference_ids.index(reference_id)
                for reference_id in family_references[left_candidate]
            ]
            right_ref_indices = [
                reference_ids.index(reference_id)
                for reference_id in family_references[right_candidate]
            ]
            best = None
            for left_ref_index in left_ref_indices:
                similarities = reference_correlations(
                    profiles[left_ref_index],
                    profiles[right_ref_indices],
                )
                local_index = int(np.argmax(similarities))
                value = float(similarities[local_index])
                record = {
                    "left_candidate": left_candidate,
                    "right_candidate": right_candidate,
                    "left_family": dataset["families"][left_candidate]["family"],
                    "right_family": dataset["families"][right_candidate]["family"],
                    "left_reference": reference_ids[left_ref_index],
                    "right_reference": reference_ids[
                        right_ref_indices[local_index]
                    ],
                    "max_profile_pearson": value,
                }
                if best is None or value > best["max_profile_pearson"]:
                    best = record
            pairs.append(best)
    pairs.sort(
        key=lambda item: item["max_profile_pearson"],
        reverse=True,
    )
    within_family = []
    for candidate_id in candidate_ids:
        references = family_references[candidate_id]
        indices = [reference_ids.index(reference_id) for reference_id in references]
        maximum = None
        for first in range(len(indices)):
            for second in range(first + 1, len(indices)):
                value = pearson(
                    profiles[indices[first]],
                    profiles[indices[second]],
                )
                maximum = value if maximum is None else max(maximum, value)
        if maximum is not None:
            within_family.append(
                {
                    "candidate_id": candidate_id,
                    "family": dataset["families"][candidate_id]["family"],
                    "max_within_family_pearson": float(maximum),
                }
            )
    within_family.sort(
        key=lambda item: item["max_within_family_pearson"],
        reverse=True,
    )
    return {
        "definition": (
            "Maximum Pearson correlation between any two family reference "
            "profiles after the frozen square-root transformation."
        ),
        "candidate_pairs": len(pairs),
        "pairs_at_or_above_0_98": sum(
            item["max_profile_pearson"] >= 0.98 for item in pairs
        ),
        "pairs_at_or_above_0_995": sum(
            item["max_profile_pearson"] >= 0.995 for item in pairs
        ),
        "fraction_pairs_at_or_above_0_995": (
            sum(item["max_profile_pearson"] >= 0.995 for item in pairs)
            / len(pairs)
        ),
        "most_similar_pairs": pairs[:20],
        "within_family": within_family,
    }


def validate_disjoint_ranking_tokens(
    query_ids: tuple[str, ...],
    candidate_ids: tuple[str, ...],
) -> None:
    values = [
        ranking_token(query_id, candidate_id)
        for query_id in query_ids
        for candidate_id in candidate_ids
    ]
    if len(values) != len(set(values)):
        raise ValueError("ranking-token collision")


def write_predictions(
    path: Path,
    query_ids: tuple[str, ...],
    candidate_ids: tuple[str, ...],
    score_matrices: dict[str, np.ndarray],
) -> str:
    rows = []
    for method in METHODS:
        for query_index, query_id in enumerate(query_ids):
            for candidate_index, candidate_id in enumerate(candidate_ids):
                rows.append(
                    {
                        "method_id": method,
                        "query_id": query_id,
                        "candidate_id": candidate_id,
                        "score": (
                            f"{score_matrices[method][query_index, candidate_index]:.17g}"
                        ),
                    }
                )
    frame = pd.DataFrame(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, lineterminator="\n")
    return sha256(path)


def build_report(dataset: dict) -> dict:
    validate_disjoint_ranking_tokens(
        dataset["query_ids"],
        dataset["candidate_ids"],
    )
    scores = {
        "deterministic_hash_random": random_scores(
            dataset["query_ids"],
            dataset["candidate_ids"],
        ),
        "leave_group_out_frequency": leave_group_out_frequency(
            dataset["labels"],
            dataset["query_ids"],
            dataset["metadata"],
        ),
    }
    global_scores, global_preprocessing = spectral_scores(
        dataset,
        windowed=False,
    )
    window_scores, window_preprocessing = spectral_scores(
        dataset,
        windowed=True,
    )
    scores["global_sqrt_pearson"] = global_scores
    scores["eight_window_sqrt_pearson"] = window_scores
    if not all(
        np.isfinite(matrix).all()
        for matrix in scores.values()
    ):
        raise ValueError("non-finite baseline scores")

    point_metrics = {
        method: metric_values(
            dataset["labels"],
            scores[method],
            dataset["query_ids"],
            dataset["candidate_ids"],
        )
        for method in METHODS
    }
    bootstrap = bootstrap_metrics(
        dataset,
        scores,
        point_metrics,
        BOOTSTRAP_REPEATS,
    )
    contrasts = {
        "global_minus_prior": contrast_report(
            "global_sqrt_pearson",
            "leave_group_out_frequency",
            point_metrics,
            bootstrap,
        ),
        "window_minus_global": contrast_report(
            "eight_window_sqrt_pearson",
            "global_sqrt_pearson",
            point_metrics,
            bootstrap,
        ),
        "eight_window_minus_prior": contrast_report(
            "eight_window_sqrt_pearson",
            "leave_group_out_frequency",
            point_metrics,
            bootstrap,
        ),
    }
    evidence_gate = {
        "micro_ap_lower_95_above_zero": (
            contrasts[PRIMARY_CONTRAST]["micro_ap"]["ci95"][0] > 0
        ),
        "macro_ap_lower_95_above_zero": (
            contrasts[PRIMARY_CONTRAST]["macro_ap"]["ci95"][0] > 0
        ),
    }
    validity_checks = {
        "manifest_hashes_match": all(
            item["matches"] for item in dataset["hash_checks"].values()
        ),
        "public_package_file_count": (
            dataset["public_audit"]["files"]
            == dataset["public_audit"]["expected_files"]
        ),
        "public_package_has_no_unexpected_files": not dataset["public_audit"][
            "unexpected_files"
        ],
        "public_package_has_no_missing_files": not dataset["public_audit"][
            "missing_files"
        ],
        "no_public_label_tokens": not dataset["public_audit"][
            "forbidden_tokens"
        ],
        "no_public_truth_file": not dataset["public_audit"][
            "public_truth_file_present"
        ],
        "complete_truth_grid": len(dataset["truth"])
        == len(dataset["query_ids"]) * len(dataset["candidate_ids"]),
        "grouped_folds": dataset["grouped_folds"],
        "no_exact_query_duplicates": (
            dataset["manifest"]["leakage_audit"]["duplicate_query_spectra"]
            == 0
        ),
        "no_exact_reference_duplicates": (
            dataset["manifest"]["leakage_audit"][
                "shared_reference_between_families"
            ]
            == 0
        ),
    }
    validity_passed = all(validity_checks.values())
    informative = validity_passed and all(evidence_gate.values())
    if informative:
        verdict = "informative_external_benchmark"
    elif validity_passed:
        verdict = "source_coverage_benchmark_only"
    else:
        verdict = "validity_gate_failed"

    method_reports = {}
    for method in METHODS:
        method_report = {
            "metrics": point_metrics[method]["values"],
            "bootstrap_ci95": {
                endpoint: percentile_interval(bootstrap[method][endpoint])
                for endpoint in PRIMARY_ENDPOINTS
            },
            "top_score_tie_diagnostics": {
                key: value
                for key, value in point_metrics[method]["diagnostics"].items()
                if key == "queries_with_exact_top_score_ties"
                or key == "ties_resolved_by"
            },
        }
        if method == "deterministic_hash_random":
            method_report["configuration"] = {
                "salt": SEED,
                "score": "SHA-256-derived uniform score",
            }
        elif method == "leave_group_out_frequency":
            method_report["configuration"] = {
                "training_labels": "all queries outside the current sample group",
                "score": "leave-group-out prevalence",
            }
        elif method == "global_sqrt_pearson":
            method_report["configuration"] = global_preprocessing
        elif method == "eight_window_sqrt_pearson":
            method_report["configuration"] = window_preprocessing
        method_reports[method] = method_report

    report = {
        "status": "chemin_external_benchmark_evaluated",
        "claim_boundary": (
            "Retrospective closed-library known-family retrieval on measured "
            "Mars CheMin patterns. This is not prospective, open-world, "
            "amorphous-content or Mars-analogue generality evidence."
        ),
        "dataset": {
            "directory": dataset["root"].name,
            "manifest_status": dataset["manifest"]["status"],
            "tree_sha256": dataset["tree_sha256"],
            "queries": len(dataset["query_ids"]),
            "candidate_families": len(dataset["candidate_ids"]),
            "reference_profiles": len(dataset["profile_by_id"]),
            "truth_rows": len(dataset["truth"]),
            "sample_groups": int(
                dataset["metadata"]["sample_group"].nunique()
            ),
            "positive_families_per_query": {
                "minimum": int(dataset["labels"].sum(axis=1).min()),
                "mean": float(dataset["labels"].sum(axis=1).mean()),
                "maximum": int(dataset["labels"].sum(axis=1).max()),
            },
            "input_hashes": dataset["hash_checks"],
            "reference_source": dataset["manifest"].get("reference_source"),
            "source_license_boundary": dataset["manifest"].get(
                "source_license_boundary"
            ),
        },
        "contract": {
            "seed": SEED,
            "bootstrap_repeats": BOOTSTRAP_REPEATS,
            "bootstrap_unit": "CheMin sample group",
            "budgets": list(BUDGETS),
            "primary_contrast": PRIMARY_CONTRAST,
            "primary_endpoints": list(PRIMARY_ENDPOINTS),
            "family_aggregation": "maximum across family reference profiles",
            "ranking_tie_rule": (
                "descending score, then SHA-256 token; truth and ID suffix "
                "are not used"
            ),
            "software": {
                "python": platform.python_version(),
                "numpy": np.__version__,
                "pandas": pd.__version__,
                "scikit_learn": sklearn.__version__,
            },
        },
        "leakage_and_integrity": {
            "passed": validity_passed,
            "checks": validity_checks,
            "public_tree": dataset["public_audit"],
        },
        "candidate_ambiguity": candidate_ambiguity(dataset),
        "methods": method_reports,
        "paired_contrasts": contrasts,
        "evidence_gate": {
            **evidence_gate,
            "passed": all(evidence_gate.values()),
            "interpretation": (
                "Passing means this frozen task contains spectral information "
                "beyond the leakage-controlled prevalence prior. It does not "
                "establish state of the art."
            ),
        },
        "verdict": verdict,
    }
    report["canonical_sha256"] = canonical_digest(report)
    return report, scores


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset",
        type=Path,
        default=Path(__file__).resolve().parent / "dataset_v1",
    )
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.out_dir.exists() and any(args.out_dir.iterdir()):
        raise FileExistsError(
            f"refusing to overwrite non-empty output directory: {args.out_dir}"
        )
    args.out_dir.mkdir(parents=True, exist_ok=True)

    dataset = load_dataset(args.dataset)
    report, scores = build_report(dataset)
    predictions_path = args.out_dir / "predictions.csv"
    predictions_sha256 = write_predictions(
        predictions_path,
        dataset["query_ids"],
        dataset["candidate_ids"],
        scores,
    )
    report["outputs"] = {
        "predictions_sha256": predictions_sha256,
    }
    report.pop("canonical_sha256", None)
    report["canonical_sha256"] = canonical_digest(report)
    result_path = args.out_dir / "evaluation.json"
    result_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "verdict": report["verdict"],
                "canonical_sha256": report["canonical_sha256"],
                "predictions_sha256": predictions_sha256,
                "evidence_gate": report["evidence_gate"],
                "output": str(result_path),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if report["leakage_and_integrity"]["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
