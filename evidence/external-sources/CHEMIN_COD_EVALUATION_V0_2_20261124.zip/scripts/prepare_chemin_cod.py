"""Build the CheMin benchmark with redistributable COD reference structures."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from prepare_chemin import (
    EXCLUDED_LABELS,
    FAMILY_ALIASES,
    GRID,
    LABEL_TO_FAMILY,
    SEED,
    WAVELENGTH_ANGSTROM,
    digest,
    extract_sample_group,
    gaussian_profile,
    read_rda,
    sha256,
    write_csv,
)

COD_RESULT_URL = "https://www.crystallography.net/cod/result.php"
COD_CIF_URL = "https://www.crystallography.net/cod/{cod_id}.cif"
COD_LICENSE_URL = "https://creativecommons.org/publicdomain/zero/1.0/"
COD_HOME_URL = "https://www.crystallography.net/cod/"
USER_AGENT = "pxrd-completesetbench-chemin-cod/1.0"
MINIMUM_PEAKS = 2
MISSING_NUMERIC = 1e9


REFERENCE_SPECS = {
    "HEMATITE": [
        {
            "alias": "hematite",
            "formulas": ("Fe2 O3",),
            "minerals": ("Hematite",),
        }
    ],
    "QUARTZ": [
        {
            "alias": "quartz",
            "formulas": ("O2 Si",),
            "minerals": ("Quartz",),
        }
    ],
    "PLAGIOCLASE": [
        {
            "alias": "albite",
            "formulas": ("Al Na O8 Si3",),
            "minerals": ("Albite",),
        },
        {
            "alias": "anorthite",
            "formulas": ("Al2 Ca O8 Si2",),
            "minerals": ("Anorthite",),
        },
    ],
    "ANHYDRITE": [
        {
            "alias": "anhydrite",
            "formulas": ("Ca O4 S",),
            "minerals": ("Anhydrite",),
        }
    ],
    "BASSANITE": [
        {
            "alias": "bassanite",
            "formulas": ("Ca2 H2 O9 S2",),
            "minerals": ("Bassanite",),
        }
    ],
    "PYROXENE": [
        {
            "alias": "diopside",
            "formulas": ("Ca Mg O6 Si2",),
            "minerals": ("Diopside",),
        },
        {
            "alias": "enstatite",
            "formulas": ("Mg O3 Si",),
            "minerals": ("Enstatite",),
        },
        {
            "alias": "hedenbergite",
            "formulas": ("Ca Fe O6 Si2",),
            "minerals": ("Hedenbergite",),
        },
    ],
    "MAGNETITE": [
        {
            "alias": "magnetite",
            "formulas": ("Fe3 O4",),
            "minerals": ("Magnetite",),
        }
    ],
    "K_FELDSPAR": [
        {
            "alias": "sanidine",
            "formulas": ("Al K O8 Si3",),
            "minerals": ("Sanidine",),
        },
        {
            "alias": "orthoclase",
            "formulas": ("Al K O8 Si3",),
            "minerals": ("Orthoclase",),
        },
        {
            "alias": "microcline",
            "formulas": ("Al K O8 Si3",),
            "minerals": ("Microcline",),
        },
    ],
    "OLIVINE": [
        {
            "alias": "forsterite",
            "formulas": ("Mg2 O4 Si",),
            "minerals": ("Forsterite",),
        },
        {
            "alias": "fayalite",
            "formulas": ("Fe2 O4 Si",),
            "minerals": ("Fayalite",),
        },
    ],
    "GYPSUM": [
        {
            "alias": "gypsum",
            "formulas": ("Ca H4 O6 S",),
            "minerals": ("Gypsum",),
        }
    ],
    "JAROSITE_GROUP": [
        {
            "alias": "jarosite",
            "formulas": ("Fe3 H6 K O14 S2",),
            "minerals": ("Jarosite",),
        },
        {
            "alias": "natrojarosite",
            "formulas": ("Fe3 H6 Na O14 S2",),
            "minerals": ("Natrojarosite",),
        },
    ],
    "APATITE": [
        {
            "alias": "fluorapatite",
            "formulas": ("Ca5 F O12 P3",),
            "minerals": ("Fluorapatite",),
        },
        {
            "alias": "chlorapatite",
            "formulas": ("Ca5 Cl O12 P3",),
            "minerals": ("Chlorapatite",),
        },
        {
            "alias": "hydroxylapatite",
            "formulas": ("Ca5 H O13 P3",),
            "minerals": ("Hydroxylapatite", "Apatite-(CaOH)"),
        },
    ],
    "ILMENITE": [
        {
            "alias": "ilmenite",
            "formulas": ("Fe O3 Ti",),
            "minerals": ("Ilmenite",),
        }
    ],
    "HALITE": [
        {
            "alias": "halite",
            "formulas": ("Cl Na",),
            "minerals": ("Halite",),
        }
    ],
    "CARBONATE": [
        {
            "alias": "calcite",
            "formulas": ("C Ca O3",),
            "minerals": ("Calcite",),
        },
        {
            "alias": "dolomite",
            "formulas": ("C2 Ca Mg O6",),
            "minerals": ("Dolomite",),
        },
        {
            "alias": "siderite",
            "formulas": ("C Fe O3",),
            "minerals": ("Siderite",),
        },
        {
            "alias": "magnesite",
            "formulas": ("C Mg O3",),
            "minerals": ("Magnesite",),
        },
    ],
    "GOETHITE": [
        {
            "alias": "goethite",
            "formulas": ("Fe H O2",),
            "minerals": ("Goethite",),
        }
    ],
    "PYRRHOTITE": [
        {
            "alias": "pyrrhotite",
            "formulas": ("Fe7 S8", "Fe9 S10"),
            "minerals": (
                "Pyrrhotite",
                "Pyrrhotite 4C",
                "Pyrrhotite 5C",
            ),
        }
    ],
    "CRISTOBALITE": [
        {
            "alias": "cristobalite",
            "formulas": ("O2 Si",),
            "minerals": ("Cristobalite",),
        }
    ],
    "PYRITE": [
        {
            "alias": "pyrite",
            "formulas": ("Fe S2",),
            "minerals": ("Pyrite",),
        }
    ],
    "TRIDYMITE": [
        {
            "alias": "tridymite",
            "formulas": ("O2 Si",),
            "minerals": ("Tridymite",),
        }
    ],
    "KIESERITE": [
        {
            "alias": "kieserite",
            "formulas": ("H2 Mg O5 S",),
            "minerals": ("Kieserite",),
        }
    ],
    "MG_SULFATE_HYDRATE": [
        {
            "alias": "starkeyite",
            "formulas": ("H8 Mg O8 S",),
            "minerals": ("Starkeyite",),
        }
    ],
}


def normalize(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()


def numeric(value: object, fallback: float) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return fallback
    return number if np.isfinite(number) else fallback


def post_form(
    url: str,
    fields: dict[str, str],
) -> bytes:
    request = urllib.request.Request(
        url,
        data=urllib.parse.urlencode(fields).encode("utf-8"),
        headers={
            "Accept": "application/json",
            "User-Agent": USER_AGENT,
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=90) as response:
        return response.read()


def fetch_bytes(url: str) -> bytes:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": USER_AGENT},
    )
    with urllib.request.urlopen(request, timeout=90) as response:
        return response.read()


def cached_formula_records(
    formula: str,
    cache_dir: Path,
) -> tuple[list[dict], dict]:
    key = hashlib.sha256(formula.encode("utf-8")).hexdigest()[:16]
    metadata_path = cache_dir / "metadata" / f"{key}.json"
    if metadata_path.exists():
        payload = json.loads(metadata_path.read_text(encoding="utf-8"))
        return payload["records"], payload["retrieval"]

    fields = {
        "formula": formula,
        "format": "json",
        "include_errors": "0",
        "include_theoretical": "0",
        "include_duplicates": "0",
    }
    raw = post_form(COD_RESULT_URL, fields)
    records = json.loads(raw.decode("utf-8"))
    if not isinstance(records, list):
        raise TypeError(f"unexpected COD response for {formula!r}")
    retrieval = {
        "endpoint": COD_RESULT_URL,
        "method": "POST",
        "fields": fields,
        "access_date_utc": dt.datetime.now(dt.UTC).date().isoformat(),
        "response_sha256": hashlib.sha256(raw).hexdigest(),
        "records": len(records),
    }
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.write_text(
        json.dumps(
            {"formula": formula, "retrieval": retrieval, "records": records},
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    time.sleep(0.6)
    return records, retrieval


def record_quality(record: dict, accepted_names: set[str]) -> tuple:
    mineral = normalize(record.get("mineral"))
    cod_id = str(record.get("file", ""))
    flags = str(record.get("flags", "")).lower()
    cell_temperature = numeric(record.get("celltemp"), MISSING_NUMERIC)
    pressure = numeric(record.get("diffrpressure"), 0.0)
    r_value = numeric(record.get("Rall"), 10.0)
    curated_rank = 0 if cod_id.startswith(("9", "5")) else 1
    ambient_penalty = (
        0.0
        if cell_temperature == MISSING_NUMERIC
        else abs(cell_temperature - 293.0)
    )
    return (
        0 if mineral in accepted_names else 1,
        0 if "has coordinates" in flags else 1,
        curated_rank,
        ambient_penalty,
        pressure,
        r_value,
        digest("cod_quality_tie", cod_id),
    )


def cif_peaks(path: Path) -> list[tuple[float, float]]:
    parser = CifParser(path)
    structures = parser.parse_structures(primitive=False)
    if not structures:
        raise ValueError(f"no structure parsed from {path.name}")
    pattern = XRDCalculator(wavelength=WAVELENGTH_ANGSTROM).get_pattern(
        structures[0],
        two_theta_range=(3.0, 52.0),
    )
    peaks = [
        (float(position), float(intensity))
        for position, intensity in zip(
            pattern.x,
            pattern.y,
            strict=True,
        )
    ]
    if len(peaks) < MINIMUM_PEAKS:
        raise ValueError(
            f"fewer than {MINIMUM_PEAKS} COD peaks in {path.name}"
        )
    return peaks


def fetch_cif(
    cod_id: str,
    cache_dir: Path,
) -> Path:
    path = cache_dir / "cif" / f"{cod_id}.cif"
    if path.exists() and path.stat().st_size:
        return path
    raw = fetch_bytes(COD_CIF_URL.format(cod_id=cod_id))
    if len(raw) < 200 or b"data_" not in raw[:5000]:
        raise ValueError(f"COD did not return a CIF for {cod_id}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    time.sleep(0.6)
    return path


def candidate_records(
    spec: dict,
    cache_dir: Path,
) -> tuple[list[dict], list[dict]]:
    accepted_names = {normalize(name) for name in spec["minerals"]}
    records = []
    retrievals = []
    seen_ids = set()
    for formula in spec["formulas"]:
        local_records, retrieval = cached_formula_records(formula, cache_dir)
        retrievals.append({"formula": formula, **retrieval})
        for record in local_records:
            cod_id = str(record.get("file", "")).strip()
            if not cod_id or cod_id in seen_ids:
                continue
            if normalize(record.get("mineral")) not in accepted_names:
                continue
            seen_ids.add(cod_id)
            records.append(record)
    records.sort(key=lambda record: record_quality(record, accepted_names))
    return records, retrievals


def selected_profiles(
    family: str,
    specs: list[dict],
    cache_dir: Path,
) -> tuple[list[dict], dict]:
    references = []
    used_cod_ids = set()
    used_profile_hashes = set()
    retrieval_records = []
    per_spec_limit = 3 if len(specs) == 1 else 1
    for spec in specs:
        records, retrievals = candidate_records(spec, cache_dir)
        retrieval_records.extend(retrievals)
        selected = 0
        failures = []
        for record in records[:40]:
            cod_id = str(record["file"])
            if cod_id in used_cod_ids:
                continue
            cif_path = None
            try:
                cif_path = fetch_cif(cod_id, cache_dir)
                peaks = cif_peaks(cif_path)
                profile = gaussian_profile(peaks)
            except (KeyError, OSError, RuntimeError, TypeError, ValueError) as error:
                failures.append(
                    {
                        "cod_id": cod_id,
                        "error": f"{type(error).__name__}: {error}",
                    }
                )
                if cif_path is not None and not cif_path.exists():
                    cif_path = None
                continue
            profile_sha = hashlib.sha256(profile.tobytes()).hexdigest()
            if profile_sha in used_profile_hashes:
                continue
            used_profile_hashes.add(profile_sha)
            used_cod_ids.add(cod_id)
            references.append(
                {
                    "family": family,
                    "alias": spec["alias"],
                    "cod_id": cod_id,
                    "cod_url": f"https://www.crystallography.net/cod/{cod_id}.html",
                    "cif_url": COD_CIF_URL.format(cod_id=cod_id),
                    "cif_sha256": sha256(cif_path),
                    "cod_license": "CC0-1.0",
                    "cod_license_url": COD_LICENSE_URL,
                    "mineral": record.get("mineral"),
                    "chemname": record.get("chemname"),
                    "formula_cod": record.get("formula"),
                    "space_group_number": record.get("sgNumber"),
                    "space_group": record.get("sg"),
                    "year": record.get("year"),
                    "doi": record.get("doi"),
                    "authors": record.get("authors"),
                    "title": record.get("title"),
                    "journal": record.get("journal"),
                    "peak_count": len(peaks),
                    "profile": profile,
                }
            )
            selected += 1
            if selected >= per_spec_limit:
                break
        if selected == 0:
            raise ValueError(
                f"no usable COD structure for {family}/{spec['alias']}: "
                f"{failures[-3:]}"
            )
    return references, {
        "family": family,
        "retrievals": retrieval_records,
        "reference_count": len(references),
    }


def filtered_sample_table(
    sample_table: Path,
    chemin_cache: Path,
) -> pd.DataFrame:
    source = pd.read_csv(sample_table)
    source["product_version"] = (
        source["min_product_id"].str.extract(r"p(\d+)$")[0].fillna(0).astype(int)
    )
    source = source.sort_values("product_version").drop_duplicates(
        "rda_product_id",
        keep="last",
    )
    source["rda_sha256"] = source["rda_product_id"].map(
        lambda value: sha256(chemin_cache / f"{value}.csv")
    )
    source = (
        source.sort_values(
            ["rda_sha256", "product_version", "rda_product_id"],
            ascending=[True, False, True],
        )
        .drop_duplicates("rda_sha256", keep="first")
    )
    source = source[
        ~source["phase_set"].map(
            lambda value: bool(
                {item.strip() for item in value.split("|")} & EXCLUDED_LABELS
            )
        )
    ].copy()
    source = source.sort_values(
        "rda_product_id",
        key=lambda values: values.map(
            lambda value: digest("query_order", value)
        ),
    )
    return source


def validate_family_coverage(source: pd.DataFrame) -> None:
    observed = {
        LABEL_TO_FAMILY[label]
        for phase_set in source["phase_set"]
        for label in phase_set.split("|")
    }
    missing_specs = sorted(observed - set(REFERENCE_SPECS))
    if missing_specs:
        raise ValueError(
            f"COD reference coverage is incomplete: missing={missing_specs}"
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-table", type=Path, required=True)
    parser.add_argument("--chemin-cache", type=Path, required=True)
    parser.add_argument("--cod-cache", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    if (args.out_dir / "public").exists():
        raise FileExistsError(f"refusing to overwrite {args.out_dir}")

    source = filtered_sample_table(args.sample_table, args.chemin_cache)
    validate_family_coverage(source)
    if len(source) != 44:
        raise ValueError(f"expected 44 eligible CheMin queries, got {len(source)}")
    family_names = sorted(
        {
            LABEL_TO_FAMILY[label]
            for phase_set in source["phase_set"]
            for label in phase_set.split("|")
        }
    )
    family_id = {
        family: f"chemins_{position:03d}"
        for position, family in enumerate(
            sorted(
                family_names,
                key=lambda value: digest("candidate_order", value),
            ),
            start=1,
        )
    }
    query_id = {
        value: f"cheminq_{position:03d}"
        for position, value in enumerate(
            source["rda_product_id"],
            start=1,
        )
    }

    public = args.out_dir / "public"
    evaluator = args.out_dir / "evaluator"
    spectra_dir = public / "spectra"
    profile_dir = public / "reference_profiles"
    spectra_dir.mkdir(parents=True)
    profile_dir.mkdir(parents=True)

    query_rows = []
    query_metadata = []
    truth_rows = []
    spectrum_hashes = set()
    for row in source.itertuples(index=False):
        opaque_query = query_id[row.rda_product_id]
        rda_path = args.chemin_cache / f"{row.rda_product_id}.csv"
        x, y = read_rda(rda_path)
        spectrum_path = spectra_dir / f"{opaque_query}.xy"
        spectrum_path.write_text(
            "".join(
                f"{theta:.10f} {intensity:.12g}\n"
                for theta, intensity in zip(x, y, strict=True)
            ),
            encoding="utf-8",
            newline="\n",
        )
        spectrum_hash = sha256(spectrum_path)
        if spectrum_hash in spectrum_hashes:
            raise ValueError("duplicate public query spectrum")
        spectrum_hashes.add(spectrum_hash)
        query_rows.append(
            {
                "query_id": opaque_query,
                "spectrum_file": f"spectra/{opaque_query}.xy",
                "radiation": "Co",
                "wavelength_angstrom": WAVELENGTH_ANGSTROM,
            }
        )
        label_path = args.chemin_cache / f"{row.min_product_id}.lbl"
        sample_group = extract_sample_group(
            label_path.read_text(encoding="utf-8", errors="replace")
        )
        query_metadata.append(
            {
                "query_id": opaque_query,
                "min_product_id": row.min_product_id,
                "rda_product_id": row.rda_product_id,
                "sample_group": sample_group,
                "fold": int(
                    digest("sample_group_fold", sample_group)[:8],
                    16,
                )
                % 5
                + 1,
            }
        )
        present_families = {
            LABEL_TO_FAMILY[label]
            for label in row.phase_set.split("|")
        }
        for family in family_names:
            truth_rows.append(
                {
                    "query_id": opaque_query,
                    "candidate_id": family_id[family],
                    "present": int(family in present_families),
                }
            )

    candidate_rows = []
    family_rows = []
    provenance_rows = []
    selection_records = []
    for family in family_names:
        candidate = family_id[family]
        references, selection = selected_profiles(
            family,
            REFERENCE_SPECS[family],
            args.cod_cache,
        )
        selection_records.append(selection)
        reference_records = []
        for position, reference in enumerate(references, start=1):
            opaque_reference = f"{candidate}_r{position:02d}"
            profile = reference.pop("profile")
            profile_path = profile_dir / f"{opaque_reference}.csv"
            profile_path.write_text(
                "two_theta_deg,intensity_normalized\n"
                + "".join(
                    f"{theta:.10f},{intensity:.12g}\n"
                    for theta, intensity in zip(
                        GRID,
                        profile,
                        strict=True,
                    )
                ),
                encoding="utf-8",
                newline="\n",
            )
            candidate_rows.append(
                {
                    "candidate_id": candidate,
                    "reference_id": opaque_reference,
                    "profile_file": (
                        f"reference_profiles/{opaque_reference}.csv"
                    ),
                }
            )
            provenance = {
                "reference_id": opaque_reference,
                "profile_sha256": sha256(profile_path),
                **reference,
            }
            provenance_rows.append(provenance)
            reference_records.append(provenance)
        family_rows.append(
            {
                "candidate_id": candidate,
                "family": family,
                "aliases": "|".join(sorted(FAMILY_ALIASES[family])),
                "references": reference_records,
            }
        )

    if len(candidate_rows) < 20:
        raise ValueError("fewer than one COD reference per candidate family")
    profile_hashes = [row["profile_sha256"] for row in provenance_rows]
    if len(profile_hashes) != len(set(profile_hashes)):
        raise ValueError("duplicate COD-derived reference profiles")
    if len({row["cod_id"] for row in provenance_rows}) != len(provenance_rows):
        raise ValueError("a COD structure is assigned to multiple candidates")

    write_csv(public / "queries.csv", query_rows)
    write_csv(public / "candidates.csv", candidate_rows)
    write_csv(evaluator / "truth.csv", truth_rows)
    write_csv(evaluator / "query_metadata.csv", query_metadata)
    write_csv(evaluator / "reference_provenance.csv", provenance_rows)
    (evaluator / "candidate_families.json").write_text(
        json.dumps(family_rows, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )

    public_text = "\n".join(
        path.read_text(encoding="utf-8", errors="ignore").upper()
        for path in public.rglob("*")
        if path.is_file()
    )
    forbidden_public_tokens = sorted(
        token
        for token in set(LABEL_TO_FAMILY) | set(LABEL_TO_FAMILY.values())
        if token.upper() in public_text
    )
    if forbidden_public_tokens:
        raise ValueError(
            f"forbidden labels found in public package: {forbidden_public_tokens}"
        )
    if (public / "truth.csv").exists():
        raise ValueError("truth table leaked into public package")

    query_groups = (
        pd.DataFrame(query_metadata)
        .groupby("sample_group")["query_id"]
        .apply(list)
        .to_dict()
    )
    fold_groups = (
        pd.DataFrame(query_metadata)
        .groupby("sample_group")["fold"]
        .nunique()
    )
    if not fold_groups.eq(1).all():
        raise ValueError("sample group has inconsistent folds")

    manifest = {
        "status": "chemin_benchmark_v0_2_cod_prepared",
        "queries": len(query_rows),
        "candidate_families": len(family_rows),
        "candidate_references": len(candidate_rows),
        "truth_rows": len(truth_rows),
        "sample_groups": len(query_groups),
        "exact_duplicate_spectra_removed": True,
        "excluded_labels": sorted(EXCLUDED_LABELS),
        "reference_source": {
            "name": "Crystallography Open Database",
            "home": COD_HOME_URL,
            "license": "CC0-1.0",
            "license_url": COD_LICENSE_URL,
            "selection": (
                "Exact COD mineral-name match per documented family species; "
                "ambient-pressure display structures preferred; deterministic "
                "quality ordering independent of CheMin labels and spectra."
            ),
            "rruff_profiles_redistributed": False,
        },
        "source_license_boundary": {
            "chemin_spectra": (
                "NASA PDS CheMin RDR products; cite the PDS dataset and release. "
                "No repository licence is asserted over upstream NASA products."
            ),
            "cod_structures": "CC0-1.0; original authors acknowledged in provenance.",
            "project_derived_reference_profiles": "CC BY 4.0.",
            "rruff": (
                "Used only for an internal feasibility audit. RRUFF-derived "
                "profiles are not included in v0.2."
            ),
        },
        "contract": {
            "wavelength_angstrom": WAVELENGTH_ANGSTROM,
            "two_theta_min": float(GRID[0]),
            "two_theta_max": float(GRID[-1]),
            "grid_points": len(GRID),
            "fwhm_degrees": 0.20,
            "seed": SEED,
        },
        "hashes": {
            "sample_table": sha256(args.sample_table),
            "queries": sha256(public / "queries.csv"),
            "candidates": sha256(public / "candidates.csv"),
            "truth": sha256(evaluator / "truth.csv"),
            "query_metadata": sha256(evaluator / "query_metadata.csv"),
            "candidate_families": sha256(
                evaluator / "candidate_families.json"
            ),
            "reference_provenance": sha256(
                evaluator / "reference_provenance.csv"
            ),
        },
        "leakage_audit": {
            "public_label_token_hits": forbidden_public_tokens,
            "public_truth_file_present": False,
            "duplicate_query_spectra": 0,
            "shared_reference_between_families": 0,
            "exact_duplicate_reference_profiles": 0,
            "grouped_folds": True,
            "rruff_reference_profiles_present": False,
        },
        "claim_boundary": (
            "Closed-library zero-shot mineral-family retrieval on measured "
            "CheMin patterns with COD-derived reference profiles. "
            "Retrospective external benchmark, not prospective and not "
            "open-world phase discovery."
        ),
    }
    (args.out_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    (args.out_dir / "cod_selection_audit.json").write_text(
        json.dumps(selection_records, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
