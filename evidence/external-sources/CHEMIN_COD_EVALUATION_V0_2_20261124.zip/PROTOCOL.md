# CheMin external complete-set benchmark v0.2

Status: frozen before v0.2 baseline execution  
Freeze date: 2026-11-24  
Dataset: `dataset_v2_cod`

## Reason for v0.2

Version 0.1 used RRUFF-derived reference profiles for internal feasibility
testing. The RRUFF record listed by AHED
(`https://doi.org/10.48667/pre9-s770`) links to CC BY-NC-ND 4.0 terms.
Those transformed profiles are therefore not redistributed in the public
candidate package.

Version 0.2 keeps the same measured CheMin queries, query groups, label
taxonomy and truth table, but replaces every candidate reference profile with
a structure-derived profile from the Crystallography Open Database (COD).
COD states that its data are dedicated to the public domain under CC0 1.0:
`https://www.crystallography.net/cod/`.

Version 0.1 remains an internal audit record and is not the public benchmark.

## Measured queries

- Source: NASA MSL CheMin PDS release 42.
- Mission page:
  `https://pds-geosciences.wustl.edu/missions/msl/chemin.htm`
- `CHEMIN_RDA`: measured one-dimensional Co K-alpha diffraction patterns.
- `CHEMIN_MIN`: source-linked mineral names, weight percent and 2-sigma
  analytical errors.
- Query filters and family collapses are identical to `PROTOCOL.md`.
- Akaganeite, generic `FELDSPAR` and overlapping `OPAL-CT` are excluded before
  scoring.
- Repeated analyses of one physical sample remain in one sample group.

## COD candidate library

The executable candidate library contains one opaque candidate family for
every retained CheMin benchmark family.

Selection uses only mineral and crystallographic metadata, never CheMin spectra
or query labels:

1. query COD by exact Hill formula;
2. retain records whose COD `mineral` field exactly matches the documented
   family species;
3. exclude duplicate, erroneous and theoretical records at query time;
4. rank remaining records by coordinate availability, curated COD collection,
   ambient temperature, pressure and reported R factor;
5. break remaining ties by SHA-256;
6. use up to three records for a single-species family and one representative
   record for each species in a multi-species family;
7. reject exact duplicate structures or derived profiles.

Candidate-family score remains the maximum score over that family's reference
profiles.

COD record identifiers, original authors, articles and CIF hashes are stored
only in `evaluator/reference_provenance.csv`. The public package contains
opaque candidate identifiers and numeric profiles.

## Reference-profile contract

- all COD CIFs are converted with pymatgen `XRDCalculator`;
- radiation is Co K-alpha with wavelength `1.78897 Angstrom`;
- peaks are broadened by a Gaussian with FWHM `0.20 deg`;
- the common grid is `3.00-51.95 deg` at `0.05 deg` spacing, 980 points;
- every profile is max-normalized to one.

## Public input boundary

The public package contains:

- opaque query IDs;
- raw two-column measured CheMin spectra;
- opaque candidate-family IDs;
- numeric COD-derived reference profiles;
- Co K-alpha and wavelength metadata.

It does not contain:

- source product IDs;
- sample names or targets;
- CheMin mineral labels;
- truth labels;
- sample groups or folds;
- COD identifiers, mineral names or source-record metadata.

## Evaluation

The frozen baselines and metrics are specified in
`EVALUATION_PLAN_COD_V0_2.md`. Bootstrap intervals resample whole CheMin sample
groups, never individual analysis products.

## Claim boundary

This is retrospective closed-library, known-family retrieval on measured Mars
CheMin patterns. It does not test open-world phase discovery, amorphous
content, phases below the CheMin reporting limit or prospective performance.

The CheMin queries, COD CIFs and derived profiles are public research data.
The repository cites NASA PDS and COD and does not assert ownership over
upstream records.
