# CheMin COD benchmark v0.2: frozen evaluation plan

Status: frozen before v0.2 baseline scoring  
Freeze date: 2026-11-24  
Dataset: `dataset_v2_cod`

## Scope

The task is closed-library, known-family retrieval from measured MSL CheMin
patterns. It is retrospective and cannot establish prospective or open-world
generalization.

The measured query set, label taxonomy, candidate-family count and truth table
are unchanged from v0.1. Only the reference provenance changes from an
internal RRUFF feasibility profile set to redistributable CC0 COD structures.

## Baselines

The four baselines and preprocessing are unchanged from
`EVALUATION_PLAN.md`:

1. deterministic SHA-256 random;
2. leave-sample-group-out frequency prior;
3. global square-root Pearson;
4. eight-window square-root Pearson.

The hidden parameters remain fixed before v0.2 scoring. No weight, smoothing,
background, peak-picking or window parameter is tuned on CheMin.

Ranking ties use a SHA-256 token computed from query ID, candidate ID and seed
`20261124`. Truth and opaque ID suffixes are not used.

## Metrics

- micro and macro average precision;
- Top-1 hit;
- Recall@1, 3, 5 and 8;
- AllPresent@3, 5 and 8;
- mean reciprocal rank.

## Uncertainty

Intervals use 10,000 paired bootstrap replicates over the 41 CheMin sample
groups. The seed is `20261124`.

The primary contrast is:

`eight_window_sqrt_pearson - leave_group_out_frequency`.

The evidence gate requires the lower 95% bound for both micro AP and macro AP
to exceed zero. A failed gate is reported as a source-coverage benchmark, not
silently changed into a method-superiority claim.

## Release gates

All of the following must pass:

1. manifest hashes match;
2. public tree contains exactly 44 queries, 20 candidate families, 44 measured
   spectra and one or more COD-derived profile for every family;
3. truth contains exactly 880 query-candidate rows;
4. every query has at least one positive family;
5. sample-group folds are consistent;
6. no mineral label or COD identifier appears in the public tree;
7. no truth table or source metadata appears in the public tree;
8. no query or reference profile is an exact duplicate;
9. all reference profiles use the frozen grid and are max-normalized;
10. two independent local runs produce byte-identical JSON and prediction
    tables.

The candidate ambiguity audit reports exact duplicates as failures and
cross-family profile correlations at or above 0.98 as warnings.

## Claim boundary

Passing the release gates establishes a traceable external benchmark. Passing
the evidence gate would show spectral information beyond the leakage-controlled
prevalence prior. Neither result establishes universal state of the art.

Any later model that was pretrained on CheMin, COD, RRUFF or related public
crystallographic corpora must declare that exposure.
