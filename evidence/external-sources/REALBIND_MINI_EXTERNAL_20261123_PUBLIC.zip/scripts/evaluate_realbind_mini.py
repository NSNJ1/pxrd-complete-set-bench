"""Evaluate global and window sqrt-Pearson on RealBind mini."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

PROTOCOL_SHA256 = "dab5dbcb2d4f9e5416cc1bf1d5075e32fa58002eed9528d83f1ba51a0bf555f4"
SOURCE_SHA256 = "00bd4742f0af524f9f88bcd98c16dfc59d4b77470597c296c34af4f6ad3d9678"
SEED = 20261123
BOOTSTRAP_REPEATS = 10_000
METHODS = ("deterministic_random", "global_sqrt_pearson", "window_sqrt_pearson")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def global_scores(query: np.ndarray, mask: np.ndarray, candidates: np.ndarray) -> np.ndarray:
    if mask.sum() < 10:
        return np.full(len(candidates), -np.inf)
    root_query = np.sqrt(np.clip(query[mask], 0.0, None))
    root_query = (
        root_query - root_query.mean()
    ) / (root_query.std() + 1e-9)
    root_candidates = np.sqrt(np.clip(candidates[:, mask], 0.0, None))
    root_candidates = (
        root_candidates - root_candidates.mean(axis=1, keepdims=True)
    ) / (root_candidates.std(axis=1, keepdims=True) + 1e-9)
    return root_candidates @ root_query / mask.sum()


def window_scores(query: np.ndarray, mask: np.ndarray, candidates: np.ndarray) -> np.ndarray:
    indices = np.flatnonzero(mask)
    total = np.zeros(len(candidates), dtype=np.float64)
    valid = 0
    for window in np.array_split(indices, 8):
        if len(window) < 10:
            continue
        local_mask = np.zeros_like(mask)
        local_mask[window] = True
        total += global_scores(query, local_mask, candidates)
        valid += 1
    return total / valid if valid else np.full(len(candidates), -np.inf)


def random_scores(query_uid: str, candidate_uids: np.ndarray) -> np.ndarray:
    values = []
    for candidate_uid in candidate_uids:
        digest = hashlib.sha256(
            f"{SEED}|{query_uid}|{candidate_uid}".encode()
        ).digest()
        values.append(int.from_bytes(digest[:8], "big") / (2**64 - 1))
    return np.asarray(values, dtype=np.float64)


def conservative_ranks(scores: np.ndarray, targets: np.ndarray) -> np.ndarray:
    target_scores = scores[np.arange(len(targets)), targets][:, None]
    ranks = (scores >= target_scores).sum(axis=1) - 1
    return np.where(np.isfinite(target_scores[:, 0]), ranks, scores.shape[1])


def metric_values(scores: np.ndarray, targets: np.ndarray) -> dict:
    ranks = conservative_ranks(scores, targets)
    labels = np.zeros_like(scores, dtype=np.int8)
    labels[np.arange(len(targets)), targets] = 1
    query_ap = np.asarray(
        [
            0.0
            if not np.isfinite(scores[index]).any()
            else average_precision_score(labels[index], scores[index])
            for index in range(len(targets))
        ]
    )
    return {
        "recall_at_1": 100.0 * float((ranks < 1).mean()),
        "recall_at_3": 100.0 * float((ranks < 3).mean()),
        "recall_at_5": 100.0 * float((ranks < 5).mean()),
        "recall_at_10": 100.0 * float((ranks < 10).mean()),
        "mrr": float((1.0 / (ranks + 1.0)).mean()),
        "phase_ap_macro": float(query_ap.mean()),
        "ranks": ranks,
        "query_ap": query_ap,
    }


def percentile_interval(values: np.ndarray) -> list[float]:
    return [
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    if sha256(args.protocol) != PROTOCOL_SHA256:
        raise ValueError("protocol hash mismatch")
    if sha256(args.source) != SOURCE_SHA256:
        raise ValueError("RealBind mini source hash mismatch")

    with np.load(args.source) as payload:
        queries = np.asarray(payload["X_query"], dtype=np.float64)
        masks = np.asarray(payload["M_query"], dtype=bool)
        query_uids = np.asarray(payload["query_uid"])
        candidates = np.asarray(payload["X_cand"], dtype=np.float64)
        has_simulation = np.asarray(payload["has_sim"], dtype=bool)
        candidate_uids = np.asarray(payload["cand_uid"])
        targets = np.asarray(payload["target"], dtype=np.int64)
    if queries.shape != (104, 1024) or candidates.shape != (104, 1024):
        raise ValueError("unexpected mini-RealBind tensor shape")
    if not has_simulation.all() or not (
        (targets >= 0) & (targets < len(candidates))
    ).all():
        raise ValueError("invalid source candidates or targets")

    score_arrays = {}
    random_matrix = np.empty((len(queries), len(candidates)), dtype=np.float64)
    global_matrix = np.empty_like(random_matrix)
    window_matrix = np.empty_like(random_matrix)
    for query_index in range(len(queries)):
        random_matrix[query_index] = random_scores(
            str(query_uids[query_index]),
            candidate_uids,
        )
        global_matrix[query_index] = global_scores(
            queries[query_index],
            masks[query_index],
            candidates,
        )
        window_matrix[query_index] = window_scores(
            queries[query_index],
            masks[query_index],
            candidates,
        )
        if masks[query_index].sum() < 10:
            random_matrix[query_index] = -np.inf
    score_arrays.update(
        {
            "deterministic_random": random_matrix,
            "global_sqrt_pearson": global_matrix,
            "window_sqrt_pearson": window_matrix,
        }
    )

    method_results = {}
    metric_arrays = {}
    for method in METHODS:
        metrics = metric_values(score_arrays[method], targets)
        metric_arrays[method] = metrics
        method_results[method] = {
            key: value
            for key, value in metrics.items()
            if key not in {"ranks", "query_ap"}
        }
    if abs(method_results["global_sqrt_pearson"]["recall_at_1"] - 78.85) > 0.05:
        raise ValueError("global score failed the RealBind R@1 check")
    if abs(method_results["global_sqrt_pearson"]["recall_at_10"] - 90.38) > 0.05:
        raise ValueError("global score failed the RealBind R@10 check")

    rng = np.random.default_rng(SEED)
    sampled = rng.integers(0, len(queries), size=(BOOTSTRAP_REPEATS, len(queries)))
    bootstrap_values = {
        method: {
            endpoint: np.empty(BOOTSTRAP_REPEATS)
            for endpoint in ("recall_at_1", "recall_at_10", "mrr", "phase_ap_macro")
        }
        for method in METHODS
    }
    for repeat, selected in enumerate(sampled):
        for method in METHODS:
            ranks = metric_arrays[method]["ranks"][selected]
            query_ap = metric_arrays[method]["query_ap"][selected]
            bootstrap_values[method]["recall_at_1"][repeat] = 100.0 * np.mean(ranks < 1)
            bootstrap_values[method]["recall_at_10"][repeat] = 100.0 * np.mean(ranks < 10)
            bootstrap_values[method]["mrr"][repeat] = np.mean(1.0 / (ranks + 1.0))
            bootstrap_values[method]["phase_ap_macro"][repeat] = query_ap.mean()
    for method in METHODS:
        method_results[method]["bootstrap_ci95"] = {
            endpoint: percentile_interval(values)
            for endpoint, values in bootstrap_values[method].items()
        }

    comparisons = {}
    for left, right in (
        ("window_sqrt_pearson", "global_sqrt_pearson"),
        ("global_sqrt_pearson", "deterministic_random"),
    ):
        name = f"{left}_minus_{right}"
        comparisons[name] = {}
        for endpoint in ("recall_at_1", "recall_at_10", "mrr", "phase_ap_macro"):
            differences = (
                bootstrap_values[left][endpoint]
                - bootstrap_values[right][endpoint]
            )
            estimate = method_results[left][endpoint] - method_results[right][endpoint]
            comparisons[name][endpoint] = {
                "estimate": estimate,
                "ci95": percentile_interval(differences),
            }

    rank_frame = pd.DataFrame(
        {
            "query_index": np.arange(len(queries)),
            "query_uid": query_uids,
            "target": targets,
            **{
                f"{method}_rank": metric_arrays[method]["ranks"]
                for method in METHODS
            },
            **{
                f"{method}_ap": metric_arrays[method]["query_ap"]
                for method in METHODS
            },
        }
    )
    report = {
        "status": "realbind_mini_evaluated",
        "claim_boundary": (
            "External retrospective single-phase cohort. It is not a "
            "multiphase source and not prospective validation."
        ),
        "source": {
            "doi": "10.5281/zenodo.23140154",
            "release": "RealBind 1.1.3",
            "license": "CC BY 4.0",
            "sha256": SOURCE_SHA256,
            "protocol_sha256": PROTOCOL_SHA256,
        },
        "contract": {
            "queries": len(queries),
            "candidates": len(candidates),
            "tie_rule": "conservative",
            "bootstrap_repeats": BOOTSTRAP_REPEATS,
            "seed": SEED,
        },
        "official_small_check": {
            "global_R@1_expected": 78.85,
            "global_R@10_expected": 90.38,
            "tolerance_points": 0.05,
            "passed": True,
        },
        "methods": method_results,
        "paired_deltas": comparisons,
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    rank_frame.to_csv(
        args.out_dir / "query_ranks.csv",
        index=False,
        lineterminator="\n",
    )
    (args.out_dir / "evaluation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(report["methods"], ensure_ascii=False, indent=2))
    print(f"evaluation_sha256={sha256(args.out_dir / 'evaluation.json')}")
    print(f"ranks_sha256={sha256(args.out_dir / 'query_ranks.csv')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
