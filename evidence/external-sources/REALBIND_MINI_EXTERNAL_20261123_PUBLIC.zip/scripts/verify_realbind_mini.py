"""Verify exact reproduction of the RealBind mini external evaluation."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary", type=Path, required=True)
    parser.add_argument("--reproduction", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    checks = {
        "source": sha256(args.source)
        == "00bd4742f0af524f9f88bcd98c16dfc59d4b77470597c296c34af4f6ad3d9678",
        "protocol": sha256(args.protocol)
        == "dab5dbcb2d4f9e5416cc1bf1d5075e32fa58002eed9528d83f1ba51a0bf555f4",
        "evaluation_exact_match": sha256(args.primary / "evaluation.json")
        == sha256(args.reproduction / "evaluation.json"),
        "ranks_exact_match": sha256(args.primary / "query_ranks.csv")
        == sha256(args.reproduction / "query_ranks.csv"),
    }
    report = {
        "status": (
            "realbind_mini_reproduction_exact_match"
            if all(checks.values())
            else "realbind_mini_reproduction_failed"
        ),
        "evaluation_sha256": sha256(args.primary / "evaluation.json"),
        "reproduced_evaluation_sha256": sha256(
            args.reproduction / "evaluation.json"
        ),
        "ranks_sha256": sha256(args.primary / "query_ranks.csv"),
        "reproduced_ranks_sha256": sha256(
            args.reproduction / "query_ranks.csv"
        ),
        "checks": checks,
    }
    args.out.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
