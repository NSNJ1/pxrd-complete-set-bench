# RealBind mini external single-phase protocol

Status: frozen before project-side scoring  
Freeze date: 2026-11-23  
Task: measured-PXRD to structure retrieval, one true phase per query  
Claim type: external retrospective boundary cohort

## Source and role

- Release: RealBind 1.1.3
- Deposit DOI: `10.5281/zenodo.23140154`
- Source file: `mini/mini_realbind.npz`
- SHA-256: `00bd4742f0af524f9f88bcd98c16dfc59d4b77470597c296c34af4f6ad3d9678`
- License: CC BY 4.0 for the mini subset
- Underlying source: opXRD, CC BY 4.0
- Queries: 104 measured patterns
- Candidates: 104 simulated structure-derived patterns

This is a single-phase cohort. It does not replace the EMPA multiphase source
and is not presented as a multiphase result. Its role is to test the N=1
boundary with a candidate library more than twenty times larger than the
four-candidate method panel.

## Inputs

The NPZ provides:

- `X_query`: 104 x 1024 normalized measured profiles;
- `M_query`: measured-support masks;
- `query_uid`;
- `X_cand`: 104 x 1024 simulated candidate profiles;
- `has_sim`;
- `cand_uid`;
- `target`: candidate index for each query.

The source file designates every opXRD query and candidate in the RealBind
common test library. No record is added or removed.

## Methods

1. deterministic random ranking, seed `20261123`;
2. global sqrt-Pearson over each query's measured mask;
3. eight-window sqrt-Pearson.

For the eight-window method, the measured mask is split into eight consecutive
windows of equal point count using `numpy.array_split`. A window contributes
only when it has at least 10 points. Window scores are averaged without
reweighting. No window is selected using the target.

The global method follows the RealBind masked-correlation definition. Its
reported RealBind R@1/R@10 values must agree with the official mini expectation
to within 0.05 percentage points before the cohort is accepted.

## Metrics and ties

Primary metrics:

- R@1;
- R@10;
- mean reciprocal rank;
- phase average precision.

Secondary metrics are R@3 and R@5.

The conservative RealBind tie rule is used: rank equals the number of
candidates with score greater than or equal to the target, minus one. A query
with no valid score is a miss.

Uncertainty uses 10,000 bootstrap samples of the 104 queries with seed
`20261123`. Pairwise global-versus-window intervals use the same resampled
queries.

## Gates

The source is accepted only if:

- all 104 queries and 104 candidates are present;
- all target indices are valid;
- the global method reproduces RealBind's official mini R@1 and R@10 within
  0.05 percentage points.

No claim that the eight-window method is superior is made unless its paired
95% interval excludes zero in the same direction for both R@1 and MRR.

## Claim boundary

RealBind was not part of the seven consumed source cohorts, but its mini subset
is public and was inspected after project development. The result is therefore
external retrospective evidence, not prospective validation. It measures
single-phase retrieval and cannot be pooled into a complete-multiphase score.
