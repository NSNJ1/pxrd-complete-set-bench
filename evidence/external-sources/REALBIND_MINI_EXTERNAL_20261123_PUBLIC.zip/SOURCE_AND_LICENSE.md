# Source and licence

This package uses the mini-RealBind subset from the RealBind 1.1.3 release.

- RealBind DOI: `10.5281/zenodo.23140154`
- Source file: `mini/mini_realbind.npz`
- Source SHA-256:
  `00bd4742f0af524f9f88bcd98c16dfc59d4b77470597c296c34af4f6ad3d9678`
- Mini-RealBind data licence: CC BY 4.0
- Underlying source: opXRD, CC BY 4.0
- RealBind code licence: MIT

The included `official_mini_expected.json` is the RealBind file used to check
the official global masked-correlation baseline. The source documentation and
all attribution remain with the RealBind release.
