# opXRD EMPA external retrospective protocol, version 2

Status: frozen after schema inspection and before any method score  
Freeze date: 2026-11-23  
Supersedes: `OPXRD_PROTOCOL_FROZEN_20261123.md`  
Claim type: external retrospective evaluation, not prospective validation

## Why version 2 exists

Version 1 required one common six-field phase encoding and at least four
institutions. A post-freeze schema audit showed that opXRD contributors encode
labels differently:

- CNRS records contain full lattice and basis structures but no explicit
  space-group field;
- EMPA records contain formula and space group but no lattice or basis;
- LBNL, INT and IKFT contain large numbers of unlabelled records;
- USC records are heterogeneous and often incomplete.

No model score was computed under version 1. Version 2 narrows the source and
uses a candidate library independently anchored in COD, so a query's phase
labels never serve as candidate reference structures.

## Query source

- Source: opXRD, Zenodo record `10.5281/zenodo.15298026`
- Archive: `opxrd.zip`, 1,400,997,733 bytes
- Published MD5: `e8e9800a8ecd2b7f01a764fdf77d5c53`
- Data licence: CC BY 4.0
- Query contribution: all records under `EMPA/`
- Original records: `EMPA/pattern_*.json`

Only EMPA records are used as measured queries in this source test.

## Candidate library

The candidate library is frozen before scoring:

| ID | Formula label | Space group | Reference | CIF SHA-256 |
| --- | --- | ---: | --- | --- |
| `PbBr2_62` | PbBr2 | 62 | COD 9009196 | `c48c8be3b7aaa09b7fa0f01e724005b565e943901bd10a8e2c3d70cbfa84fd6e` |
| `PbCl2_62` | PbCl2 | 62 | COD 9009195 | `e5b9354813fcbce74d1c353037b9a8736a0c84cbf842b616b5cd9bb918c04d48` |
| `PbI2_164` | PbI2 | 164 | COD 1010062 | `037aa67866eed8f5c940968313d9607c2dd822a00532bc30b614772b4339fc65` |
| `MAPbI3_140` | CH3NHPbI3 | 140 | COD 4124388 | `8bfdbc88697aeafe3ff2e02578e77b25233d5f79dd2f9927514b5ff6b89e825c` |

Candidate CIFs are stored under `opxrd_empa_20261123/candidates/`. COD
structures are CC0. The four candidates were selected before scoring from a
small set of recurring EMPA multiphase identities. No benchmark outcome was
used in their selection.

## Query eligibility

An EMPA record is eligible only when:

1. the label parses into exactly two non-null phase dictionaries;
2. each phase has an explicit, non-empty formula other than `nan`;
3. each phase has a finite integer space-group number;
4. the normalized `(formula, space group)` pair is one of the four frozen
   candidate identities;
5. the two identities are distinct;
6. both label entries are retained as true phases, regardless of whether a
   phase fraction is missing;
7. the spectrum has at least 100 finite points, strictly increasing two-theta,
   and positive maximum intensity;
8. the recorded primary or secondary wavelength is within 1.53-1.56 A, so the
   COD Cu K-alpha reference is physically appropriate.

Formula normalization removes case-irrelevant whitespace and parenthetical
annotations such as `(alpha phase)`. It does not alter element symbols,
stoichiometric digits, or the space-group number.

If an EMPA record contains `nan` in either phase slot, a missing space group, a
different wavelength, or a fifth recurring identity absent from the frozen
library, it is excluded with a recorded reason.

## Query cap and clustering

Every eligible query is sorted by:

```text
SHA256("opxrd-empa-v2|20261123|" + record_path)
```

At most 200 queries are retained, stopping earlier if fewer are eligible.
The cluster identifier is the normalized `metadata.filename` when present;
otherwise it is the record path. Files sharing a non-empty original filename
remain in the same bootstrap cluster.

## Reference profiles

The candidate references are generated from the four COD CIFs with pymatgen
`XRDCalculator` at 1.5405929 A. Each pattern is convolved with a Gaussian of
0.15 degree FWHM on a fixed 10-120 degree, 0.02 degree grid and max-normalized.
The exact grid, wavelength, FWHM, peak simulator and CIF hashes are frozen.

Measured queries are linearly interpolated to the same grid. Positive
intensity is retained, the 5th percentile is subtracted as a background floor,
and the result is max-normalized. The mask contains only grid points inside a
query's measured two-theta interval.

## Methods

The following methods run on the same four-candidate library:

1. deterministic random ranking, seed `20261123`;
2. sqrt-global Pearson similarity;
3. sqrt-window Pearson, using 64-point windows at indices
   `3,6,7,9,4,5,8,2`;
4. anchored-set strict, using global-Pearson anchor selection, polynomial
   background removal, non-negative phase amplitudes, BIC beam search over
   one to four phases, and posterior inclusion ranking.

The anchored-set implementation follows the existing frozen PXRD benchmark
decoder. No threshold, feature, or candidate identity is tuned on EMPA labels.

## Endpoints and statistics

Primary endpoints:

- two-phase AP;
- exact-set success at 2, which is all-present@2 for every eligible query;
- all-present@3;
- dominant or anchor stability as a secondary diagnostic.

Uncertainty uses 10,000 query-cluster bootstrap replicates with seed
`20261123`. Paired method differences use the same sampled clusters. Holm
correction is applied to the four prespecified pairwise contrasts.

## Interpretation gates

The source is informative only if at least 20 eligible queries remain and
deterministic random all-present@3 is below 75%.

Evidence that anchored-set strict beats global Pearson requires:

- at least a 5 percentage-point gain in all-present@2;
- lower 95% interval of the paired gain above zero;
- a non-negative gain in phase AP.

If the anchored method fails these gates, the result is reported as a negative
or mixed external confirmation. It cannot be used to claim universal
superiority.

## Claim boundary and leakage

opXRD was not one of the seven source cohorts in PXRD-CompleteSetBench and no
method result from this EMPA subset was previously computed. Because the source
and labels are public, this is external retrospective evidence. It becomes
prospective only if an unseen source is frozen before its labels are opened,
which is not the case here.

Candidate CIFs come from COD rather than from the query labels, eliminating
query-template circularity for the four candidates. Any formula or space-group
error in the EMPA labels remains a source-label error and is not repaired.
