"""Verify exact reproduction of the frozen opXRD EMPA evaluation."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def md5(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_hash(directory: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(item for item in directory.rglob("*") if item.is_file()):
        relative = path.relative_to(directory).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(sha256(path).encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary", type=Path, required=True)
    parser.add_argument("--secondary", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--reproduced-dataset", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    primary_evaluation = sha256(args.primary / "evaluation.json")
    secondary_evaluation = sha256(args.secondary / "evaluation.json")
    primary_scores = sha256(args.primary / "method_scores.csv")
    secondary_scores = sha256(args.secondary / "method_scores.csv")
    checks = {
        "protocol": sha256(args.protocol)
        == "11b8f15c2a1e1e31d1bd81579d43f438770a4b5e6e09096df1b130202deb627a",
        "source_md5": md5(args.archive) == "e8e9800a8ecd2b7f01a764fdf77d5c53",
        "dataset_manifest": sha256(args.dataset / "dataset_manifest.json")
        == "547edc777b29606fa544f6ac866f34d6462e8f4d968528632483940a37bb8a29",
        "dataset_manifest_exact_match": sha256(
            args.dataset / "dataset_manifest.json"
        )
        == sha256(args.reproduced_dataset / "dataset_manifest.json"),
        "queries_exact_match": sha256(args.dataset / "queries.csv")
        == sha256(args.reproduced_dataset / "queries.csv"),
        "pairs_exact_match": sha256(args.dataset / "query_phase_pairs.csv")
        == sha256(args.reproduced_dataset / "query_phase_pairs.csv"),
        "candidate_library_exact_match": sha256(
            args.dataset / "candidate_library.csv"
        )
        == sha256(args.reproduced_dataset / "candidate_library.csv"),
        "eligibility_exact_match": sha256(args.dataset / "eligibility.csv")
        == sha256(args.reproduced_dataset / "eligibility.csv"),
        "spectra_exact_match": tree_hash(args.dataset / "spectra")
        == tree_hash(args.reproduced_dataset / "spectra"),
        "candidates_exact_match": tree_hash(args.dataset / "candidates")
        == tree_hash(args.reproduced_dataset / "candidates"),
        "evaluation_exact_match": primary_evaluation == secondary_evaluation,
        "scores_exact_match": primary_scores == secondary_scores,
    }
    report = {
        "status": (
            "opxrd_empa_reproduction_exact_match"
            if all(checks.values())
            else "opxrd_empa_reproduction_failed"
        ),
        "evaluation_sha256": primary_evaluation,
        "reproduced_evaluation_sha256": secondary_evaluation,
        "scores_sha256": primary_scores,
        "reproduced_scores_sha256": secondary_scores,
        "checks": checks,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
