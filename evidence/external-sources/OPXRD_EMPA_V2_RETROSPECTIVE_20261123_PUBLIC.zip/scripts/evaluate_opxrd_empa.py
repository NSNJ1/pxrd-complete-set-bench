"""Evaluate frozen profile scorers on the opXRD EMPA external subset."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.optimize import nnls
from sklearn.metrics import average_precision_score

PROTOCOL_SHA256 = "11b8f15c2a1e1e31d1bd81579d43f438770a4b5e6e09096df1b130202deb627a"
GRID = np.round(np.arange(10.0, 120.0 + 0.01, 0.02), 8)
WAVELENGTH = 1.5405929
FWHM = 0.15
BACKGROUND_QUANTILE = 0.05
WINDOW_POINTS = 64
PANEL = (3, 6, 7, 9, 4, 5, 8, 2)
BUDGETS = (1, 2, 3, 4)
REVIEW_BUDGET = 3
MAX_COMPONENTS = 4
BEAM_WIDTH = 24
BACKGROUND_DEGREE = 5
BOOTSTRAP_REPEATS = 10_000
SEED = 20261123
METHODS = (
    "deterministic_random",
    "global_sqrt_pearson",
    "window_sqrt_pearson",
    "anchored_set_strict",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def candidate_hash(query: str, phase: str) -> float:
    digest = hashlib.sha256(f"{SEED}|{query}|{phase}".encode()).digest()
    return int.from_bytes(digest[:8], "big") / (2**64 - 1)


def simulate_candidate(cif_path: Path) -> np.ndarray:
    structure = Structure.from_file(str(cif_path))
    pattern = XRDCalculator(wavelength=WAVELENGTH).get_pattern(
        structure,
        two_theta_range=(10.0, 120.0),
    )
    sigma = FWHM / (2.0 * math.sqrt(2.0 * math.log(2.0)))
    profile = np.zeros_like(GRID)
    for position, intensity in zip(pattern.x, pattern.y, strict=True):
        profile += intensity * np.exp(-0.5 * ((GRID - position) / sigma) ** 2)
    profile = np.clip(profile, 0.0, None)
    maximum = float(profile.max())
    if maximum <= 0:
        raise ValueError(f"candidate produced no signal: {cif_path}")
    return profile / maximum


def load_query(spectrum_path: Path) -> tuple[np.ndarray, np.ndarray]:
    with np.load(spectrum_path) as payload:
        two_theta = np.asarray(payload["two_theta"], dtype=np.float64)
        intensity = np.asarray(payload["intensity"], dtype=np.float64)
    order = np.argsort(two_theta, kind="stable")
    two_theta = two_theta[order]
    intensity = intensity[order]
    profile = np.interp(GRID, two_theta, intensity, left=np.nan, right=np.nan)
    mask = np.isfinite(profile)
    profile[~mask] = 0.0
    profile = np.clip(profile, 0.0, None)
    floor = float(np.quantile(profile[mask], BACKGROUND_QUANTILE))
    profile = np.clip(profile - floor, 0.0, None)
    maximum = float(profile[mask].max())
    if maximum <= 0:
        raise ValueError(f"query produced no signal: {spectrum_path}")
    return profile / maximum, mask


def normal_rows(matrix: np.ndarray) -> np.ndarray:
    values = np.asarray(matrix, dtype=np.float64)
    centered = values - values.mean(axis=1, keepdims=True)
    norms = np.linalg.norm(centered, axis=1, keepdims=True)
    return np.divide(
        centered,
        norms,
        out=np.zeros_like(centered),
        where=norms > 0,
    )


def pearson_scores(
    query: np.ndarray,
    candidates: np.ndarray,
    mask: np.ndarray,
) -> np.ndarray:
    query_row = normal_rows(query[mask][None, :])[0]
    candidate_rows = normal_rows(candidates[:, mask])
    return candidate_rows @ query_row


def window_pearson_scores(
    query: np.ndarray,
    candidates: np.ndarray,
    mask: np.ndarray,
) -> np.ndarray:
    total = np.zeros(len(candidates), dtype=np.float64)
    valid_windows = 0
    for window in PANEL:
        start = int(window) * WINDOW_POINTS
        stop = start + WINDOW_POINTS
        window_mask = mask[start:stop]
        if not window_mask.any():
            continue
        total += pearson_scores(
            query[start:stop],
            candidates[:, start:stop],
            window_mask,
        )
        valid_windows += 1
    if valid_windows == 0:
        return np.zeros(len(candidates), dtype=np.float64)
    return total / valid_windows


def background_basis(points: int) -> np.ndarray:
    position = np.linspace(-1.0, 1.0, points)
    return np.column_stack(
        [position**degree for degree in range(BACKGROUND_DEGREE + 1)]
    )


def fit_set(
    y: np.ndarray,
    residual_profiles: np.ndarray,
    subset: tuple[int, ...],
) -> tuple[np.ndarray, float, float]:
    design = residual_profiles[list(subset), :].T
    weights, residual_norm = nnls(
        design,
        y,
        maxiter=8 * design.shape[1],
    )
    rss = float(residual_norm * residual_norm)
    parameter_count = BACKGROUND_DEGREE + 1 + len(subset)
    bic = y.size * math.log(max(rss / y.size, 1e-15)) + parameter_count * math.log(
        y.size
    )
    return weights, rss, float(bic)


def decode_anchored_set(
    query: np.ndarray,
    references: np.ndarray,
    anchor: int,
    mask: np.ndarray,
) -> dict:
    root_query = np.sqrt(np.clip(query, 0.0, None))[mask]
    root_references = np.sqrt(np.clip(references, 0.0, None))[:, mask]
    q_basis, _ = np.linalg.qr(
        background_basis(root_query.size),
        mode="reduced",
    )
    y = root_query - q_basis @ (q_basis.T @ root_query)
    residual_references = (
        root_references.T - q_basis @ (q_basis.T @ root_references.T)
    ).T
    candidate_count = references.shape[0]
    max_components = min(MAX_COMPONENTS, candidate_count)
    anchor_subset = (int(anchor),)
    anchor_weights, anchor_rss, anchor_bic = fit_set(
        y,
        residual_references,
        anchor_subset,
    )
    beams = {anchor_subset}
    models = [
        {
            "subset": anchor_subset,
            "weights": anchor_weights,
            "rss": anchor_rss,
            "bic": anchor_bic,
        }
    ]
    for _target_size in range(2, max_components + 1):
        expanded = set()
        for subset in beams:
            for candidate in range(candidate_count):
                if candidate not in subset:
                    expanded.add(tuple(sorted((*subset, candidate))))
        scored = []
        for subset in expanded:
            weights, rss, bic = fit_set(
                y,
                residual_references,
                subset,
            )
            scored.append(
                {
                    "subset": subset,
                    "weights": weights,
                    "rss": rss,
                    "bic": bic,
                }
            )
        scored.sort(key=lambda item: item["bic"])
        beams = {tuple(item["subset"]) for item in scored[:BEAM_WIDTH]}
        models.extend(scored[:BEAM_WIDTH])
    models.sort(key=lambda item: item["bic"])
    minimum = models[0]["bic"]
    posterior = np.exp(-0.5 * np.asarray([model["bic"] - minimum for model in models]))
    posterior /= posterior.sum()
    inclusion = np.zeros(candidate_count, dtype=np.float64)
    for model, probability in zip(models, posterior, strict=True):
        inclusion[list(model["subset"])] += probability
    return {
        "inclusion": inclusion,
        "map_bic": float(models[0]["bic"]),
        "models_scored": len(models),
    }


def metric_values(
    truth: np.ndarray,
    scores: np.ndarray,
) -> dict:
    query_ap = np.asarray(
        [
            average_precision_score(truth[index], scores[index])
            for index in range(len(truth))
        ]
    )
    minimum_k = np.empty(len(truth), dtype=np.int64)
    all_present = np.zeros((len(truth), len(BUDGETS)), dtype=bool)
    for index in range(len(truth)):
        order = np.argsort(-scores[index], kind="stable")
        positives = np.flatnonzero(truth[index])
        rank = {
            candidate: position for position, candidate in enumerate(order, start=1)
        }
        minimum_k[index] = max(rank[positive] for positive in positives)
        all_present[index] = [minimum_k[index] <= budget for budget in BUDGETS]
    return {
        "phase_ap_micro": float(average_precision_score(truth.ravel(), scores.ravel())),
        "phase_ap_macro": float(query_ap.mean()),
        "mean_minimum_k": float(minimum_k.mean()),
        **{
            f"all_present_at_{budget}": float(all_present[:, index].mean())
            for index, budget in enumerate(BUDGETS)
        },
        "query_ap": query_ap,
        "all_present_matrix": all_present,
    }


def tie_orders(scores: np.ndarray) -> list[tuple[int, ...]]:
    groups = {}
    for index, score in enumerate(scores):
        groups.setdefault(float(score), []).append(index)
    blocks = [
        list(itertools.permutations(groups[score]))
        for score in sorted(groups, reverse=True)
    ]
    return [
        tuple(index for block in order for index in block)
        for order in itertools.product(*blocks)
    ]


def tie_bounds(truth: np.ndarray, scores: np.ndarray) -> dict:
    result = {}
    for budget in (2, 3):
        values = []
        for query_index in range(len(truth)):
            positives = set(np.flatnonzero(truth[query_index]).tolist())
            outcomes = [
                positives.issubset(order[:budget])
                for order in tie_orders(scores[query_index])
            ]
            values.append((all(outcomes), any(outcomes)))
        result[str(budget)] = {
            "min": float(np.mean([value[0] for value in values])),
            "max": float(np.mean([value[1] for value in values])),
        }
    return result


def bootstrap(
    truth: np.ndarray,
    score_arrays: dict[str, np.ndarray],
) -> dict[str, dict[str, np.ndarray]]:
    rng = np.random.default_rng(SEED)
    sampled = rng.integers(0, len(truth), size=(BOOTSTRAP_REPEATS, len(truth)))
    output = {
        method: {
            "phase_ap_micro": np.empty(BOOTSTRAP_REPEATS),
            "all_present_at_2": np.empty(BOOTSTRAP_REPEATS),
            "all_present_at_3": np.empty(BOOTSTRAP_REPEATS),
        }
        for method in METHODS
    }
    for repeat, selected in enumerate(sampled):
        local_truth = truth[selected]
        for method in METHODS:
            local_scores = score_arrays[method][selected]
            output[method]["phase_ap_micro"][repeat] = average_precision_score(
                local_truth.ravel(),
                local_scores.ravel(),
            )
            for budget in (2, 3):
                successes = []
                for query_index in range(len(local_truth)):
                    order = np.argsort(-local_scores[query_index], kind="stable")
                    positives = set(np.flatnonzero(local_truth[query_index]).tolist())
                    successes.append(positives.issubset(order[:budget]))
                output[method][f"all_present_at_{budget}"][repeat] = np.mean(successes)
    return output


def percentile_interval(values: np.ndarray) -> list[float]:
    return [
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    ]


def bootstrap_p_value(left: np.ndarray, right: np.ndarray) -> float:
    difference = left - right
    lower = (1 + int(np.sum(difference <= 0))) / (len(difference) + 1)
    upper = (1 + int(np.sum(difference >= 0))) / (len(difference) + 1)
    return float(min(1.0, 2.0 * min(lower, upper)))


def holm_adjust(values: dict[str, float]) -> dict[str, float]:
    ordered = sorted(values.items(), key=lambda item: item[1])
    running = 0.0
    total = len(ordered)
    output = {}
    for rank, (name, value) in enumerate(ordered, start=1):
        running = max(running, min(1.0, (total - rank + 1) * value))
        output[name] = running
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-dir", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    if sha256(args.protocol) != PROTOCOL_SHA256:
        raise ValueError("protocol hash mismatch")

    dataset_manifest = json.loads(
        (args.dataset_dir / "dataset_manifest.json").read_text(encoding="utf-8")
    )
    queries = pd.read_csv(args.dataset_dir / "queries.csv").sort_values("query_id")
    pairs = pd.read_csv(args.dataset_dir / "query_phase_pairs.csv")
    candidates = pd.read_csv(args.dataset_dir / "candidate_library.csv").sort_values(
        "phase_id"
    )
    phase_ids = tuple(candidates["phase_id"])
    if len(queries) != int(dataset_manifest["selected_queries"]):
        raise ValueError("query count does not match dataset manifest")
    if len(phase_ids) != 4:
        raise ValueError("the frozen library must contain four candidates")

    for row in candidates.itertuples(index=False):
        if sha256(args.dataset_dir / row.cif_file) != row.sha256:
            raise ValueError(f"candidate hash mismatch: {row.cif_file}")
    references = np.stack(
        [
            simulate_candidate(args.dataset_dir / row.cif_file)
            for row in candidates.itertuples(index=False)
        ]
    )

    pair_lookup = {
        (row.query_id, row.phase_id): int(row.present)
        for row in pairs.itertuples(index=False)
    }
    truth = np.zeros((len(queries), len(phase_ids)), dtype=np.int64)
    score_rows = []
    for query_index, query in enumerate(queries.itertuples(index=False)):
        profile, mask = load_query(
            args.dataset_dir / "spectra" / f"{query.query_id}.npz"
        )
        for candidate_index, phase_id in enumerate(phase_ids):
            truth[query_index, candidate_index] = pair_lookup.get(
                (query.query_id, phase_id),
                0,
            )
        root_query = np.sqrt(profile)
        root_references = np.sqrt(references)
        global_scores = pearson_scores(root_query, root_references, mask)
        window_scores = window_pearson_scores(
            root_query,
            root_references,
            mask,
        )
        anchored = decode_anchored_set(
            profile,
            references,
            int(np.argmax(global_scores)),
            mask,
        )["inclusion"]
        method_scores = {
            "deterministic_random": np.asarray(
                [candidate_hash(query.query_id, phase_id) for phase_id in phase_ids]
            ),
            "global_sqrt_pearson": global_scores,
            "window_sqrt_pearson": window_scores,
            "anchored_set_strict": anchored,
        }
        for method, scores in method_scores.items():
            for phase_id, score in zip(phase_ids, scores, strict=True):
                score_rows.append(
                    {
                        "method": method,
                        "query_id": query.query_id,
                        "cluster_id": query.cluster_id,
                        "phase_id": phase_id,
                        "score": float(score),
                        "present": int(pair_lookup.get((query.query_id, phase_id), 0)),
                    }
                )

    score_frame = pd.DataFrame(score_rows)
    score_arrays = {}
    method_results = {}
    for method in METHODS:
        local = score_frame.loc[score_frame["method"].eq(method)]
        values = (
            local.pivot(index="query_id", columns="phase_id", values="score")
            .reindex(index=queries["query_id"], columns=list(phase_ids))
            .to_numpy(dtype=np.float64)
        )
        score_arrays[method] = values
        metrics = metric_values(truth, values)
        method_results[method] = {
            "phase_ap_micro": metrics["phase_ap_micro"],
            "phase_ap_macro": metrics["phase_ap_macro"],
            "mean_minimum_k": metrics["mean_minimum_k"],
            **{
                f"all_present_at_{budget}": metrics[f"all_present_at_{budget}"]
                for budget in BUDGETS
            },
            "tie_order_bounds": tie_bounds(truth, values),
        }

    bootstrap_values = bootstrap(truth, score_arrays)
    for method in METHODS:
        method_results[method]["bootstrap_ci95"] = {
            endpoint: percentile_interval(bootstrap_values[method][endpoint])
            for endpoint in (
                "phase_ap_micro",
                "all_present_at_2",
                "all_present_at_3",
            )
        }

    comparisons = {}
    pairs_to_compare = (
        ("anchored_set_strict", "global_sqrt_pearson"),
        ("anchored_set_strict", "window_sqrt_pearson"),
        ("anchored_set_strict", "deterministic_random"),
        ("global_sqrt_pearson", "window_sqrt_pearson"),
    )
    for left, right in pairs_to_compare:
        name = f"{left}_minus_{right}"
        comparisons[name] = {}
        for endpoint in ("phase_ap_micro", "all_present_at_2", "all_present_at_3"):
            estimate = method_results[left][endpoint] - method_results[right][endpoint]
            difference = (
                bootstrap_values[left][endpoint] - bootstrap_values[right][endpoint]
            )
            comparisons[name][endpoint] = {
                "estimate": estimate,
                "ci95": percentile_interval(difference),
                "p_value": bootstrap_p_value(
                    bootstrap_values[left][endpoint],
                    bootstrap_values[right][endpoint],
                ),
            }
    for endpoint in ("phase_ap_micro", "all_present_at_2", "all_present_at_3"):
        adjusted = holm_adjust(
            {name: values[endpoint]["p_value"] for name, values in comparisons.items()}
        )
        for name, value in adjusted.items():
            comparisons[name][endpoint]["p_value_holm"] = value

    selected_query_ids = set(queries["query_id"])
    report = {
        "status": "opxrd_empa_external_evaluated",
        "claim_boundary": (
            "External retrospective evaluation on an EMPA opXRD subset. "
            "Not prospective validation and not a claim of universal SOTA."
        ),
        "source": {
            "doi": "10.5281/zenodo.15298026",
            "md5": "e8e9800a8ecd2b7f01a764fdf77d5c53",
            "protocol_sha256": PROTOCOL_SHA256,
        },
        "contract": {
            "queries": len(queries),
            "clusters": int(queries["cluster_id"].nunique()),
            "candidates": len(phase_ids),
            "candidate_ids": list(phase_ids),
            "budgets": list(BUDGETS),
            "review_budget": REVIEW_BUDGET,
            "bootstrap_repeats": BOOTSTRAP_REPEATS,
            "seed": SEED,
        },
        "eligibility": {
            "empa_records": dataset_manifest["empa_records"],
            "eligible_before_cap": dataset_manifest["eligible_before_cap"],
            "selected_queries": dataset_manifest["selected_queries"],
            "exclusion_reason_counts": dataset_manifest["exclusion_reason_counts"],
        },
        "methods": method_results,
        "pairwise_paired_deltas": comparisons,
        "query_scope": {
            "source_archive_sha256": sha256(args.archive),
            "dataset_manifest_sha256": sha256(
                args.dataset_dir / "dataset_manifest.json"
            ),
            "queries_sha256": sha256(args.dataset_dir / "queries.csv"),
            "pairs_sha256": sha256(args.dataset_dir / "query_phase_pairs.csv"),
            "selected_query_ids_sha256": hashlib.sha256(
                "\n".join(sorted(selected_query_ids)).encode()
            ).hexdigest(),
        },
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    score_frame.sort_values(["method", "query_id", "phase_id"]).to_csv(
        args.out_dir / "method_scores.csv",
        index=False,
        lineterminator="\n",
    )
    (args.out_dir / "evaluation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {
                method: {
                    endpoint: values[endpoint]
                    for endpoint in (
                        "phase_ap_micro",
                        "all_present_at_2",
                        "all_present_at_3",
                    )
                }
                for method, values in method_results.items()
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    print(f"evaluation_sha256={sha256(args.out_dir / 'evaluation.json')}")
    print(f"scores_sha256={sha256(args.out_dir / 'method_scores.csv')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
