"""Prepare the frozen EMPA opXRD subset under protocol version 2."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import zipfile
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

SOURCE_DOI = "10.5281/zenodo.15298026"
SOURCE_MD5 = "e8e9800a8ecd2b7f01a764fdf77d5c53"
PROTOCOL_SHA256 = "11b8f15c2a1e1e31d1bd81579d43f438770a4b5e6e09096df1b130202deb627a"
QUERY_CAP = 200
SEED = 20261123

CANDIDATES = {
    ("PbBr2", 62): {
        "phase_id": "PbBr2_62",
        "formula": "PbBr2",
        "spacegroup": 62,
        "cod_id": "9009196",
        "cif_file": "candidates/PbBr2_62_COD9009196.cif",
    },
    ("PbCl2", 62): {
        "phase_id": "PbCl2_62",
        "formula": "PbCl2",
        "spacegroup": 62,
        "cod_id": "9009195",
        "cif_file": "candidates/PbCl2_62_COD9009195.cif",
    },
    ("PbI2", 164): {
        "phase_id": "PbI2_164",
        "formula": "PbI2",
        "spacegroup": 164,
        "cod_id": "1010062",
        "cif_file": "candidates/PbI2_164_COD1010062.cif",
    },
    ("CH3NHPbI3", 140): {
        "phase_id": "MAPbI3_140",
        "formula": "CH3NHPbI3",
        "spacegroup": 140,
        "cod_id": "4124388",
        "cif_file": "candidates/MAPbI3_140_COD4124388.cif",
    },
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nested_json(value):
    if isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return None
    return value


def normalize_formula(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    formula = re.sub(r"\([^)]*\)", "", value)
    formula = re.sub(r"\s+", "", formula).strip()
    if not formula or formula.lower() == "nan":
        return None
    return formula


def parse_phase(raw_phase) -> dict | None:
    phase = nested_json(raw_phase)
    if not isinstance(phase, dict):
        return None
    formula = normalize_formula(phase.get("chemical_composition"))
    try:
        spacegroup = int(phase.get("spacegroup"))
    except (TypeError, ValueError):
        spacegroup = None
    return {
        "formula": formula,
        "spacegroup": spacegroup,
        "phase_fraction": phase.get("phase_fraction"),
    }


def wavelength_ok(label: dict) -> tuple[bool, float | None]:
    xray = nested_json(label.get("xray_info"))
    if not isinstance(xray, dict):
        return False, None
    wavelengths = []
    for key in ("primary_wavelength", "secondary_wavelength"):
        try:
            value = float(xray.get(key))
        except (TypeError, ValueError):
            continue
        if math.isfinite(value):
            wavelengths.append(value)
    eligible = [value for value in wavelengths if 1.53 <= value <= 1.56]
    if not eligible:
        return False, None
    return True, eligible[0]


def spectrum_ok(payload: dict) -> tuple[bool, str, np.ndarray, np.ndarray]:
    try:
        angle = np.asarray(payload["two_theta_values"], dtype=np.float64)
        intensity = np.asarray(payload["intensities"], dtype=np.float64)
    except (KeyError, TypeError, ValueError):
        return False, "spectrum_parse", np.array([]), np.array([])
    if len(angle) < 100 or len(angle) != len(intensity):
        return False, "too_few_or_mismatched_points", angle, intensity
    if not np.isfinite(angle).all() or not np.isfinite(intensity).all():
        return False, "nonfinite_spectrum", angle, intensity
    if np.any(np.diff(angle) <= 0):
        return False, "nonmonotone_two_theta", angle, intensity
    if float(intensity.max()) <= 0:
        return False, "nonpositive_intensity", angle, intensity
    return True, "", angle, intensity


def metadata_cluster(payload: dict, record_path: str) -> str:
    metadata = nested_json(payload.get("metadata"))
    if isinstance(metadata, dict):
        filename = metadata.get("filename")
        if isinstance(filename, str) and filename.strip():
            return filename.strip().replace("\\", "/")
    return record_path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    args = parser.parse_args()
    if not args.archive.is_file():
        raise FileNotFoundError(args.archive)
    if sha256(args.protocol) != PROTOCOL_SHA256:
        raise ValueError("protocol hash does not match the frozen version")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    spectra_dir = args.out_dir / "spectra"
    spectra_dir.mkdir(exist_ok=True)

    candidate_rows = []
    for candidate in CANDIDATES.values():
        cif = args.out_dir / candidate["cif_file"]
        candidate_rows.append(
            {
                **candidate,
                "sha256": sha256(cif),
            }
        )
    candidate_frame = pd.DataFrame(candidate_rows).sort_values("phase_id")
    candidate_frame.to_csv(
        args.out_dir / "candidate_library.csv",
        index=False,
        lineterminator="\n",
    )

    eligible = []
    exclusions = []
    total_empa = 0
    with zipfile.ZipFile(args.archive) as archive:
        names = sorted(
            name
            for name in archive.namelist()
            if name.startswith("EMPA/") and name.endswith(".json")
        )
        for name in names:
            total_empa += 1
            payload = json.loads(archive.read(name))
            reasons = []
            label = nested_json(payload.get("label"))
            if not isinstance(label, dict):
                reasons.append("label_parse")
                raw_phases = []
            else:
                raw_phases = label.get("phases", [])
            if len(raw_phases) != 2:
                reasons.append(f"phase_count_{len(raw_phases)}")
            phases = [parse_phase(item) for item in raw_phases]
            if len(phases) != 2 or any(phase is None for phase in phases):
                reasons.append("phase_parse")
                phases = []
            if phases:
                if any(
                    phase["formula"] is None or phase["spacegroup"] is None
                    for phase in phases
                ):
                    reasons.append("incomplete_formula_or_spacegroup")
                identities = [
                    (phase["formula"], phase["spacegroup"])
                    for phase in phases
                ]
                if identities[0] == identities[1]:
                    reasons.append("duplicate_identity")
                if any(identity not in CANDIDATES for identity in identities):
                    reasons.append("identity_outside_frozen_library")
            wavelength_valid, wavelength = wavelength_ok(
                label if isinstance(label, dict) else {}
            )
            if not wavelength_valid:
                reasons.append("wavelength_not_cu")
            spectrum_valid, spectrum_reason, angle, intensity = spectrum_ok(payload)
            if not spectrum_valid:
                reasons.append(spectrum_reason)

            record = {
                "source_path": name,
                "eligible": not reasons,
                "reasons": "|".join(dict.fromkeys(reasons)),
            }
            if reasons:
                exclusions.append(record)
                continue

            query_number = int(re.search(r"pattern_(\d+)\.json$", name).group(1))
            query_id = f"opxrd_empa_{query_number:04d}"
            cluster_id = metadata_cluster(payload, name)
            true_ids = sorted(
                CANDIDATES[identity]["phase_id"]
                for identity in identities
            )
            np.savez_compressed(
                spectra_dir / f"{query_id}.npz",
                two_theta=angle,
                intensity=intensity,
            )
            eligible.append(
                {
                    "query_id": query_id,
                    "cluster_id": cluster_id,
                    "source_path": name,
                    "wavelength_angstrom": wavelength,
                    "points": int(len(angle)),
                    "two_theta_min": float(angle.min()),
                    "two_theta_max": float(angle.max()),
                    "phase_ids": "|".join(true_ids),
                    "phase_formulas": "|".join(
                        sorted(phase["formula"] for phase in phases)
                    ),
                }
            )

    eligible.sort(
        key=lambda record: hashlib.sha256(
            (
                "opxrd-empa-v2|20261123|"
                + record["source_path"]
            ).encode()
        ).hexdigest()
    )
    selected = eligible[:QUERY_CAP]
    selected_ids = {record["query_id"] for record in selected}
    for path in spectra_dir.glob("*.npz"):
        if path.stem not in selected_ids:
            path.unlink()

    query_frame = pd.DataFrame(selected).sort_values("query_id")
    query_frame.to_csv(
        args.out_dir / "queries.csv",
        index=False,
        lineterminator="\n",
    )
    pair_rows = []
    for record in selected:
        for phase_id in record["phase_ids"].split("|"):
            pair_rows.append(
                {
                    "source": "opxrd_empa",
                    "query_id": record["query_id"],
                    "cluster_id": record["cluster_id"],
                    "phase_id": phase_id,
                    "present": 1,
                    "primary": 0,
                }
            )
    pair_frame = pd.DataFrame(pair_rows).sort_values(["query_id", "phase_id"])
    pair_frame.to_csv(
        args.out_dir / "query_phase_pairs.csv",
        index=False,
        lineterminator="\n",
    )

    exclusion_frame = pd.DataFrame(exclusions).sort_values("source_path")
    exclusion_frame.to_csv(
        args.out_dir / "eligibility.csv",
        index=False,
        lineterminator="\n",
    )
    reason_counts = Counter(
        reason
        for row in exclusions
        for reason in row["reasons"].split("|")
        if reason
    )
    manifest = {
        "status": "opxrd_empa_dataset_frozen",
        "source_doi": SOURCE_DOI,
        "source_md5": SOURCE_MD5,
        "protocol_sha256": PROTOCOL_SHA256,
        "query_cap": QUERY_CAP,
        "seed": SEED,
        "empa_records": total_empa,
        "eligible_before_cap": len(eligible),
        "selected_queries": len(selected),
        "selected_clusters": int(query_frame["cluster_id"].nunique()),
        "candidate_count": len(candidate_frame),
        "excluded_records": len(exclusions),
        "exclusion_reason_counts": dict(sorted(reason_counts.items())),
        "files": {
            "queries": {
                "sha256": sha256(args.out_dir / "queries.csv"),
            },
            "query_phase_pairs": {
                "sha256": sha256(args.out_dir / "query_phase_pairs.csv"),
            },
            "candidate_library": {
                "sha256": sha256(args.out_dir / "candidate_library.csv"),
            },
            "eligibility": {
                "sha256": sha256(args.out_dir / "eligibility.csv"),
            },
        },
    }
    (args.out_dir / "dataset_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
