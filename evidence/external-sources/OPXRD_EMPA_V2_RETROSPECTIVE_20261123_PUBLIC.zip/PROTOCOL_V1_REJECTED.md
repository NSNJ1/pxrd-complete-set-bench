# opXRD external retrospective protocol

Status: frozen before inspecting any opXRD record content  
Freeze date: 2026-11-23  
Claim type: external retrospective evaluation, not prospective validation

## Source

- Official record: `10.5281/zenodo.15298026`
- Concept DOI: `10.5281/zenodo.14254270`
- File: `opxrd.zip`
- File size: 1,400,997,733 bytes
- Published MD5: `e8e9800a8ecd2b7f01a764fdf77d5c53`
- Data license: CC BY 4.0
- Python wrapper source: `https://github.com/aimat-lab/opXRD`
- Wrapper source archive SHA-256 used for schema interpretation:
  `53e7a8d0a218c73bc789467f613d0524a0e02f67fccaf5530ad6ca08ffd88427`
  (the archive was not used as a dataset copy)

Only the official ZIP central directory and public schema documentation were
examined before this protocol was frozen. No `pattern_*.json` payload was
opened, and no model score or benchmark outcome was observed.

## Query eligibility

The archive is expected to contain 92,552 JSON records grouped by institution.
A record is eligible as a query only when all of the following hold:

1. the stored spectrum has at least 100 finite points;
2. two-theta coordinates are strictly increasing;
3. maximum intensity is positive;
4. `powder_experiment.phases` contains two, three or four non-null phases;
5. every phase has a non-empty chemical composition and a finite integer
   space-group number;
6. all lattice lengths and angles are finite and positive;
7. no duplicate phase identity occurs within the query;
8. every true identity has at least one eligible single-phase reference record
   from a different institution; if no cross-institution reference exists, a
   same-institution reference is allowed and the fallback is recorded.

Invalid or partially labelled records are excluded with a machine-readable
reason. Missing fields are never imputed.

## Phase identity

A phase identity is the tuple:

```text
(normalized chemical composition,
 space-group number,
 a, b, c rounded to 0.02 A,
 alpha, beta, gamma rounded to 0.1 degree)
```

The hash of this tuple is the comparison identity. This identity is used only
to link data records; it is not presented as a crystallographic phase standard.

## Candidate references

A candidate reference must be a single-phase opXRD record with the same phase
identity, a valid spectrum and a non-empty source path. When multiple references
exist, the selected reference is the record with the smallest value of:

```text
SHA256("opxrd-reference-v1|" + query_institution + "|" + candidate_identity
       + "|" + candidate_record_path)
```

References from a different institution are preferred. Same-institution
fallback is allowed only when no cross-institution candidate exists, and every
fallback is reported.

The candidate reference spectrum is linearly interpolated to the query's
two-theta support. Outside the overlap, both profiles receive zero. Each
reference is max-normalized. No ground-truth phase set, query label, AER score
or method outcome is passed to a scorer.

## Query selection and library construction

Eligible queries are grouped by institution. Within each institution, records
are sorted by:

```text
SHA256("opxrd-query-v1|20261123|" + record_path)
```

At most 20 queries are taken from each institution. If an institution has
fewer eligible records, all are retained. This prevents a single large
institution from determining the conclusion.

Each query receives a fixed library of at most 20 candidate identities:

1. all true identities are retained;
2. distractors are drawn without replacement from the union of eligible
   candidate identities;
3. possible distractors are sorted by
   `SHA256("opxrd-distractor-v1|20261123|" + record_path + "|" + identity)`;
4. the first distractors are added until the library reaches 20 candidates or
   the distractor pool is exhausted.

The candidate library, relevance labels and cluster identity are written after
selection and hashed before any method score is computed.

The cluster unit is the query JSON path. Query records from the same institution
are never treated as statistically independent if they share an explicit sample
identifier; when such an identifier is unavailable, each query is its own
cluster and this is reported as a limitation.

## Scorers

The same frozen code path is used for every eligible query:

- deterministic random ranking;
- global sqrt-Pearson similarity;
- eight-window sqrt-Pearson similarity;
- anchored-set strict ranking;
- XMatcher AutoMix only if the same official executable can consume the
  measured reference spectra without changing the library or candidate truth.

The three project scorers use the algorithm definitions already frozen in the
PXRD-CompleteSetBench repository. A scorer that cannot consume the opXRD
records without a new learned fit is excluded rather than replaced with an
unregistered method.

## Endpoints and statistics

Primary endpoints:

- phase average precision;
- all-present@2;
- all-present@3;
- screening recall for a review budget of three.

Secondary endpoints:

- risk-coverage at 50%, 70% and 90% coverage;
- failure taxonomy;
- institution-level and phase-count-level results.

Uncertainty uses 10,000 query-cluster bootstrap replicates with seed
`20261123`. Pairwise differences use the same resampled clusters. Holm
correction is applied within each endpoint family. Equal scores remain one AP
threshold block, and all-present ranking uses phase identity as the fixed tie
break with a separate tie-bound report.

## Pre-specified interpretation gates

The source is considered informative, rather than merely executable, only if:

- at least 40 eligible queries remain;
- at least four institutions are represented;
- random all-present@3 is below 75%.

Evidence that the project method clears the no-information control requires:

- Holm-adjusted paired p < 0.05;
- lower 95% interval of the paired gain above zero.

A superiority claim over the strongest non-random baseline requires:

- a paired gain of at least 5 percentage points on all-present@3;
- lower 95% interval of that gain above zero;
- agreement in the same direction on phase AP.

If these gates fail, the result is reported as a failed or mixed external
confirmation. The protocol is not changed after seeing the result.

## Leakage and claim boundary

opXRD was not part of the seven consumed source cohorts or the external method
panel when this protocol was frozen. Because labels are public and the source
was accessed after method development, results are labelled **external
retrospective**. They are not prospective validation.

The source may be used to support cross-institution generalization only if the
candidate-reference fallback rate and institution composition are reported.
No result from this source is pooled with the seven existing sources unless the
input schema, candidate construction and endpoint definitions pass review.
