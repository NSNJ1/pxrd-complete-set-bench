# Source and licence

## Measured spectra

The selected spectra are derived from opXRD:

- Hollarek, D. et al. opXRD: Open Experimental Powder X-ray Diffraction
  Database. DOI `10.5281/zenodo.15298026`
- Licence: Creative Commons Attribution 4.0 International
- Official archive MD5: `e8e9800a8ecd2b7f01a764fdf77d5c53`
- The archive itself is not mirrored here.

This package contains only 200 selected EMPA spectra, their derived masks,
query identities, labels and hashes.

## Candidate structures

The candidate CIFs are from the Crystallography Open Database:

- COD homepage: https://www.crystallography.net/cod/
- COD data licence: CC0 1.0
- COD entries: 9009196, 9009195, 1010062 and 4124388

The CIF hashes in `dataset/candidate_library.csv` identify the exact records
used for this run.

## Code

The adapter and evaluator scripts are original project contributions and follow
the PXRD-CompleteSetBench licence terms. They do not redistribute the upstream
opXRD wrapper.
