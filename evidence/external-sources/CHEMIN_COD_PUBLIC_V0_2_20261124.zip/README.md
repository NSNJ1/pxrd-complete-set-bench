# CheMin closed-library complete-set benchmark v0.2

This package contains a blind evaluation input for closed-library,
known-family retrieval from measured Mars CheMin X-ray diffraction patterns.

## Task

For each query spectrum, rank the candidate families so that every family
reported by the source enters a fixed review budget.

## Files

- `queries.csv`: opaque query IDs, Co K-alpha wavelength and spectrum paths.
- `candidates.csv`: opaque candidate-family IDs and numeric reference-profile
  paths.
- `spectra/`: raw measured two-column spectra.
- `reference_profiles/`: structure-derived profiles on a common normalized
  grid.
- `PUBLIC_MANIFEST.json`: counts, contracts and hashes.
- `CHECKSUMS.sha256`: per-file SHA-256 values.

## Evaluation boundary

This is retrospective, closed-library and known-family retrieval. It does not
tell whether a candidate is absent from the source catalogue, and it does not
measure amorphous content, phases below the reporting limit or prospective
performance.

The query labels, sample groups and candidate provenance are intentionally
withheld from this blind package. A method must not be described as label-blind
if the executor has access to those withheld files.

## Licences and attribution

- Measured spectra: NASA Planetary Data System, MSL CheMin derived products.
  Cite the PDS dataset and the release used by the benchmark.
- Candidate reference structures: Crystallography Open Database records
  dedicated to the public domain under CC0 1.0.
- Project-created derived profiles and documentation: CC BY 4.0.

No non-redistributable upstream candidate profiles are included.
